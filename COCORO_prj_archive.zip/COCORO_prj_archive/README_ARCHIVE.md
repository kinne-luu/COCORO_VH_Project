# COCORO_prj_archive — Tài liệu tổng hợp & Giải thích lưu trữ

Tài liệu này mô tả ngắn gọn toàn bộ nội dung bên trong gói lưu trữ `COCORO_prj_archive` để **cả con người và AI** có thể nhanh chóng hiểu từng thư mục/tệp dùng để làm gì khi cần tra cứu lại.

---

## 1. Tổng quan những gì đã làm trong dự án Việt hóa COCORO

1. **Dịch thuật & Biên tập kịch bản:** Dịch 12.867 câu thoại từ 50 chương (`scn00_00` đến `scn01_01`) bằng workflow dịch thuật và lưu kết quả chuẩn vào file Excel `COCORO_Dialogue-chinh-sua.xlsx`.
2. **Việt hóa Giao diện (UI) & Căn chỉnh tọa độ (PBD):**
   - Xuất ảnh gốc từ `data.xp3`, thiết kế/thay chữ tiếng Việt, convert sang chuẩn nén **TLG5 (`mark = 0`)** bằng `msg_tool.exe` để tránh lỗi khối tím `#FF00FF`.
   - Đồng bộ lại tọa độ cắt lát (`cx, cy, cw, ch, ox, oy`) trong 46 tệp `.pbd` để nút bấm và nhãn hiển thị đúng vị trí.
3. **Việt hóa Tooltip & Văn bản hệ thống:**
   - Dịch toàn bộ 97 mục giải thích ở menu Cài đặt (`help_conf.txt`) và chuỗi mẫu tốc độ chữ/hệ thống (`ConfigPreviewText`, ghi chú Save/Load, Backlog).
   - Chuyển sang định dạng **Plain Text UTF-16LE có BOM (`\xFF\xFE`)** + đặt `segm.flags = 0` khi đóng gói để khắc phục triệt để lỗi `Read error: option`.
4. **Đóng gói chuẩn Frontwing HXV4:** Dùng `DripProgram` tính toán Filter Runtime State 48-byte cho từng entry khi nạp vào `data.xp3` và `video.xp3`.

---

## 2. Giải thích vì sao các tệp ảnh & script trong Archive nhìn thô / không đẹp

Các ảnh và script lưu trong gói này là **sản phẩm trung gian trong quá trình thử nghiệm và tinh chỉnh kỹ thuật**:
- **Dùng AI + Python script để cắt ghép tự động:** Nhiều ảnh UI, nút bấm, khung chữ được tạo hoặc cắt ghép hàng loạt bằng script Python (`PIL`/`Pillow`, `crop_*`, `measure_*`, `stack_buttons.py`...) dựa trên ảnh chụp màn hình hoặc atlas gốc để dò đúng từng pixel tọa độ.
- **Ép khớp với cơ chế cắt lát cứng của UI game:** Engine Kirikiri Z (`PackinOne.dll`) cắt ảnh theo khung chữ nhật cố định trong `.pbd`. Để chữ tiếng Việt (có dấu và thường dài hơn tiếng Anh/Nhật) vừa khít ô nút bấm mà không bị cắt mất nét hoặc lệch tâm, ảnh trung gian bị co giãn, cắt gọt, mở rộng canvas hoặc xếp chồng khá thô so với bản thiết kế hoàn thiện cuối cùng.
- **Mục đích lưu trữ:** Giữ lại để làm tư liệu đối chiếu, biết lịch sử đã sửa những gì và cách tọa độ được tính toán — **không phải lỗi**, và không ảnh hưởng đến bản game hoàn chỉnh đã build.

---

## 3. Cấu trúc bên trong `COCORO_prj_archive`

| Thư mục | Nội dung | Dùng để làm gì |
|---|---|---|
| `scripts_build_history/` | 65 tệp `.py` phụ trợ (`build_*`, `fix_*`, `measure_*`, `crop_*`, `extract_*`, `sync_pbd.py`...) | Các script viết ra trong lúc dò tọa độ, cắt thử ảnh, kiểm tra PBD/TLG, sửa từng phần UI và config. (Các script đóng gói chính nằm ở thư mục gốc dự án ngoài archive). |
| `images_edited_and_done/` | `exported_png_from_psd/`, `UI_Da_Sua/`, `UI_Chua_Sua/`, `UI_Image_VH/`, `UI_Wireframe_Templates/`, `lỗi UI/`, `Music_Titles_Crop/` | Toàn bộ ảnh UI đã qua chỉnh sửa, ảnh xuất từ PSD, ảnh wireframe mẫu dùng để căn khung và ảnh chụp lỗi UI trong lúc test. |
| `translation_workflow/` | `COCORO_Translate/` (`config`, `logs`, `notes`, `out`, `prompts`, `work`) và `cocoro_context_and_pronoun_guide.md` | Toàn bộ quy trình, prompt, ghi chú ngữ cảnh/xưng hô và dữ liệu trung gian của quá trình dịch thoại bằng AI. |
| `misc_old_builds/` | `COCORO_Patch_Full/`, `true_clean_extracted/`, `data/` | Các bản patch cũ từ đợt đầu, bản extract kiểm chứng và tệp `.pbd` lẻ thử nghiệm. |

---

## 4. Ghi chú nhanh cho AI / Người dùng khi cần build lại game

- Nếu chỉ muốn **chơi hoặc cài bản Việt hóa**: dùng thư mục `COCORO_Patch_VietHoa/` (nằm ngoài archive).
- Nếu muốn **build lại `data.xp3` từ nguồn chính**: đọc `README.md` ở thư mục gốc và chạy `repack_viet_hoa_full.py` (không chạy các script cũ trong `scripts_build_history/` vì chúng có thể ghi đè lên bản vá mới nhất).
