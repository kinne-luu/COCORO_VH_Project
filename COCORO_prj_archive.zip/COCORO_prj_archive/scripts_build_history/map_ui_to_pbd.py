import json
from pathlib import Path

dump_dir = Path(r"D:\Software\Antigravity\Project\Cocoro\temp_pbd_dumps")
raw_dir = Path(r"D:\Software\Antigravity\Project\Cocoro\image\UI_Raw")

ui_entries = [
    (1931, "entry_01931_578a"),
    (1937, "entry_01937_5790"),
    (1942, "entry_01942_5795"),
    (1948, "entry_01948_579b"),
    (1952, "entry_01952_579f"),
    (1961, "entry_01961_57a8"),
    (1970, "entry_01970_57b1"),
    (1979, "entry_01979_57ba"),
    (1988, "entry_01988_57c3"),
    (1997, "entry_01997_57cc"),
    (2006, "entry_02006_57d5"),
    (2026, "entry_02026_57e9"),
    (2037, "entry_02037_57f4"),
    (2055, "entry_02055_5806"),
    (2081, "entry_02081_5820"),
    (2165, "entry_02165_5874")
]

# Scan all PBDs and check their storage/images
pbd_data = {}
for p in sorted(dump_dir.glob("entry_*.json")):
    if any(k in p.name for k in ["synced", "test", "verify"]):
        continue
    try:
        d = json.load(open(p, encoding="utf-8"))
        pbd_data[p.name] = d
    except Exception:
        pass

print("=== MAPPING UI ENTRIES TO PBD FILES ===")
for idx, name in ui_entries:
    raw_png = raw_dir / f"{name}.png"
    size_str = "unknown"
    if raw_png.exists():
        from PIL import Image
        im = Image.open(raw_png)
        size_str = f"{im.size[0]}x{im.size[1]}"
        
    print(f"\n--- Entry {idx:05d} ({name}) Size: {size_str} ---")
    
    # Find matching PBDs that reference this entry's slices or holdimage
    matching_pbds = []
    for pbd_name, d in pbd_data.items():
        hold = d.get("holdimage", []) or []
        packbase = d.get("packbase", []) or []
        # check result nodes for image / storage
        res = d.get("result", {})
        found = False
        
        # Check if packlist slices match bounds or if storage matches
        for k, v in res.items():
            if isinstance(v, dict):
                states = v.get("uistates", {})
                for sk, sv in states.items():
                    if isinstance(sv, dict):
                        stg = sv.get("storage")
                        if stg and any(h in stg for h in hold):
                            pass
        matching_pbds.append((pbd_name, packbase, hold, len(d.get("packlist") or [])))

# Let's inspect which PBD belongs to which entry
