from PIL import Image
import json

pbd = json.load(open("temp_pbd_dumps/entry_02157_586c.json", encoding="utf-8"))
im_orig = Image.open("image/UI_Raw/entry_02055_5806.png").convert("RGBA")
im_user = Image.open("image/UI_Da_Sua/entry_02055_5806.png").convert("RGBA")

# Tạo 2 canvas mô phỏng màn hình 1920x1080 (hoặc crop vùng x=1500..1920, y=0..1080)
canvas_orig = Image.new("RGBA", (400, 1080), (0, 0, 0, 0))
canvas_user = Image.new("RGBA", (400, 1080), (0, 0, 0, 0))

res = pbd["result"]

for name, node in res.items():
    if "x" in node and "y" in node and "uistates" in node:
        nx = node["x"] - 1550
        ny = node["y"]
        st = node["uistates"]
        if "normal" in st:
            norm = st["normal"]
            cx, cy, cw, ch = norm["cx"], norm["cy"], norm["cw"], norm["ch"]
            cr = norm.get("cr", 0)
            
            c_orig = im_orig.crop((cx, cy, cx+cw, cy+ch))
            c_user = im_user.crop((cx, cy, cx+cw, cy+ch))
            if cr == 1:
                c_orig = c_orig.transpose(Image.Transpose.ROTATE_270)
                c_user = c_user.transpose(Image.Transpose.ROTATE_270)
                
            canvas_orig.paste(c_orig, (nx, ny), c_orig)
            canvas_user.paste(c_user, (nx, ny), c_user)

canvas_orig.save("sim_menu_orig.png")
canvas_user.save("sim_menu_user.png")
print("Saved simulated in-game menus!")
