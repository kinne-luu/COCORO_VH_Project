# -*- coding: utf-8 -*-
"""
Cập nhật Title Menu:
1. Đổi 'EXTRA' -> 'MỞ RỘNG'
2. Hạ thấp toàn bộ hàng chữ xuống (BASELINE_OFFSET_Y = 34 trong ô ch=48) để cân giữa theo chiều cao dải trắng
3. Giữ nguyên Baseline phẳng (anchor='ms') để chữ có dấu nặng không bị kênh
4. Dòng gạch chân hover tại y=38
5. Xuất layered PSD chuẩn vào wireframe_guide/title_template_guide.psd
6. Biên dịch entry_02161.bin và entry_02165_5874.tlg
"""

import sys
import json
import shutil
import subprocess
from pathlib import Path
import numpy as np
from PIL import Image, ImageDraw, ImageFont, ImageFilter
import pytoshop
from pytoshop.user import nested_layers

ROOT_DIR = Path(r"D:\Software\Antigravity\Project\Cocoro")
GUIDE_DIR = Path(r"D:\Workspace\Creative\2D\Projects\Photoshop\COCORO Prj\wireframe_guide")
MSG_TOOL = ROOT_DIR / "tools" / "msg-tool" / "msg_tool.exe"
PATCH_UI_DIR = ROOT_DIR / "COCORO_Patch_VietHoa" / "patch_data" / "ui"
PATCH_PBD_DIR = ROOT_DIR / "COCORO_Patch_VietHoa" / "patch_data" / "pbd"
TLG_MSGTOOL_DIR = ROOT_DIR / "tlg_msgtool"

FONT_PATH = Path(r"C:\Users\ADMIN\AppData\Local\Microsoft\Windows\Fonts\STIXTwoText-Bold.ttf")
if not FONT_PATH.exists():
    FONT_PATH = Path(r"C:\Windows\Fonts\timesbd.ttf")

SMALL_FONT = ImageFont.truetype(str(FONT_PATH), 11)

RAW_ATLAS_TITLE = ROOT_DIR / "image" / "UI_Raw" / "entry_02165_5874.png"
PBD_ORIG_JSON = ROOT_DIR / "temp_pbd_dumps" / "entry_02161_5870.json"
PBD_ORIG_BIN = ROOT_DIR / "extracted_data" / "data" / "entry_02161_5870.bin"

raw_title_img = Image.open(RAW_ATLAS_TITLE).convert("RGBA")

CANVAS_W = 650
CANVAS_H = 780
COL1_X = 90   # Normal column
COL2_X = 350  # Hover column
START_Y = 30
ROW_STEP = 64
BOX_H = 48
# Hạ thấp baseline từ 30 -> 34 để chữ cân giữa đối xứng hoàn hảo trong chiều cao thanh trắng
BASELINE_OFFSET_Y = 34

TITLE_BUTTONS = {
    "cont":    {"row": 0, "w": 191, "h": 53, "cw": 191, "ch": BOX_H, "text": "TIẾP TỤC", "font_size": 26},
    "start":   {"row": 1, "w": 125, "h": 53, "cw": 140, "ch": BOX_H, "text": "BẮT ĐẦU",  "font_size": 26},
    "load":    {"row": 2, "w": 110, "h": 53, "cw": 125, "ch": BOX_H, "text": "TẢI",      "font_size": 26},
    "option":  {"row": 3, "w": 164, "h": 53, "cw": 164, "ch": BOX_H, "text": "TÙY CHỌN", "font_size": 26},
    "extra":   {"row": 4, "w": 140, "h": 53, "cw": 160, "ch": BOX_H, "text": "MỞ RỘNG",  "font_size": 26},
    "exit":    {"row": 5, "w": 97,  "h": 53, "cw": 115, "ch": BOX_H, "text": "THOÁT",    "font_size": 26},
    "gallery": {"row": 6, "w": 170, "h": 53, "cw": 170, "ch": BOX_H, "text": "THƯ VIỆN", "font_size": 26},
    "music":   {"row": 7, "w": 126, "h": 53, "cw": 140, "ch": BOX_H, "text": "NHẠC",     "font_size": 26},
    "after":   {"row": 8, "w": 129, "h": 53, "cw": 160, "ch": BOX_H, "text": "AFTER",    "font_size": 26},
    "credits": {"row": 9, "w": 142, "h": 53, "cw": 142, "ch": BOX_H, "text": "ĐỘI NGŨ",  "font_size": 26},
    "back":    {"row": 10,"w": 109, "h": 53, "cw": 130, "ch": BOX_H, "text": "TRỞ LẠI",  "font_size": 26}
}

SLICE_INDEX_MAP = {
    0:  ("after",   "off"),
    1:  ("after",   "on"),
    2:  ("back",    "off"),
    3:  ("back",    "on"),
    4:  ("cont",    "off"),
    5:  ("cont",    "on"),
    6:  ("copyright", None),
    7:  ("credits", "off"),
    8:  ("credits", "on"),
    9:  ("exit",    "off"),
    10: ("exit",    "on"),
    11: ("extra",   "off"),
    12: ("extra",   "on"),
    13: ("gallery", "off"),
    14: ("gallery", "on"),
    15: ("load",    "off"),
    16: ("load",    "on"),
    17: ("music",   "off"),
    18: ("music",   "on"),
    19: ("new",     None),
    20: ("option",  "off"),
    21: ("option",  "on"),
    22: ("start",   "off"),
    23: ("start",   "on"),
}

def render_button_pair_baseline(text, cw, ch, font_size=26):
    font = ImageFont.truetype(str(FONT_PATH), font_size)
    dummy = Image.new("RGBA", (1, 1), (0, 0, 0, 0))
    d = ImageDraw.Draw(dummy)
    
    center_x = cw // 2
    base_y = BASELINE_OFFSET_Y
    
    bbox = d.textbbox((center_x, base_y), text, font=font, anchor="ms")
    
    # 1. Normal
    im_normal = Image.new("RGBA", (cw, ch), (0, 0, 0, 0))
    d_norm = ImageDraw.Draw(im_normal)
    d_norm.text((center_x, base_y), text, font=font, fill=(55, 55, 55, 255), anchor="ms")
    
    # 2. Hover with Underline
    im_hover = Image.new("RGBA", (cw, ch), (0, 0, 0, 0))
    line_y = base_y + 4  # Dưới chân chữ 4px
    line_x0 = bbox[0] - 2
    line_x1 = bbox[2] + 2
    
    # Glow
    glow_img = Image.new("RGBA", (cw, ch), (0, 0, 0, 0))
    gd = ImageDraw.Draw(glow_img)
    glow_color = (0, 168, 255, 220)
    for ox in range(-2, 3):
        for oy in range(-2, 3):
            gd.text((center_x + ox, base_y + oy), text, font=font, fill=glow_color, anchor="ms")
            gd.line([(line_x0 + ox, line_y + oy), (line_x1 + ox, line_y + oy)], fill=glow_color, width=2)
            
    glow_img = glow_img.filter(ImageFilter.GaussianBlur(1.5))
    im_hover.paste(glow_img, (0, 0), glow_img)
    
    # Main white text & white underline
    d_hov = ImageDraw.Draw(im_hover)
    d_hov.text((center_x, base_y), text, font=font, fill=(255, 255, 255, 255), anchor="ms")
    d_hov.line([(line_x0, line_y), (line_x1, line_y)], fill=(255, 255, 255, 255), width=2)
    
    return im_normal, im_hover

atlas_base = Image.new("RGBA", (CANVAS_W, CANVAS_H), (0, 0, 0, 0))
atlas_guide = Image.new("RGBA", (CANVAS_W, CANVAS_H), (0, 0, 0, 0))
guide_draw = ImageDraw.Draw(atlas_guide)

cr_orig = raw_title_img.crop((0, 0, 52, 347))
nw_orig = raw_title_img.crop((289, 283, 289 + 23, 283 + 55))
atlas_base.paste(cr_orig, (10, 20))
atlas_base.paste(nw_orig, (10, 380))

guide_draw.rectangle([10, 20, 10 + 52 - 1, 20 + 347 - 1], outline=(255, 30, 30, 255), width=1)
guide_draw.text((12, 6), "[copyright] (52x347)", font=SMALL_FONT, fill=(255, 230, 0, 255))
guide_draw.rectangle([10, 380, 10 + 23 - 1, 380 + 55 - 1], outline=(255, 30, 30, 255), width=1)
guide_draw.text((12, 366), "[new] (23x55)", font=SMALL_FONT, fill=(255, 230, 0, 255))

guide_draw.text((COL1_X, 10), "=== COT 1: NORMAL (BINH THUONG) ===", font=SMALL_FONT, fill=(100, 255, 255, 255))
guide_draw.text((COL2_X, 10), "=== COT 2: HOVER (CO GACH CHAN) ===", font=SMALL_FONT, fill=(255, 180, 255, 255))

normal_layers_dict = {}
hover_layers_dict = {}
title_slice_coords = {}

for name, b in TITLE_BUTTONS.items():
    row = b["row"]
    cw = b["cw"]
    ch = b["ch"]
    cy = START_Y + row * ROW_STEP
    text = b["text"]
    fsize = b["font_size"]
    
    norm_img, hov_img = render_button_pair_baseline(text, cw, ch, fsize)
    
    # 1. Normal
    cx1 = COL1_X
    atlas_base.paste(norm_img, (cx1, cy), norm_img)
    normal_layers_dict[f"{name}_normal"] = {"img": norm_img, "box": (cx1, cy, cx1 + cw, cy + ch)}
    guide_draw.rectangle([cx1, cy, cx1 + cw - 1, cy + ch - 1], outline=(255, 40, 40, 255), width=1)
    guide_draw.line([(cx1, cy + BASELINE_OFFSET_Y), (cx1 + cw - 1, cy + BASELINE_OFFSET_Y)], fill=(0, 180, 255, 180), width=1)
    guide_draw.text((cx1, cy - 14), f"[{name}] {text} (Normal) - {cw}x{ch}", font=SMALL_FONT, fill=(255, 230, 0, 255))
    
    # 2. Hover
    cx2 = COL2_X
    atlas_base.paste(hov_img, (cx2, cy), hov_img)
    hover_layers_dict[f"{name}_hover"] = {"img": hov_img, "box": (cx2, cy, cx2 + cw, cy + ch)}
    guide_draw.rectangle([cx2, cy, cx2 + cw - 1, cy + ch - 1], outline=(255, 40, 40, 255), width=1)
    guide_draw.line([(cx2, cy + BASELINE_OFFSET_Y), (cx2 + cw - 1, cy + BASELINE_OFFSET_Y)], fill=(0, 180, 255, 180), width=1)
    guide_draw.text((cx2, cy - 14), f"[{name}] {text} (Hover) - {cw}x{ch}", font=SMALL_FONT, fill=(255, 180, 255, 255))
    
    title_slice_coords[name] = {
        "normal": (cx1, cy, cw, ch),
        "hover":  (cx2, cy, cw, ch),
        "w": b["w"],
        "h": b["h"]
    }

base_png_path = GUIDE_DIR / "title_atlas_base.png"
guide_png_path = GUIDE_DIR / "title_atlas_guide.png"
atlas_base.save(base_png_path)
atlas_guide.save(guide_png_path)
print(f"   + Da luu {base_png_path.name} va {guide_png_path.name}")

# Build layered PSD
def pil_to_pytoshop_layer(pil_img, name, left, top):
    arr = np.array(pil_img)
    h, w = arr.shape[:2]
    return nested_layers.Image(
        name=name,
        top=top,
        left=left,
        bottom=top + h,
        right=left + w,
        channels={
            0: arr[:, :, 0],
            1: arr[:, :, 1],
            2: arr[:, :, 2],
            -1: arr[:, :, 3]
        }
    )

wire_img_layer = pil_to_pytoshop_layer(atlas_guide, "Khung_Wireframe_Va_Nhan (TAT MAT KHI XUAT PNG)", 0, 0)
group_guide = nested_layers.Group(
    name="[HUONG_DAN_WIREFRAME] (TAT MAT KHI XUAT PNG)",
    layers=[wire_img_layer],
    closed=False
)

hover_sublayers = [pil_to_pytoshop_layer(v["img"], k, v["box"][0], v["box"][1]) for k, v in hover_layers_dict.items()]
group_hover = nested_layers.Group(
    name="[HOVER_EFFECT] (Chu Khi Re Chuot - Co Gach Chan)",
    layers=hover_sublayers,
    closed=True
)

normal_sublayers = [pil_to_pytoshop_layer(v["img"], k, v["box"][0], v["box"][1]) for k, v in normal_layers_dict.items()]
group_normal = nested_layers.Group(
    name="[NORMAL_TEXT] (Chu Khi Binh Thuong - Khong Gach Chan)",
    layers=normal_sublayers,
    closed=True
)

static_cr_layer = pil_to_pytoshop_layer(cr_orig, "Copyright_Logo", 10, 20)
static_nw_layer = pil_to_pytoshop_layer(nw_orig, "New_Icon", 10, 380)
group_static = nested_layers.Group(
    name="[STATIC_ELEMENTS] (Logo & Bieu Tuong Co Dinh)",
    layers=[static_cr_layer, static_nw_layer],
    closed=True
)

psd_layers = [group_guide, group_hover, group_normal, group_static]
psd_obj = nested_layers.nested_layers_to_psd(
    psd_layers,
    color_mode=3,
    size=(CANVAS_W, CANVAS_H),
    compression=0
)
psd_file_path = GUIDE_DIR / "title_template_guide.psd"
with open(psd_file_path, "wb") as f:
    psd_obj.write(f)
print(f"   + Da cap nhat file PSD: {psd_file_path.name} ({psd_file_path.stat().st_size:,} bytes)!")

# Update PBD entry_02161
with open(PBD_ORIG_JSON, "r", encoding="utf-8") as f:
    pbd_data = json.load(f)

packlist = pbd_data.get("packlist", [])
packlist[6][0] = 10
packlist[6][1] = 20
packlist[6][2] = 52
packlist[6][3] = 347

packlist[19][0] = 10
packlist[19][1] = 380
packlist[19][2] = 23
packlist[19][3] = 55

for s_idx, (bname, st_type) in SLICE_INDEX_MAP.items():
    if bname in title_slice_coords:
        coords = title_slice_coords[bname]
        cx, cy, cw, ch = coords["normal"] if st_type == "off" else coords["hover"]
        packlist[s_idx][0] = cx
        packlist[s_idx][1] = cy
        packlist[s_idx][2] = cw
        packlist[s_idx][3] = ch
        if len(packlist[s_idx]) > 7:
            packlist[s_idx][7] = None

res = pbd_data.get("result", {})
for bname, coords in title_slice_coords.items():
    if bname in res:
        node = res[bname]
        st = node.get("uistates", {})
        w_node = coords["w"]
        cw_norm = coords["normal"][2]
        ch_norm = coords["normal"][3]
        ox_norm = (w_node - cw_norm) // 2
        
        cw_hov = coords["hover"][2]
        ch_hov = coords["hover"][3]
        ox_hov = (w_node - cw_hov) // 2
        
        if "off" in st:
            st["off"].update({
                "cx": coords["normal"][0], "cy": coords["normal"][1],
                "cw": cw_norm, "ch": ch_norm,
                "w": cw_norm, "h": ch_norm,
                "ox": ox_norm, "oy": 4, "cr": None
            })
        if "on" in st:
            st["on"].update({
                "cx": coords["hover"][0], "cy": coords["hover"][1],
                "cw": cw_hov, "ch": ch_hov,
                "w": cw_hov, "h": ch_hov,
                "ox": ox_hov, "oy": 4, "cr": None
            })

temp_pbd_synced = Path("temp_title_pbd_synced.json")
with open(temp_pbd_synced, "w", encoding="utf-8") as f:
    json.dump(pbd_data, f, indent=2, ensure_ascii=False)

out_pbd_bin = PATCH_PBD_DIR / "entry_02161.bin"
cmd_pbd = [str(MSG_TOOL), "import", "-t", "kirikiri-tjs-ns0", str(PBD_ORIG_BIN), str(temp_pbd_synced), str(out_pbd_bin)]
subprocess.run(cmd_pbd, check=True)
print(f"   + Da bien dich PBD thanh cong: {out_pbd_bin.name} ({out_pbd_bin.stat().st_size:,} bytes)!")

# Convert atlas_base to TLG5
out_title_tlg = TLG_MSGTOOL_DIR / "entry_02165_5874.tlg"
cmd_tlg = [str(MSG_TOOL), "import", "-t", "kirikiri-tlg", str(ROOT_DIR / "extracted_data" / "data" / "entry_02165_5874.bin"), str(base_png_path), str(out_title_tlg)]
subprocess.run(cmd_tlg, check=True)
patch_title_tlg = PATCH_UI_DIR / "entry_02165.bin"
patch_title_tlg.write_bytes(out_title_tlg.read_bytes())
print(f"   + Da xuat TLG5 thanh cong: {out_title_tlg.name} ({out_title_tlg.stat().st_size:,} bytes)!")
