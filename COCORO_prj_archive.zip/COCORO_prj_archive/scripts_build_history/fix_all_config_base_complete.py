# -*- coding: utf-8 -*-
"""
Đồng bộ toàn diện 9 file PBD Config Base (In-game và Title Menu) + Atlas Base (entry_01948):
1. Cỡ chữ font STIX Two Text Bold size 28 (vừa vặn, cực đẹp, lọt thỏm giữa hai vạch | ... |)
2. TAB_WIDTH = 210, TAB_HEIGHT = 48
3. Cập nhật ĐỒNG BỘ:
   - node["width"] = 210
   - node["w"] = 210
   - st["off"]["w"] = 210, st["off"]["cw"] = 210, ox=0, oy=0
   - st["over"]["w"] = 210, st["over"]["cw"] = 210, ox=0, oy=0
4. Áp dụng cho TOÀN BỘ 9 file PBD:
   - In-game: 1939 (CN), 1941 (EN), 1943 (JP), 1945 (TW)
   - Title: 2065 (Base), 2066 (CN), 2067 (EN), 2068 (JP), 2070 (TW)
5. Xuất TLG entry_01948.bin vào COCORO_Patch_VietHoa/patch_data/ui/
6. Xuất PSD vào wireframe_guide/config_base_template_guide.psd
"""

import sys
import json
import shutil
import subprocess
from pathlib import Path
import numpy as np
from PIL import Image, ImageDraw, ImageFont, ImageFilter
import pytoshop
from pytoshop.user import nested_layers

ROOT_DIR = Path(r"D:\Software\Antigravity\Project\Cocoro")
GUIDE_DIR = Path(r"D:\Workspace\Creative\2D\Projects\Photoshop\COCORO Prj\wireframe_guide")
GUIDE_DIR.mkdir(parents=True, exist_ok=True)
MSG_TOOL = ROOT_DIR / "tools" / "msg-tool" / "msg_tool.exe"
FRESH_DIR = ROOT_DIR / "orig_fresh"
EXT_DATA_DIR = ROOT_DIR / "extracted_data" / "data"
PATCH_UI_DIR = ROOT_DIR / "COCORO_Patch_VietHoa" / "patch_data" / "ui"
PATCH_PBD_DIR = ROOT_DIR / "COCORO_Patch_VietHoa" / "patch_data" / "pbd"
TLG_MSGTOOL_DIR = ROOT_DIR / "tlg_msgtool"

FONT_PATH = Path(r"C:\Users\ADMIN\AppData\Local\Microsoft\Windows\Fonts\STIXTwoText-Bold.ttf")
if not FONT_PATH.exists():
    FONT_PATH = Path(r"C:\Windows\Fonts\timesbd.ttf")

FONT_TAB_NORMAL = ImageFont.truetype(str(FONT_PATH), 28)
FONT_TAB_HOVER  = ImageFont.truetype(str(FONT_PATH), 28)

def pil_to_pytoshop_layer(pil_img, name, left, top):
    arr = np.array(pil_img)
    h, w = arr.shape[:2]
    return nested_layers.Image(
        name=name, top=top, left=left, bottom=top + h, right=left + w,
        channels={0: arr[:, :, 0], 1: arr[:, :, 1], 2: arr[:, :, 2], -1: arr[:, :, 3]}
    )

print("=" * 70)
print("   BẮT ĐẦU ĐỒNG BỘ TOÀN DIỆN CONFIG BASE (9 PBD + 1 TLG)   ")
print("=" * 70)

RAW_TAB_PATH = FRESH_DIR / "entry_01948.png"
raw_tab_img = Image.open(RAW_TAB_PATH).convert("RGBA")

CANVAS_W = 1652
CANVAS_H = 500
atlas_canvas = Image.new("RGBA", (CANVAS_W, CANVAS_H), (0, 0, 0, 0))
atlas_canvas.paste(raw_tab_img, (0, 0)) # Bảo tồn nguyên bản 100% vùng gốc slider

TAB_WIDTH = 210
TAB_HEIGHT = 48

# Tọa độ x màn hình cân giữa các slot | ... |
# Slot 0: 553..833 (tâm 693) -> x = 588
# Slot 1: 833..1059 (tâm 946) -> x = 841
# Slot 2: 1059..1322 (tâm 1190.5) -> x = 1085
# Slot 3: 1322..1573 (tâm 1447.5) -> x = 1342
# Slot 4: 1573..1796 (tâm 1684.5) -> x = 1579
TABS_INFO = [
    ("page0", "HIỂN THỊ", 588),
    ("page1", "VĂN BẢN",  841),
    ("page2", "HỘI THOẠI",1085),
    ("page3", "ÂM THANH", 1342),
    ("page4", "GIỌNG NÓI",1579),
]

ROW_OFF_Y = 320
ROW_OVER_Y = 380
STEP_X = 220

normal_tab_layers = {}
hover_tab_layers = {}
new_tab_coords = {}

for idx, (page_key, text, target_screen_x) in enumerate(TABS_INFO):
    cx = 10 + idx * STEP_X
    
    # 1. Normal (off)
    im_off = Image.new("RGBA", (TAB_WIDTH, TAB_HEIGHT), (0, 0, 0, 0))
    d_off = ImageDraw.Draw(im_off)
    d_off.text((TAB_WIDTH // 2, TAB_HEIGHT // 2 + 7), text, font=FONT_TAB_NORMAL, fill=(160, 180, 195, 255), anchor="ms")
    atlas_canvas.paste(im_off, (cx, ROW_OFF_Y), im_off)
    normal_tab_layers[f"{page_key}_normal"] = {"img": im_off, "box": (cx, ROW_OFF_Y, cx + TAB_WIDTH, ROW_OFF_Y + TAB_HEIGHT), "text": f"{text} (Thường)"}
    
    # 2. Hover (over) - phát sáng xanh neon
    im_ov = Image.new("RGBA", (TAB_WIDTH, TAB_HEIGHT), (0, 0, 0, 0))
    glow = Image.new("RGBA", (TAB_WIDTH, TAB_HEIGHT), (0, 0, 0, 0))
    gd = ImageDraw.Draw(glow)
    center_ov_x = TAB_WIDTH // 2
    base_ov_y = TAB_HEIGHT // 2 + 7
    
    glow_col = (0, 200, 255, 240)
    for ox in range(-2, 3):
        for oy in range(-2, 3):
            gd.text((center_ov_x + ox, base_ov_y + oy), text, font=FONT_TAB_HOVER, fill=glow_col, anchor="ms")
    glow = glow.filter(ImageFilter.GaussianBlur(1.8))
    im_ov.paste(glow, (0, 0), glow)
    
    d_ov = ImageDraw.Draw(im_ov)
    d_ov.text((center_ov_x, base_ov_y), text, font=FONT_TAB_HOVER, fill=(255, 255, 255, 255), anchor="ms")
    atlas_canvas.paste(im_ov, (cx, ROW_OVER_Y), im_ov)
    hover_tab_layers[f"{page_key}_hover"] = {"img": im_ov, "box": (cx, ROW_OVER_Y, cx + TAB_WIDTH, ROW_OVER_Y + TAB_HEIGHT), "text": f"{text} (Sáng)"}
    
    new_tab_coords[page_key] = {
        "text": text,
        "x": target_screen_x,
        "y": 26, # Cân giữa tuyệt đối chiều cao dải xanh
        "off":  (cx, ROW_OFF_Y,  TAB_WIDTH, TAB_HEIGHT),
        "over": (cx, ROW_OVER_Y, TAB_WIDTH, TAB_HEIGHT)
    }

# Lưu atlas PNG
tab_png_path = GUIDE_DIR / "config_base_atlas.png"
atlas_canvas.save(tab_png_path)
atlas_canvas.save(ROOT_DIR / "image" / "UI_Da_Sua" / "entry_01948_579b.png")

# Xuất PSD layered
normal_layers = [pil_to_pytoshop_layer(v["img"], v["text"], v["box"][0], v["box"][1]) for k, v in normal_tab_layers.items()]
hover_layers  = [pil_to_pytoshop_layer(v["img"], v["text"], v["box"][0], v["box"][1]) for k, v in hover_tab_layers.items()]
base_layer    = pil_to_pytoshop_layer(raw_tab_img, "Background_Base_Clean", 0, 0)

group_normal = nested_layers.Group(name="[TAB_NORMAL] (Chữ Xám Thanh Lịch - Font 28)", layers=normal_layers, closed=False)
group_hover  = nested_layers.Group(name="[TAB_HOVER] (Chữ Sáng Neon - Font 28)", layers=hover_layers, closed=False)
group_base   = nested_layers.Group(name="[BASE_ORIGINAL] (Slider & Track Nguyên Bản Sạch)", layers=[base_layer], closed=True)

psd_obj = nested_layers.nested_layers_to_psd([group_hover, group_normal, group_base], color_mode=3, size=atlas_canvas.size, compression=0)
psd_file = GUIDE_DIR / "config_base_template_guide.psd"
with open(psd_file, "wb") as f:
    psd_obj.write(f)
print(f"   + Đã xuất PSD Tab Base Cài Đặt chuyên nghiệp: {psd_file.name} ({psd_file.stat().st_size:,} bytes)!")

# Biên dịch TLG entry_01948.bin
out_tab_tlg = TLG_MSGTOOL_DIR / "entry_01948_579b.tlg"
cmd_tab = [str(MSG_TOOL), "import", "-t", "kirikiri-tlg", str(FRESH_DIR / "entry_01948.bin"), str(tab_png_path), str(out_tab_tlg)]
subprocess.run(cmd_tab, check=True)
patch_tab_bin = PATCH_UI_DIR / "entry_01948.bin"
patch_tab_bin.write_bytes(out_tab_tlg.read_bytes())
print(f"   + Đã xuất TLG5 Tab Base: entry_01948.bin ({patch_tab_bin.stat().st_size:,} bytes)!")

# Hàm patch PBD config base
def patch_config_base_pbd(pbd_id, in_json, bin_orig, out_bin):
    with open(in_json, "r", encoding="utf-8") as f:
        pbd = json.load(f)
    
    # 1. Đảm bảo holdimage có config_base__pack
    hold = pbd.get("holdimage", [])
    if "config_base__pack" not in hold:
        hold.append("config_base__pack")
        pbd["holdimage"] = hold
        
    res = pbd.get("result", {})
    for page_key, info in new_tab_coords.items():
        if page_key in res:
            node = res[page_key]
            # CẬP NHẬT CẢ width VÀ w!
            node["width"] = TAB_WIDTH
            node["w"] = TAB_WIDTH
            node["height"] = TAB_HEIGHT
            node["h"] = TAB_HEIGHT
            node["x"] = info["x"]
            node["y"] = info["y"]
            
            st = node.get("uistates", {})
            if "off" in st:
                cx, cy, cw, ch = info["off"]
                st["off"].update({
                    "storage": "config_base__pack",
                    "cx": cx, "cy": cy, "cw": cw, "ch": ch,
                    "w": cw, "h": ch, "ox": 0, "oy": 0, "cr": None
                })
            if "over" in st:
                cx, cy, cw, ch = info["over"]
                st["over"].update({
                    "storage": "config_base__pack",
                    "cx": cx, "cy": cy, "cw": cw, "ch": ch,
                    "w": cw, "h": ch, "ox": 0, "oy": 0, "cr": None
                })
            if "on" in st:
                cx, cy, cw, ch = info["over"]
                st["on"].update({
                    "storage": "config_base__pack",
                    "cx": cx, "cy": cy, "cw": cw, "ch": ch,
                    "w": cw, "h": ch, "ox": 0, "oy": 0, "cr": None
                })
                
    tmp_json = Path(f"temp_patch_{pbd_id}.json")
    with open(tmp_json, "w", encoding="utf-8") as f:
        json.dump(pbd, f, indent=2, ensure_ascii=False)
        
    subprocess.run([str(MSG_TOOL), "import", "-t", "kirikiri-tjs-ns0", str(bin_orig), str(tmp_json), str(out_bin)], check=True)
    print(f"   + Đã xuất PBD {pbd_id}: {out_bin.name} ({out_bin.stat().st_size:,} bytes)!")

# Danh sách 9 file PBD Config Base
ALL_CONFIG_BASE_PBDS = [
    (1939, "temp_pbd_dumps/entry_01939_5792.json", EXT_DATA_DIR / "entry_01939_5792.bin"),
    (1941, "orig_fresh/entry_01941.json",          FRESH_DIR / "entry_01941.bin"),
    (1943, "orig_fresh/entry_01943.json",          FRESH_DIR / "entry_01943.bin"),
    (1945, "temp_pbd_dumps/entry_01945_5798.json", EXT_DATA_DIR / "entry_01945_5798.bin"),
    (2065, "temp_pbd_dumps/entry_02065_5810.json", EXT_DATA_DIR / "entry_02065_5810.bin"),
    (2066, "temp_pbd_dumps/entry_02066_5811.json", EXT_DATA_DIR / "entry_02066_5811.bin"),
    (2067, "temp_pbd_dumps/entry_02067_5812.json", EXT_DATA_DIR / "entry_02067_5812.bin"),
    (2068, "temp_pbd_dumps/entry_02068_5813.json", EXT_DATA_DIR / "entry_02068_5813.bin"),
    (2070, "temp_pbd_dumps/entry_02070_5815.json", EXT_DATA_DIR / "entry_02070_5815.bin"),
]

for pbd_id, in_json, bin_orig in ALL_CONFIG_BASE_PBDS:
    out_bin = PATCH_PBD_DIR / f"entry_{pbd_id:05d}.bin"
    patch_config_base_pbd(pbd_id, in_json, bin_orig, out_bin)

print("\n" + "=" * 70)
print("   HOÀN TẤT ĐỒNG BỘ 100% CẢ 9 PBD CONFIG BASE VÀ ATLAS!   ")
print("=" * 70)
