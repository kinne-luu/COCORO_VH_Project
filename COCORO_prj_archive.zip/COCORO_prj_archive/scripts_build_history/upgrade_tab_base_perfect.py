# -*- coding: utf-8 -*-
"""
Nâng cấp thanh Tab Base Cài Đặt (Top Bar):
1. Cỡ chữ to hơn nữa: font STIX Two Text Bold size 32 cho cả Normal và Hover
2. Hạ thấp xuống y = 28 để cân giữa dải màu xanh
3. Giữ nguyên 100% vùng gốc (0..1652, 0..298) sạch từ orig_fresh/entry_01948.png (KHÔNG VẼ ĐÈ LÊN SLIDER)
4. Tọa độ off và over đồng nhất ox=0, oy=0 để triệt tiêu hoàn toàn lỗi nhảy vị trí khi hover
5. Xuất PSD layered vào wireframe_guide/config_base_template_guide.psd
6. Biên dịch entry_01948.bin (TLG) và entry_01941.bin / entry_01943.bin (PBD)
"""

import sys
import json
import shutil
import subprocess
from pathlib import Path
import numpy as np
from PIL import Image, ImageDraw, ImageFont, ImageFilter
import pytoshop
from pytoshop.user import nested_layers

ROOT_DIR = Path(r"D:\Software\Antigravity\Project\Cocoro")
GUIDE_DIR = Path(r"D:\Workspace\Creative\2D\Projects\Photoshop\COCORO Prj\wireframe_guide")
GUIDE_DIR.mkdir(parents=True, exist_ok=True)
MSG_TOOL = ROOT_DIR / "tools" / "msg-tool" / "msg_tool.exe"
FRESH_DIR = ROOT_DIR / "orig_fresh"
PATCH_UI_DIR = ROOT_DIR / "COCORO_Patch_VietHoa" / "patch_data" / "ui"
PATCH_PBD_DIR = ROOT_DIR / "COCORO_Patch_VietHoa" / "patch_data" / "pbd"
TLG_MSGTOOL_DIR = ROOT_DIR / "tlg_msgtool"

FONT_PATH = Path(r"C:\Users\ADMIN\AppData\Local\Microsoft\Windows\Fonts\STIXTwoText-Bold.ttf")
if not FONT_PATH.exists():
    FONT_PATH = Path(r"C:\Windows\Fonts\timesbd.ttf")

FONT_TAB_NORMAL = ImageFont.truetype(str(FONT_PATH), 32)
FONT_TAB_HOVER = ImageFont.truetype(str(FONT_PATH), 32)
SMALL_FONT = ImageFont.truetype(str(FONT_PATH), 11)

def pil_to_pytoshop_layer(pil_img, name, left, top):
    arr = np.array(pil_img)
    h, w = arr.shape[:2]
    return nested_layers.Image(
        name=name,
        top=top,
        left=left,
        bottom=top + h,
        right=left + w,
        channels={
            0: arr[:, :, 0],
            1: arr[:, :, 1],
            2: arr[:, :, 2],
            -1: arr[:, :, 3]
        }
    )

print("=" * 70)
print("   BẮT ĐẦU NÂNG CẤP THANH TAB BASE CÀI ĐẶT (SIZE 32, CÂN GIỮA)   ")
print("=" * 70)

# Lấy ảnh gốc sạch 100% từ orig_fresh
RAW_TAB_PATH = FRESH_DIR / "entry_01948.png"
raw_tab_img = Image.open(RAW_TAB_PATH).convert("RGBA")

# Mở rộng canvas lên (1652, 520)
CANVAS_W = 1652
CANVAS_H = 520
atlas_canvas = Image.new("RGBA", (CANVAS_W, CANVAS_H), (0, 0, 0, 0))
# Giữ 100% pixel gốc của vùng y < 298
atlas_canvas.paste(raw_tab_img, (0, 0))

TAB_WIDTH = 220
TAB_HEIGHT = 48

TABS_INFO = [
    ("page0", "HIỂN THỊ", 565),
    ("page1", "VĂN BẢN",  835),
    ("page2", "HỘI THOẠI",1080),
    ("page3", "ÂM THANH", 1340),
    ("page4", "GIỌNG NÓI",1600),
]

ROW_OFF_Y = 320
ROW_OVER_Y = 390
STEP_X = 230

normal_tab_layers = {}
hover_tab_layers = {}
new_tab_coords = {}

for idx, (page_key, text, target_screen_x) in enumerate(TABS_INFO):
    cx = 10 + idx * STEP_X
    
    # 1. Normal (off)
    im_off = Image.new("RGBA", (TAB_WIDTH, TAB_HEIGHT), (0, 0, 0, 0))
    d_off = ImageDraw.Draw(im_off)
    # anchor='ms' căn giữa ngang và baseline ở giữa dọc
    d_off.text((TAB_WIDTH // 2, TAB_HEIGHT // 2 + 7), text, font=FONT_TAB_NORMAL, fill=(160, 180, 195, 255), anchor="ms")
    atlas_canvas.paste(im_off, (cx, ROW_OFF_Y), im_off)
    normal_tab_layers[f"{page_key}_normal"] = {"img": im_off, "box": (cx, ROW_OFF_Y, cx + TAB_WIDTH, ROW_OFF_Y + TAB_HEIGHT), "text": f"{text} (Thường)"}
    
    # 2. Hover (over) - phát sáng xanh neon
    im_ov = Image.new("RGBA", (TAB_WIDTH, TAB_HEIGHT), (0, 0, 0, 0))
    glow = Image.new("RGBA", (TAB_WIDTH, TAB_HEIGHT), (0, 0, 0, 0))
    gd = ImageDraw.Draw(glow)
    center_ov_x = TAB_WIDTH // 2
    base_ov_y = TAB_HEIGHT // 2 + 7
    
    glow_col = (0, 200, 255, 240)
    for ox in range(-2, 3):
        for oy in range(-2, 3):
            gd.text((center_ov_x + ox, base_ov_y + oy), text, font=FONT_TAB_HOVER, fill=glow_col, anchor="ms")
    glow = glow.filter(ImageFilter.GaussianBlur(1.8))
    im_ov.paste(glow, (0, 0), glow)
    
    d_ov = ImageDraw.Draw(im_ov)
    d_ov.text((center_ov_x, base_ov_y), text, font=FONT_TAB_HOVER, fill=(255, 255, 255, 255), anchor="ms")
    atlas_canvas.paste(im_ov, (cx, ROW_OVER_Y), im_ov)
    hover_tab_layers[f"{page_key}_hover"] = {"img": im_ov, "box": (cx, ROW_OVER_Y, cx + TAB_WIDTH, ROW_OVER_Y + TAB_HEIGHT), "text": f"{text} (Sáng)"}
    
    new_tab_coords[page_key] = {
        "text": text,
        "x": target_screen_x,
        "y": 28,  # Hạ thấp 4px để căn giữa chiều cao dải xanh
        "off":  (cx, ROW_OFF_Y,  TAB_WIDTH, TAB_HEIGHT),
        "over": (cx, ROW_OVER_Y, TAB_WIDTH, TAB_HEIGHT)
    }

# Lưu atlas PNG
tab_png_path = GUIDE_DIR / "config_base_atlas.png"
atlas_canvas.save(tab_png_path)
atlas_canvas.save(ROOT_DIR / "image" / "UI_Da_Sua" / "entry_01948_579b.png")

# Tạo layered PSD
normal_layers = [pil_to_pytoshop_layer(v["img"], v["text"], v["box"][0], v["box"][1]) for k, v in normal_tab_layers.items()]
hover_layers  = [pil_to_pytoshop_layer(v["img"], v["text"], v["box"][0], v["box"][1]) for k, v in hover_tab_layers.items()]

group_normal = nested_layers.Group(name="[TAB_NORMAL] (Chữ Xám Thanh Lịch - Font 32)", layers=normal_layers, closed=False)
group_hover  = nested_layers.Group(name="[TAB_HOVER] (Chữ Sáng Neon - Font 32)", layers=hover_layers, closed=False)
base_layer   = pil_to_pytoshop_layer(raw_tab_img, "Background_Base_Clean", 0, 0)
group_base   = nested_layers.Group(name="[BASE_ORIGINAL] (Slider & Track Nguyên Bản Sạch)", layers=[base_layer], closed=True)

psd_obj = nested_layers.nested_layers_to_psd([group_hover, group_normal, group_base], color_mode=3, size=atlas_canvas.size, compression=0)
psd_file = GUIDE_DIR / "config_base_template_guide.psd"
with open(psd_file, "wb") as f:
    psd_obj.write(f)
print(f"   + Đã xuất PSD Tab Base Cài Đặt chuyên nghiệp: {psd_file.name} ({psd_file.stat().st_size:,} bytes)!")

# Cập nhật PBD entry_01941 (EN) và entry_01943 (JP)
def update_tab_pbd(json_in, bin_template, bin_out):
    with open(json_in, "r", encoding="utf-8") as f:
        pbd = json.load(f)
    res = pbd.get("result", {})
    for page_key, info in new_tab_coords.items():
        if page_key in res:
            node = res[page_key]
            node["x"] = info["x"]
            node["y"] = info["y"] # 28
            node["w"] = TAB_WIDTH
            node["h"] = TAB_HEIGHT
            st = node.get("uistates", {})
            if "off" in st:
                cx, cy, cw, ch = info["off"]
                st["off"].update({"cx": cx, "cy": cy, "cw": cw, "ch": ch, "w": cw, "h": ch, "ox": 0, "oy": 0, "cr": None})
            if "over" in st:
                cx, cy, cw, ch = info["over"]
                st["over"].update({"cx": cx, "cy": cy, "cw": cw, "ch": ch, "w": cw, "h": ch, "ox": 0, "oy": 0, "cr": None})
    synced_json = Path("temp_tab_synced.json")
    with open(synced_json, "w", encoding="utf-8") as f:
        json.dump(pbd, f, indent=2, ensure_ascii=False)
    subprocess.run([str(MSG_TOOL), "import", "-t", "kirikiri-tjs-ns0", str(bin_template), str(synced_json), str(bin_out)], check=True)

update_tab_pbd(FRESH_DIR / "entry_01941.json", FRESH_DIR / "entry_01941.bin", PATCH_PBD_DIR / "entry_01941.bin")
update_tab_pbd(FRESH_DIR / "entry_01943.json", FRESH_DIR / "entry_01943.bin", PATCH_PBD_DIR / "entry_01943.bin")

# Biên dịch TLG entry_01948
out_tab_tlg = TLG_MSGTOOL_DIR / "entry_01948_579b.tlg"
cmd_tab = [str(MSG_TOOL), "import", "-t", "kirikiri-tlg", str(FRESH_DIR / "entry_01948.bin"), str(tab_png_path), str(out_tab_tlg)]
subprocess.run(cmd_tab, check=True)
patch_tab_bin = PATCH_UI_DIR / "entry_01948.bin"
patch_tab_bin.write_bytes(out_tab_tlg.read_bytes())
print(f"   + Đã xuất TLG5 Tab Base: entry_01948.bin ({patch_tab_bin.stat().st_size:,} bytes)!")

print("\n" + "=" * 70)
print("   HOÀN TẤT NÂNG CẤP THANH TAB BASE CÀI ĐẶT HOÀN HẢO!   ")
print("=" * 70)
