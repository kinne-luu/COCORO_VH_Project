# -*- coding: utf-8 -*-
"""
COCORO - Build Title Guide System & Synchronize PBD/TLG Engine
Target Folder: D:\Workspace\Creative\2D\Projects\Photoshop\COCORO Prj\wireframe_guide
"""

import sys
import json
import subprocess
from pathlib import Path
import numpy as np
from PIL import Image, ImageDraw, ImageFont, ImageFilter
import pytoshop
from pytoshop.user import nested_layers

# Paths
ROOT_DIR = Path(r"D:\Software\Antigravity\Project\Cocoro")
OUTPUT_DIR = Path(r"D:\Workspace\Creative\2D\Projects\Photoshop\COCORO Prj\wireframe_guide")
RAW_ATLAS = ROOT_DIR / "image" / "UI_Raw" / "entry_02165_5874.png"
PBD_ORIG_JSON = ROOT_DIR / "temp_pbd_dumps" / "entry_02161_5870.json"
PBD_ORIG_BIN = ROOT_DIR / "extracted_data" / "data" / "entry_02161_5870.bin"
MSG_TOOL = ROOT_DIR / "tools" / "msg-tool" / "msg_tool.exe"
REPACK_SCRIPT = ROOT_DIR / "repack_viet_hoa_full.py"
USER_PYTHON = Path(r"C:\Users\ADMIN\AppData\Local\Python\bin\python.exe")

OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

# Grid setup
CANVAS_W = 620
CANVAS_H = 780

BUTTON_DEFS = {
    "cont":    {"row": 0, "w": 191, "h": 53, "cw": 191, "ch": 44, "text": "TIẾP TỤC", "font_size": 22},
    "after":   {"row": 1, "w": 129, "h": 53, "cw": 129, "ch": 44, "text": "CHƯƠNG KẾ", "font_size": 18},
    "start":   {"row": 2, "w": 125, "h": 53, "cw": 125, "ch": 44, "text": "BẮT ĐẦU", "font_size": 20},
    "load":    {"row": 3, "w": 110, "h": 53, "cw": 110, "ch": 44, "text": "TẢI", "font_size": 22},
    "option":  {"row": 4, "w": 164, "h": 53, "cw": 164, "ch": 44, "text": "TÙY CHỌN", "font_size": 20},
    "extra":   {"row": 5, "w": 129, "h": 53, "cw": 129, "ch": 44, "text": "EXTRA", "font_size": 20},
    "credits": {"row": 6, "w": 142, "h": 53, "cw": 142, "ch": 44, "text": "ĐỘI NGŨ", "font_size": 20},
    "exit":    {"row": 7, "w": 97,  "h": 53, "cw": 97,  "ch": 44, "text": "THOÁT", "font_size": 20},
    "gallery": {"row": 8, "w": 170, "h": 53, "cw": 170, "ch": 44, "text": "THƯ VIỆN", "font_size": 20},
    "music":   {"row": 9, "w": 126, "h": 53, "cw": 126, "ch": 44, "text": "ÂM NHẠC", "font_size": 20},
    "back":    {"row": 10,"w": 109, "h": 53, "cw": 109, "ch": 44, "text": "TRỞ LẠI", "font_size": 20}
}

COL1_X = 90
COL2_X = 340
START_Y = 30
ROW_STEP = 64

SLICE_MAP = {
    0: ("after", "off"),
    1: ("after", "on"),
    2: ("back", "off"),
    3: ("back", "on"),
    4: ("cont", "off"),
    5: ("cont", "on"),
    6: ("copyright", None),
    7: ("credits", "off"),
    8: ("credits", "on"),
    9: ("exit", "off"),
    10: ("exit", "on"),
    11: ("extra", "off"),
    12: ("extra", "on"),
    13: ("gallery", "off"),
    14: ("gallery", "on"),
    15: ("load", "off"),
    16: ("load", "on"),
    17: ("music", "off"),
    18: ("music", "on"),
    19: ("new", None),
    20: ("option", "off"),
    21: ("option", "on"),
    22: ("start", "off"),
    23: ("start", "on"),
}

# Original slices for reference extraction
ORIG_SLICES = {
    "after_off": (52, 316, 115, 29),
    "after_on": (52, 250, 115, 33),
    "back_off": (202, 126, 93, 30),
    "back_on": (206, 62, 93, 34),
    "cont_off": (52, 33, 174, 29),
    "cont_on": (52, 0, 177, 33),
    "copyright": (0, 0, 52, 347),
    "credits_off": (52, 221, 125, 29),
    "credits_on": (52, 188, 128, 33),
    "exit_off": (226, 33, 82, 29),
    "exit_on": (229, 0, 83, 33),
    "extra_off": (180, 188, 115, 29),
    "extra_on": (52, 283, 115, 33),
    "gallery_off": (52, 96, 153, 30),
    "gallery_on": (52, 62, 154, 34),
    "load_off": (205, 96, 93, 28),
    "load_on": (180, 312, 96, 33),
    "music_off": (180, 283, 109, 29),
    "music_on": (180, 250, 110, 33),
    "new": (289, 283, 23, 55),
    "option_off": (52, 159, 147, 29),
    "option_on": (52, 126, 150, 33),
    "start_off": (199, 159, 110, 28),
    "start_on": (180, 217, 111, 33)
}

print("[1] Đang tải ảnh atlas gốc...")
raw_img = Image.open(RAW_ATLAS).convert("RGBA")

# Load fonts
font_path = Path(r"C:\Windows\Fonts\STIXTwoText-Bold.ttf")
if not font_path.exists():
    font_path = Path(r"C:\Windows\Fonts\timesbd.ttf")
small_font = ImageFont.truetype(str(font_path), 11)

# Helper function to create centered text image
def create_text_image(text, box_w, box_h, font_size, text_color, glow=False):
    font = ImageFont.truetype(str(font_path), font_size)
    # Measure
    dummy = Image.new("RGBA", (1, 1), (0, 0, 0, 0))
    d = ImageDraw.Draw(dummy)
    bbox = d.textbbox((0, 0), text, font=font)
    tw = bbox[2] - bbox[0]
    th = bbox[3] - bbox[1]
    
    img = Image.new("RGBA", (box_w, box_h), (0, 0, 0, 0))
    tx = (box_w - tw) // 2 - bbox[0]
    ty = (box_h - th) // 2 - bbox[1] - 1
    
    if glow:
        # Glow layer
        glow_img = Image.new("RGBA", (box_w, box_h), (0, 0, 0, 0))
        gd = ImageDraw.Draw(glow_img)
        glow_color = (0, 168, 255, 230)
        for ox in range(-2, 3):
            for oy in range(-2, 3):
                gd.text((tx + ox, ty + oy), text, font=font, fill=glow_color)
        glow_img = glow_img.filter(ImageFilter.GaussianBlur(1.8))
        img.paste(glow_img, (0, 0), glow_img)
    
    draw = ImageDraw.Draw(img)
    draw.text((tx, ty), text, font=font, fill=text_color)
    return img

print("[2] Khởi tạo các canvas...")
atlas_base = Image.new("RGBA", (CANVAS_W, CANVAS_H), (0, 0, 0, 0))
atlas_guide = Image.new("RGBA", (CANVAS_W, CANVAS_H), (0, 0, 0, 0))
guide_draw = ImageDraw.Draw(atlas_guide)

# 1. Static Elements
cr_orig = raw_img.crop((0, 0, 52, 347))
nw_orig = raw_img.crop((289, 283, 289 + 23, 283 + 55))

atlas_base.paste(cr_orig, (10, 20))
atlas_base.paste(nw_orig, (10, 380))

# Wireframe for static
guide_draw.rectangle([10, 20, 10 + 52 - 1, 20 + 347 - 1], outline=(255, 30, 30, 255), width=1)
guide_draw.text((12, 6), "[copyright] (52x347)", font=small_font, fill=(255, 230, 0, 255))

guide_draw.rectangle([10, 380, 10 + 23 - 1, 380 + 55 - 1], outline=(255, 30, 30, 255), width=1)
guide_draw.text((12, 366), "[new] (23x55)", font=small_font, fill=(255, 230, 0, 255))

# Column headers in guide
guide_draw.text((COL1_X, 10), "=== CỘT 1: NORMAL (OFF) ===", font=small_font, fill=(100, 255, 255, 255))
guide_draw.text((COL2_X, 10), "=== CỘT 2: HOVER (ON / OVER) ===", font=small_font, fill=(255, 180, 255, 255))

normal_layers_dict = {}
hover_layers_dict = {}
manifest = {"canvas_size": [CANVAS_W, CANVAS_H], "slices": {}}

print("[3] Vẽ các nút và tạo wireframe...")
for name, b in BUTTON_DEFS.items():
    row = b["row"]
    cw = b["cw"]
    ch = b["ch"]
    cy = START_Y + row * ROW_STEP
    text = b["text"]
    fsize = b["font_size"]
    
    # --- NORMAL (Column 1) ---
    cx1 = COL1_X
    # Red border (engine slice)
    guide_draw.rectangle([cx1, cy, cx1 + cw - 1, cy + ch - 1], outline=(255, 40, 40, 255), width=1)
    # Green border (safe text area)
    guide_draw.rectangle([cx1 + 6, cy + 4, cx1 + cw - 7, cy + ch - 5], outline=(0, 230, 80, 200), width=1)
    # Label
    guide_draw.text((cx1, cy - 14), f"[{name}] {text} - NORMAL ({cw}x{ch})", font=small_font, fill=(255, 230, 0, 255))
    
    # Reference original text
    orig_key_off = f"{name}_off"
    if orig_key_off in ORIG_SLICES:
        ocx, ocy, ocw, och = ORIG_SLICES[orig_key_off]
        ref_patch = raw_img.crop((ocx, ocy, ocx + ocw, ocy + och))
        # Dim to 30% alpha
        ref_arr = np.array(ref_patch)
        ref_arr[:, :, 3] = (ref_arr[:, :, 3] * 0.35).astype(np.uint8)
        ref_dim = Image.fromarray(ref_arr)
        # Paste centered in green box
        rx = cx1 + (cw - ocw) // 2
        ry = cy + (ch - och) // 2
        atlas_guide.paste(ref_dim, (rx, ry), ref_dim)
        
    # Render Normal text
    img_normal = create_text_image(text, cw, ch, fsize, (50, 50, 50, 255), glow=False)
    atlas_base.paste(img_normal, (cx1, cy), img_normal)
    normal_layers_dict[f"{name}_normal"] = {"img": img_normal, "box": (cx1, cy, cx1 + cw, cy + ch)}
    
    # --- HOVER (Column 2) ---
    cx2 = COL2_X
    # Red border
    guide_draw.rectangle([cx2, cy, cx2 + cw - 1, cy + ch - 1], outline=(255, 40, 40, 255), width=1)
    # Green border
    guide_draw.rectangle([cx2 + 6, cy + 4, cx2 + cw - 7, cy + ch - 5], outline=(0, 230, 80, 200), width=1)
    # Label
    guide_draw.text((cx2, cy - 14), f"[{name}] {text} - HOVER ({cw}x{ch})", font=small_font, fill=(255, 230, 0, 255))
    
    # Reference original hover text
    orig_key_on = f"{name}_on"
    if orig_key_on in ORIG_SLICES:
        ocx, ocy, ocw, och = ORIG_SLICES[orig_key_on]
        ref_patch = raw_img.crop((ocx, ocy, ocx + ocw, ocy + och))
        ref_arr = np.array(ref_patch)
        ref_arr[:, :, 3] = (ref_arr[:, :, 3] * 0.35).astype(np.uint8)
        ref_dim = Image.fromarray(ref_arr)
        rx = cx2 + (cw - ocw) // 2
        ry = cy + (ch - och) // 2
        atlas_guide.paste(ref_dim, (rx, ry), ref_dim)

    # Render Hover text (pure white + cyan glow)
    img_hover = create_text_image(text, cw, ch, fsize, (255, 255, 255, 255), glow=True)
    atlas_base.paste(img_hover, (cx2, cy), img_hover)
    hover_layers_dict[f"{name}_hover"] = {"img": img_hover, "box": (cx2, cy, cx2 + cw, cy + ch)}
    
    manifest["slices"][name] = {
        "normal": {"cx": cx1, "cy": cy, "cw": cw, "ch": ch, "ox": 0, "oy": 4},
        "hover":  {"cx": cx2, "cy": cy, "cw": cw, "ch": ch, "ox": 0, "oy": 4}
    }

# Save Guide PNG and Base PNG
guide_path = OUTPUT_DIR / "title_atlas_guide.png"
base_path = OUTPUT_DIR / "title_atlas_base.png"
manifest_path = OUTPUT_DIR / "layout_manifest.json"

atlas_guide.save(guide_path)
atlas_base.save(base_path)
with open(manifest_path, "w", encoding="utf-8") as f:
    json.dump(manifest, f, indent=2, ensure_ascii=False)

print(f"[+] Đã lưu {guide_path.name}")
print(f"[+] Đã lưu {base_path.name}")
print(f"[+] Đã lưu {manifest_path.name}")

# Helper for pytoshop Image Layer
def pil_to_pytoshop_layer(pil_img, name, left, top):
    arr = np.array(pil_img)
    h, w = arr.shape[:2]
    return nested_layers.Image(
        name=name,
        top=top,
        left=left,
        bottom=top + h,
        right=left + w,
        channels={
            0: arr[:, :, 0],
            1: arr[:, :, 1],
            2: arr[:, :, 2],
            -1: arr[:, :, 3]
        }
    )

print("[4] Đang tạo file PSD chuyên nghiệp với pytoshop...")
psd_layers = []

# Group 1: Wireframe Guide
wire_img_layer = pil_to_pytoshop_layer(atlas_guide, "Khung_Wireframe_Va_Nhan (TẮT MẮT KHI XUẤT PNG)", 0, 0)
group_guide = nested_layers.Group(
    name="[HUONG_DAN_WIREFRAME] (TẮT MẮT KHI XUẤT PNG)",
    layers=[wire_img_layer],
    closed=False
)

# Group 2: Hover Text
hover_sublayers = []
for k, v in hover_layers_dict.items():
    b = v["box"]
    hover_sublayers.append(pil_to_pytoshop_layer(v["img"], k, b[0], b[1]))
group_hover = nested_layers.Group(
    name="[HOVER_EFFECT] (Chữ Khi Rê Chuột)",
    layers=hover_sublayers,
    closed=True
)

# Group 3: Normal Text
normal_sublayers = []
for k, v in normal_layers_dict.items():
    b = v["box"]
    normal_sublayers.append(pil_to_pytoshop_layer(v["img"], k, b[0], b[1]))
group_normal = nested_layers.Group(
    name="[NORMAL_TEXT] (Chữ Khi Bình Thường)",
    layers=normal_sublayers,
    closed=True
)

# Group 4: Static
cr_layer = pil_to_pytoshop_layer(cr_orig, "copyright", 10, 20)
nw_layer = pil_to_pytoshop_layer(nw_orig, "new", 10, 380)
group_static = nested_layers.Group(
    name="[STATIC_ELEMENTS]",
    layers=[cr_layer, nw_layer],
    closed=True
)

psd = nested_layers.nested_layers_to_psd(
    [group_guide, group_hover, group_normal, group_static],
    color_mode=3,
    size=(CANVAS_W, CANVAS_H),
    compression=0
)

psd_output_path = OUTPUT_DIR / "title_template_guide.psd"
with open(psd_output_path, "wb") as f:
    psd.write(f)
print(f"[+] Đã tạo file PSD: {psd_output_path}")

print("[5] Đồng bộ tọa độ PBD và biên dịch file nhị phân...")
with open(PBD_ORIG_JSON, "r", encoding="utf-8") as f:
    pbd = json.load(f)

packlist = pbd["packlist"]
result = pbd["result"]

for s_idx, (uiname, state) in SLICE_MAP.items():
    if uiname == "copyright":
        cx, cy, cw, ch = 10, 20, 52, 347
        ox, oy = 0, 0
    elif uiname == "new":
        cx, cy, cw, ch = 10, 380, 23, 55
        ox, oy = 0, 0
    else:
        b = BUTTON_DEFS[uiname]
        row = b["row"]
        cw = b["cw"]
        ch = b["ch"]
        cy = START_Y + row * ROW_STEP
        cx = COL1_X if state == "off" else COL2_X
        ox = 0
        oy = 4
    
    # 1. Update packlist
    s = packlist[s_idx]
    s[0] = cx
    s[1] = cy
    s[2] = cw
    s[3] = ch
    if len(s) > 8 and isinstance(s[8], list) and len(s[8]) >= 6:
        s[8][4] = ox
        s[8][5] = oy
        s[8][2] = BUTTON_DEFS.get(uiname, {}).get("w", s[8][2])
        s[8][3] = 53

    # 2. Update result
    if uiname in result and isinstance(result[uiname], dict):
        node = result[uiname]
        states = node.get("uistates", {})
        if state in states:
            st = states[state]
            st["cx"] = cx
            st["cy"] = cy
            st["cw"] = cw
            st["ch"] = ch
            st["ox"] = ox
            st["oy"] = oy
            st["w"] = BUTTON_DEFS[uiname]["w"]
            st["h"] = 53
        # In kirikiri, both on and over must be updated for hover
        if state == "on" and "over" in states:
            st = states["over"]
            st["cx"] = cx
            st["cy"] = cy
            st["cw"] = cw
            st["ch"] = ch
            st["ox"] = ox
            st["oy"] = oy
            st["w"] = BUTTON_DEFS[uiname]["w"]
            st["h"] = 53

# Save synced JSON
pbd_synced_json = ROOT_DIR / "temp_pbd_dumps" / "entry_02161_5870_synced.json"
with open(pbd_synced_json, "w", encoding="utf-8") as f:
    json.dump(pbd, f, indent=2, ensure_ascii=False)

# Compile binary .bin using msg_tool
pbd_compiled_bin = ROOT_DIR / "COCORO_Patch_VietHoa" / "patch_data" / "pbd" / "entry_02161.bin"
pbd_compiled_bin.parent.mkdir(parents=True, exist_ok=True)
cmd = [str(MSG_TOOL), "import", "-t", "kirikiri-tjs-ns0", str(PBD_ORIG_BIN), str(pbd_synced_json), str(pbd_compiled_bin)]
res = subprocess.run(cmd, capture_output=True, text=True)
assert res.returncode == 0, f"Lỗi biên dịch PBD: {res.stderr}"
print(f"[+] Biên dịch PBD thành công -> {pbd_compiled_bin.name} ({pbd_compiled_bin.stat().st_size} bytes)")

# Also copy with full hash name if needed
pbd_compiled_bin_full = ROOT_DIR / "COCORO_Patch_VietHoa" / "patch_data" / "pbd" / "entry_02161_5870.bin"
with open(pbd_compiled_bin_full, "wb") as f:
    f.write(pbd_compiled_bin.read_bytes())

TLG_ORIG_BIN = ROOT_DIR / "extracted_data" / "data" / "entry_02165_5874.bin"

print("[6] Chuyển đổi atlas base PNG sang TLG5...")
tlg_output_dir = ROOT_DIR / "tlg_msgtool"
tlg_output_dir.mkdir(parents=True, exist_ok=True)
tlg_output_file = tlg_output_dir / "entry_02165_5874.tlg"

cmd = [str(MSG_TOOL), "import", "-t", "kirikiri-tlg", str(TLG_ORIG_BIN), str(base_path), str(tlg_output_file)]
res = subprocess.run(cmd, capture_output=True, text=True)
assert res.returncode == 0, f"Lỗi chuyển TLG: {res.stderr}"
print(f"[+] Chuyển đổi TLG thành công -> {tlg_output_file.name} ({tlg_output_file.stat().st_size} bytes)")

# Copy to patch_data/ui
patch_ui_dir = ROOT_DIR / "COCORO_Patch_VietHoa" / "patch_data" / "ui"
patch_ui_dir.mkdir(parents=True, exist_ok=True)
patch_ui_bin = patch_ui_dir / "entry_02165.bin"
patch_ui_bin_full = patch_ui_dir / "entry_02165_5874.bin"
patch_ui_bin.write_bytes(tlg_output_file.read_bytes())
patch_ui_bin_full.write_bytes(tlg_output_file.read_bytes())
print(f"[+] Đã copy TLG sang patch_data/ui/entry_02165.bin")

print("[7] Tiến hành repack vào data.xp3 của game...")
repack_cmd = [str(USER_PYTHON), str(REPACK_SCRIPT)]
res = subprocess.run(repack_cmd, capture_output=True, text=True)
print(res.stdout)
if res.returncode != 0:
    print("[-] Lỗi repack:", res.stderr)
else:
    print("[+] Hoàn tất đóng gói toàn diện vào game!")
