import sys
from pathlib import Path

sys.path.insert(0, r"E:\Extract Tools\cxdec-hxv4\src\common")
from xp3_inspect import read_archive

_, entries, _ = read_archive(Path(r"E:\Games\COCORO.FIXED\game\data.xp3.original.bak"))
for i in range(1948, 1990):
    if i < len(entries):
        print(f"Entry {i:05d}: {entries[i].name}")
