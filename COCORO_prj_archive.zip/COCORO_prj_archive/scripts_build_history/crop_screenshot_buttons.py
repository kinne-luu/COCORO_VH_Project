from PIL import Image

im = Image.open(r"C:\Users\ADMIN\.gemini\antigravity\brain\6b02dd57-4279-4cd4-9c69-1295e15a34fe\.user_uploaded\media_1795387234991_5ce0a5dd.jpg")

# Nút 1: y từ 70 đến 145
btn1 = im.crop((40, 70, 300, 145))
btn1.save("screenshot_btn1.png")

# Nút 2: y từ 145 đến 220
btn2 = im.crop((40, 145, 300, 220))
btn2.save("screenshot_btn2.png")

# Nút 3: y từ 220 đến 295
btn3 = im.crop((40, 220, 300, 295))
btn3.save("screenshot_btn3.png")

print("Saved screenshot_btn1, 2, 3!")
