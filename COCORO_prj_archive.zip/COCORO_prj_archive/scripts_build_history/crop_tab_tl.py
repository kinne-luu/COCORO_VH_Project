from PIL import Image

im = Image.open("image/UI_Raw/entry_01948_579b.png").convert("RGBA")
print("1948 size:", im.size)

# Crop góc trên bên trái
crop_tl = im.crop((0, 0, 400, 100))
crop_tl.save("tab_base_tl.png")
print("Saved tab_base_tl.png!")
