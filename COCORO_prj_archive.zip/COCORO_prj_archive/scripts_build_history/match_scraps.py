from PIL import Image
import numpy as np
from pathlib import Path

# Đọc các mẩu rác
scraps = {
    "r2_bgm": Image.open("user_scrap_r2_bgm.png").convert("RGB"),
    "r3_down": Image.open("user_scrap_r3_down.png").convert("RGB"),
    "r4_se": Image.open("user_scrap_r4_se.png").convert("RGB"),
    "r5_movie": Image.open("user_scrap_r5_movie.png").convert("RGB"),
}

# Quét trong:
search_files = [
    Path("orig_fresh/entry_01977.png"),
    Path("orig_fresh/entry_01979.png"),
    Path("orig_fresh/entry_01986.png"),
    Path("orig_fresh/entry_01988.png"),
    Path("orig_fresh/entry_01950.png"),
    Path("orig_fresh/entry_01970.png"),
    Path("temp_cur_01977.png"),
    Path("temp_check_01975.png"),
    Path("COCORO_Patch_VietHoa/patch_data/ui/entry_01977.bin"), # if png available
]

for sname, sim in scraps.items():
    sarr = np.array(sim)
    sh, sw, _ = sarr.shape
    # Tìm pixel không phải màu nền (màu nền là xanh nhạt > 220)
    fg_mask = ~((sarr[:, :, 0] > 220) & (sarr[:, :, 1] > 235) & (sarr[:, :, 2] > 235))
    fg_pixels = sarr[fg_mask]
    if len(fg_pixels) == 0: continue
    
    print(f"\n--- Searching for {sname} (shape {sw}x{sh}, fg {len(fg_pixels)}) ---")
    
    for fpath in search_files:
        if not fpath.exists() or not fpath.suffix == ".png": continue
        aim = Image.open(fpath).convert("RGBA")
        aarr = np.array(aim)
        ah, aw, _ = aarr.shape
        if aw < sw or ah < sh: continue
        
        # Test rotations: 0, 90, 180, 270
        for rot in [0, 90, 180, 270]:
            if rot == 0:
                t_arr = aarr
            elif rot == 90:
                t_arr = np.rot90(aarr, 1)
            elif rot == 180:
                t_arr = np.rot90(aarr, 2)
            elif rot == 270:
                t_arr = np.rot90(aarr, 3)
            
            th, tw, _ = t_arr.shape
            if tw < sw or th < sh: continue
            
            # Subsample scan
            # Check center pixel of scrap
            cy, cx = sh // 2, sw // 2
            cpix = sarr[cy, cx]
            
            # Find candidate positions in t_arr
            matches = (np.abs(t_arr[:, :, 0].astype(int) - cpix[0]) < 10) & \
                      (np.abs(t_arr[:, :, 1].astype(int) - cpix[1]) < 10) & \
                      (np.abs(t_arr[:, :, 2].astype(int) - cpix[2]) < 10) & \
                      (t_arr[:, :, 3] > 200)
            
            cand_y, cand_x = np.where(matches)
            for py, px in zip(cand_y, cand_x):
                y0 = py - cy
                x0 = px - cx
                if 0 <= y0 and y0 + sh <= th and 0 <= x0 and x0 + sw <= tw:
                    sub = t_arr[y0:y0+sh, x0:x0+sw]
                    # check fg diff
                    diff = np.mean(np.abs(sub[:, :, :3][fg_mask].astype(int) - sarr[fg_mask].astype(int)))
                    if diff < 15:
                        print(f"MATCH FOUND in {fpath.name} (rot={rot}) at x={x0}, y={y0}, diff={diff:.2f}")
                        break
