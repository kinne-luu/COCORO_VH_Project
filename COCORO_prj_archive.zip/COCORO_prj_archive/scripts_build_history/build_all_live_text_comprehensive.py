# -*- coding: utf-8 -*-
"""
Tự động tạo Live Text Layer (chữ sống) cho TẤT CẢ các file PSD có:
- Chữ có màu (không phải màu trắng, e.g. màu tối, xám, màu thương hiệu)
- Chữ có hiệu ứng bloom (phát sáng, neon, hover, active)
Lưu vào thư mục riêng: D:\Workspace\Creative\2D\Projects\Photoshop\COCORO Prj\wireframe_guide\01_PSD_Live_Text_Chinh_Sua\
"""

import sys
import shutil
import win32com.client
from pathlib import Path

BASE_DIR = Path(r"D:\Workspace\Creative\2D\Projects\Photoshop\COCORO Prj\wireframe_guide")
SRC_DIR = BASE_DIR / "01_PSD_Chinh_Sua_Hieu_Ung"
OUT_DIR = BASE_DIR / "01_PSD_Live_Text_Chinh_Sua"
OUT_DIR.mkdir(parents=True, exist_ok=True)

print("=" * 70)
print("   BẮT ĐẦU TẠO LIVE TEXT CHO TOÀN BỘ CÁC FILE PSD CÓ MÀU & BLOOM   ")
print("=" * 70)

ps = win32com.client.Dispatch("Photoshop.Application")
ps.DisplayDialogs = 3         # 3 = psDisplayNoDialogs (QUAN TRỌNG: Không block dialog)
ps.Preferences.RulerUnits = 1 # 1 = psPixels
ps.Preferences.TypeUnits  = 1 # 1 = psPoints

def make_color(hex_str):
    c = win32com.client.Dispatch("Photoshop.SolidColor")
    c.RGB.HexValue = hex_str
    return c

def add_live_text(parent_group, text, x, y, size_pt, hex_color, justification=2, font_name="STIXTwoText-Bold"):
    layer = parent_group.ArtLayers.Add()
    layer.Name = f"[LiveText] {text}"
    layer.Kind = 2 # psTextLayer
    ti = layer.TextItem
    ti.Contents = text
    try:
        ti.Font = font_name
    except:
        ti.Font = "TimesNewRomanPS-BoldMT"
    ti.Size = size_pt
    ti.Position = [x, y]
    ti.Justification = justification # 2 = psCenter, 1 = psLeft
    ti.Color = make_color(hex_color)
    return layer

# ======================================================================
# 1. BACKLOG (backlog_template_guide.psd)
# ======================================================================
print("\n[1/8] Tạo Live Text cho Backlog...")
src_p = SRC_DIR / "backlog_template_guide.psd"
out_p = OUT_DIR / "backlog_template_guide.psd"
if src_p.exists():
    doc = ps.Open(str(src_p))
    grp_hov = doc.LayerSets.Add()
    grp_hov.Name = "[LIVE_TEXT_HOVER_BLOOM] (Chữ Sống Sáng)"
    grp_norm = doc.LayerSets.Add()
    grp_norm.Name = "[LIVE_TEXT_NORMAL] (Chữ Sống Thường)"
    
    # Normal (xám #373737)
    add_live_text(grp_norm, "TRỞ LẠI",  80,  67, 20, "373737", 2)
    add_live_text(grp_norm, "CHẾ ĐỘ 1", 80, 182, 20, "373737", 2)
    add_live_text(grp_norm, "CHẾ ĐỘ 2", 360, 182, 20, "373737", 2)
    add_live_text(grp_norm, "CHẾ ĐỘ 3", 220, 297, 20, "373737", 2)
    
    # Hover / Active (trắng #FFFFFF)
    add_live_text(grp_hov, "TRỞ LẠI (Active)", 220,  67, 20, "FFFFFF", 2)
    add_live_text(grp_hov, "TRỞ LẠI (Hover)",  360,  67, 20, "FFFFFF", 2)
    add_live_text(grp_hov, "CHẾ ĐỘ 1 (Active)", 220, 182, 20, "FFFFFF", 2)
    add_live_text(grp_hov, "CHẾ ĐỘ 2 (Active)",  80, 297, 20, "FFFFFF", 2)
    add_live_text(grp_hov, "CHẾ ĐỘ 3 (Hover)",  360, 297, 20, "FFFFFF", 2)
    
    doc.SaveAs(str(out_p))
    doc.Close(2)
    print(f"   + Đã xuất: {out_p.name}")

# ======================================================================
# 2. FILE LOAD (file_load_template_guide.psd)
# ======================================================================
print("\n[2/8] Tạo Live Text cho File Load...")
src_p = SRC_DIR / "file_load_template_guide.psd"
out_p = OUT_DIR / "file_load_template_guide.psd"
if src_p.exists():
    doc = ps.Open(str(src_p))
    grp_hov = doc.LayerSets.Add()
    grp_hov.Name = "[LIVE_TEXT_HOVER_BLOOM] (Chữ Sống Sáng)"
    grp_norm = doc.LayerSets.Add()
    grp_norm.Name = "[LIVE_TEXT_NORMAL] (Chữ Sống Thường)"
    
    # Normal
    add_live_text(grp_norm, "TRỞ LẠI",    105,  57, 22, "373737", 2)
    add_live_text(grp_norm, "XÓA",        105, 157, 22, "373737", 2)
    add_live_text(grp_norm, "XÓA TẤT CẢ", 105, 257, 22, "373737", 2)
    
    # Hover
    add_live_text(grp_hov, "TRỞ LẠI",    300,  57, 22, "FFFFFF", 2)
    add_live_text(grp_hov, "XÓA",        300, 157, 22, "FFFFFF", 2)
    add_live_text(grp_hov, "XÓA TẤT CẢ", 300, 257, 22, "FFFFFF", 2)
    
    doc.SaveAs(str(out_p))
    doc.Close(2)
    print(f"   + Đã xuất: {out_p.name}")

# ======================================================================
# 3. FILE SAVE (file_save_template_guide.psd)
# ======================================================================
print("\n[3/8] Tạo Live Text cho File Save...")
src_p = SRC_DIR / "file_save_template_guide.psd"
out_p = OUT_DIR / "file_save_template_guide.psd"
if src_p.exists():
    doc = ps.Open(str(src_p))
    grp_hov = doc.LayerSets.Add()
    grp_hov.Name = "[LIVE_TEXT_HOVER_BLOOM] (Chữ Sống Sáng)"
    grp_norm = doc.LayerSets.Add()
    grp_norm.Name = "[LIVE_TEXT_NORMAL] (Chữ Sống Thường)"
    
    # Normal
    add_live_text(grp_norm, "TRỞ LẠI",    105,  57, 22, "373737", 2)
    add_live_text(grp_norm, "XÓA",        105, 157, 22, "373737", 2)
    add_live_text(grp_norm, "XÓA TẤT CẢ", 105, 257, 22, "373737", 2)
    
    # Hover
    add_live_text(grp_hov, "TRỞ LẠI",    300,  57, 22, "FFFFFF", 2)
    add_live_text(grp_hov, "XÓA",        300, 157, 22, "FFFFFF", 2)
    add_live_text(grp_hov, "XÓA TẤT CẢ", 300, 257, 22, "FFFFFF", 2)
    
    doc.SaveAs(str(out_p))
    doc.Close(2)
    print(f"   + Đã xuất: {out_p.name}")

# ======================================================================
# 4. GALLERY (gallery_template_guide.psd)
# ======================================================================
print("\n[4/8] Tạo Live Text cho Gallery...")
src_p = SRC_DIR / "gallery_template_guide.psd"
out_p = OUT_DIR / "gallery_template_guide.psd"
if src_p.exists():
    doc = ps.Open(str(src_p))
    grp_hov = doc.LayerSets.Add()
    grp_hov.Name = "[LIVE_TEXT_HOVER_BLOOM] (Chữ Sống Sáng)"
    grp_norm = doc.LayerSets.Add()
    grp_norm.Name = "[LIVE_TEXT_NORMAL] (Chữ Sống Thường)"
    
    add_live_text(grp_norm, "TRỞ LẠI", 105, 62, 22, "373737", 2)
    add_live_text(grp_hov,  "TRỞ LẠI", 300, 62, 22, "FFFFFF", 2)
    
    doc.SaveAs(str(out_p))
    doc.Close(2)
    print(f"   + Đã xuất: {out_p.name}")

# ======================================================================
# 5. DIALOG TEMPLATE (dialog_template_guide.psd)
# ======================================================================
print("\n[5/8] Tạo Live Text cho Dialog Template (Nút & 15 Dòng Thông Báo)...")
src_p = SRC_DIR / "dialog_template_guide.psd"
out_p = OUT_DIR / "dialog_template_guide.psd"
if src_p.exists():
    doc = ps.Open(str(src_p))
    grp_txt = doc.LayerSets.Add()
    grp_txt.Name = "[LIVE_TEXT_THONG_BAO] (15 Dòng Thông Báo)"
    grp_hov = doc.LayerSets.Add()
    grp_hov.Name = "[LIVE_TEXT_HOVER_BLOOM] (Nút Sáng)"
    grp_norm = doc.LayerSets.Add()
    grp_norm.Name = "[LIVE_TEXT_NORMAL] (Nút Thường)"
    
    # Nút Normal
    add_live_text(grp_norm, "CÓ",            115,  55, 22, "373737", 2)
    add_live_text(grp_norm, "KHÔNG",         495,  55, 22, "373737", 2)
    add_live_text(grp_norm, "Không hỏi lại", 210, 142, 18, "373737", 2)
    
    # Nút Hover
    add_live_text(grp_hov, "CÓ",            305,  57, 22, "FFFFFF", 2)
    add_live_text(grp_hov, "KHÔNG",         685,  57, 22, "FFFFFF", 2)
    add_live_text(grp_hov, "Không hỏi lại", 590, 142, 18, "FFFFFF", 2)
    
    # 15 Dòng thông báo
    prompts = [
        ("Xác nhận xóa toàn bộ dữ liệu?",      215),
        ("Khôi phục toàn bộ thiết lập?",       289),
        ("Trở về lựa chọn trước?",             363),
        ("Xóa file lưu này?",                  437),
        ("Thoát khỏi trò chơi?",               511),
        ("Khôi phục cài đặt mặc định?",        585),
        ("Nhảy tới cảnh này?",                 659),
        ("Tải dữ liệu đã lưu?",                733),
        ("Tới lựa chọn kế tiếp?",              807),
        ("Tới cảnh tiếp theo?",                881),
        ("Ghi đè lên file lưu này?",           955),
        ("Về cảnh trước đó?",                 1029),
        ("Tải bản lưu nhanh?",                1103),
        ("Lưu nhanh dữ liệu?",                1177),
        ("Trở về màn hình chính?",            1251),
    ]
    for text, y in prompts:
        add_live_text(grp_txt, text, 310, y, 20, "32373C", 2)
        
    doc.SaveAs(str(out_p))
    doc.Close(2)
    print(f"   + Đã xuất: {out_p.name}")

# ======================================================================
# 6. CONFIG P4 VOICE (config_p4_template_guide.psd)
# ======================================================================
print("\n[6/8] Tạo Live Text cho Config P4 (Voice 9 Nhân Vật & Nút Bật/Tắt)...")
src_p = SRC_DIR / "config_p4_template_guide.psd"
out_p = OUT_DIR / "config_p4_template_guide.psd"
if src_p.exists():
    doc = ps.Open(str(src_p))
    grp_btn = doc.LayerSets.Add()
    grp_btn.Name = "[LIVE_TEXT_ON_OFF] (Nút Bật/Tắt Voice)"
    grp_chars = doc.LayerSets.Add()
    grp_chars.Name = "[LIVE_TEXT_NHAN_VAT] (9 Tên Nhân Vật)"
    
    char_names = [
        "Phụ", "Khác", "Raita", "Kotaro", "Gensei", "Sousei", "Kagura", "Yuito", "Shinra"
    ]
    for idx, name in enumerate(char_names):
        cy = 50 + idx * 58
        add_live_text(grp_chars, name, 250, cy, 24, "32373C", 1)
        
    # Nút BẬT / TẮT
    add_live_text(grp_btn, "TẮT", 450,  60, 20, "373737", 2)
    add_live_text(grp_btn, "BẬT", 550,  60, 20, "373737", 2)
    add_live_text(grp_btn, "TẮT (Sáng)", 450, 130, 20, "FFFFFF", 2)
    add_live_text(grp_btn, "BẬT (Sáng)", 550, 130, 20, "FFFFFF", 2)
    
    doc.SaveAs(str(out_p))
    doc.Close(2)
    print(f"   + Đã xuất: {out_p.name}")

# ======================================================================
# 7. CONFIG P3 SOUND (config_p3_template_guide.psd)
# ======================================================================
print("\n[7/8] Tạo Live Text cho Config P3 (Sound)...")
src_p = SRC_DIR / "config_p3_template_guide.psd"
out_p = OUT_DIR / "config_p3_template_guide.psd"
if src_p.exists():
    doc = ps.Open(str(src_p))
    grp_btn = doc.LayerSets.Add()
    grp_btn.Name = "[LIVE_TEXT_ON_OFF] (Nút Bật/Tắt)"
    grp_lbl = doc.LayerSets.Add()
    grp_lbl.Name = "[LIVE_TEXT_NHAN_AM_THANH] (8 Nhãn Âm Thanh)"
    
    sound_items = [
        "Chế độ Downmix", "Ngắt giọng khi bấm qua", "Giọng hệ thống", 
        "Âm lượng phim", "Hiệu ứng âm thanh", "Nhạc nền", "Lời thoại", "Âm lượng tổng"
    ]
    for idx, lbl in enumerate(sound_items):
        cy = 50 + idx * 60
        add_live_text(grp_lbl, lbl, 50, cy, 26, "32373C", 1)
        
    add_live_text(grp_btn, "TẮT", 650,  70, 22, "373737", 2)
    add_live_text(grp_btn, "BẬT", 780,  70, 22, "373737", 2)
    add_live_text(grp_btn, "TẮT (Sáng)", 650, 150, 22, "FFFFFF", 2)
    add_live_text(grp_btn, "BẬT (Sáng)", 780, 150, 22, "FFFFFF", 2)
    
    doc.SaveAs(str(out_p))
    doc.Close(2)
    print(f"   + Đã xuất: {out_p.name}")

# ======================================================================
# 8. GAME SIDE MENU (game_side_template_guide.psd)
# ======================================================================
print("\n[8/8] Tạo Live Text cho Game Side (In-game Quick Menu)...")
src_p = SRC_DIR / "game_side_template_guide.psd"
out_p = OUT_DIR / "game_side_template_guide.psd"
if src_p.exists():
    doc = ps.Open(str(src_p))
    grp_hov = doc.LayerSets.Add()
    grp_hov.Name = "[LIVE_TEXT_HOVER_BLOOM] (Nút Khi Rê Chuột / Sáng)"
    grp_norm = doc.LayerSets.Add()
    grp_norm.Name = "[LIVE_TEXT_NORMAL] (Nút Thường)"
    
    # Các nút ngang
    side_buttons_h = [
        ("TỰ ĐỘNG",     231,  80),
        ("TẢI",         992, 177),
        ("NHẬT KÝ",     231, 375),
        ("HƯỚNG DẪN",   638, 474),
        ("TIẾP",        231, 672),
        ("HỆ THỐNG",    638, 771),
        ("TẢI NHANH",   231, 969),
        ("LƯU NHANH",   638, 1068),
        ("LÙI",         231, 1933),
    ]
    for text, cx, cy in side_buttons_h:
        add_live_text(grp_norm, text, cx, cy, 22, "FFFFFF", 2)
        add_live_text(grp_hov,  text, cx, cy, 22, "FFFFFF", 2)
        
    doc.SaveAs(str(out_p))
    doc.Close(2)
    print(f"   + Đã xuất: {out_p.name}")

# Copy bất kỳ file nào còn lại sang OUT_DIR để đảm bảo 100% đầy đủ
for f in SRC_DIR.glob("*.psd"):
    dst = OUT_DIR / f.name
    if not dst.exists():
        shutil.copy2(f, dst)

print("\n" + "=" * 70)
print("   HOÀN TẤT 100% TẤT CẢ FILE PSD CÓ CHỨA LIVE TEXT CHỮ SỐNG!   ")
print("=" * 70)
