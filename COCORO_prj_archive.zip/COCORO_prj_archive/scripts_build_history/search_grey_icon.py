import subprocess
from pathlib import Path
from PIL import Image
import numpy as np

# 1. Lấy mẩu xám từ ảnh user
user_img = Image.open(r"C:\Users\ADMIN\.gemini\antigravity\brain\6b02dd57-4279-4cd4-9c69-1295e15a34fe\.user_uploaded\media_1795402114054_6050186b.jpg").convert("RGB")
arr_user = np.array(user_img)
# Mẩu xám ở hàng 2: y 195..240, x 100..130
sample_grey = arr_user[200:235, 105:125]
print("Sample grey shape:", sample_grey.shape)

# 2. Tìm trong tất cả các file TLG trong extracted_data/data từ 1900 đến 2200
msg_tool = Path("tools/msg-tool/msg_tool.exe")
ext_dir = Path("extracted_data/data")
temp_dir = Path("temp_tlg_search")
temp_dir.mkdir(exist_ok=True)

# Export tất cả TLG trong dải đó
tlg_files = []
for p in sorted(ext_dir.glob("entry_*.bin")):
    idx = int(p.name.split("_")[1])
    if 1930 <= idx <= 2170:
        b = p.read_bytes()[:8]
        if b.startswith(b"TLG"):
            tlg_files.append((idx, p))

print(f"Total TLG files to search: {len(tlg_files)}")

# Quét từng file
found = []
for idx, p in tlg_files:
    png_path = temp_dir / f"entry_{idx:05d}.png"
    if not png_path.exists():
        res = subprocess.run([str(msg_tool), "export", "-t", "kirikiri-tlg", str(p), str(png_path)], capture_output=True)
        if res.returncode != 0:
            continue
    try:
        im = Image.open(png_path).convert("RGBA")
        arr = np.array(im)
        # Check if there are grey pixels similar to sample_grey
        # sample_grey is ~[138, 149, 153]
        # In the original atlas, background was magenta [255, 0, 255] or transparent
        # Look for cluster of grey pixels [130..150, 140..160, 145..165]
        m = (arr[:, :, 0] >= 120) & (arr[:, :, 0] <= 155) & (arr[:, :, 1] >= 130) & (arr[:, :, 1] <= 165) & (arr[:, :, 2] >= 135) & (arr[:, :, 2] <= 170) & (arr[:, :, 3] > 100)
        cnt = np.sum(m)
        if cnt > 100:
            print(f"Entry {idx:05d} ({png_path.name}) has {cnt} grey pixels! Size: {im.size}")
            found.append(idx)
    except Exception as e:
        pass

print("Done! Found entries:", found)
