import json

d = json.load(open('temp_pbd_dumps/entry_01941_5794.json', encoding='utf-8'))
packlist = d['packlist']
print(f"Packlist total: {len(packlist)}")
for i, item in enumerate(packlist):
    print(f"  {i:2d}: {item}")
