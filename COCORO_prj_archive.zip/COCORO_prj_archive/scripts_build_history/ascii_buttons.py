from PIL import Image

# Resize nhỏ hiển thị ascii art của screenshot_btn1 và screenshot_btn2
for bname in ["screenshot_btn1.png", "screenshot_btn2.png"]:
    im = Image.open(bname).convert("L")
    im = im.resize((60, 15))
    print(f"=== ASCII ART OF {bname} ===")
    for y in range(im.height):
        line = ""
        for x in range(im.width):
            p = im.getpixel((x, y))
            if p > 180: line += "#"
            elif p > 100: line += "+"
            elif p > 50: line += "."
            else: line += " "
        print(line)
