import os
from pathlib import Path

targets = ["Load this save", "Don't ask", "Save this", "Overwrite"]

print("Scanning extracted_data and temp_pbd_dumps...")
for root, dirs, files in os.walk(r"D:\Software\Antigravity\Project\Cocoro"):
    if ".git" in root or "node_modules" in root or "brain" in root: continue
    for f in files:
        if f.endswith((".json", ".tjs", ".ks", ".csv", ".txt")):
            p = Path(root) / f
            try:
                txt = p.read_text(encoding="utf-8", errors="ignore")
                for t in targets:
                    if t.lower() in txt.lower():
                        print(f"Found '{t}' in {p.relative_to(r'D:\Software\Antigravity\Project\Cocoro')}")
            except Exception as e:
                pass
