# -*- coding: utf-8 -*-
"""
Sửa dứt điểm lỗi chữ 'MỞ RỘNG' bị cắt chữ G:
1. Đặt w = 160, cw = 160 cho nút extra
2. Font STIX Two Text Bold cỡ 25 (chiều rộng chữ ~126px, padding mỗi bên 17px rộng rãi, không bị clip)
3. ox = 0, oy = 4 đồng nhất cho cả normal và hover (triệt tiêu hoàn toàn lỗi hover bị nhảy lệch)
4. Đặt x = 1188 để giữ tâm nút tại x = 1268 (cân xứng tuyệt đối trên dải trắng)
5. Xuất PSD layered vào wireframe_guide/title_template_guide.psd (xếp gọn nhóm layer để người dùng dễ đổi màu/hiệu ứng)
6. Biên dịch entry_02161.bin và entry_02165.bin
"""

import sys
import json
import shutil
import subprocess
from pathlib import Path
import numpy as np
from PIL import Image, ImageDraw, ImageFont, ImageFilter
import pytoshop
from pytoshop.user import nested_layers

ROOT_DIR = Path(r"D:\Software\Antigravity\Project\Cocoro")
GUIDE_DIR = Path(r"D:\Workspace\Creative\2D\Projects\Photoshop\COCORO Prj\wireframe_guide")
GUIDE_DIR.mkdir(parents=True, exist_ok=True)
MSG_TOOL = ROOT_DIR / "tools" / "msg-tool" / "msg_tool.exe"
PATCH_UI_DIR = ROOT_DIR / "COCORO_Patch_VietHoa" / "patch_data" / "ui"
PATCH_PBD_DIR = ROOT_DIR / "COCORO_Patch_VietHoa" / "patch_data" / "pbd"
TLG_MSGTOOL_DIR = ROOT_DIR / "tlg_msgtool"

FONT_PATH = Path(r"C:\Users\ADMIN\AppData\Local\Microsoft\Windows\Fonts\STIXTwoText-Bold.ttf")
if not FONT_PATH.exists():
    FONT_PATH = Path(r"C:\Windows\Fonts\timesbd.ttf")

SMALL_FONT = ImageFont.truetype(str(FONT_PATH), 11)

RAW_ATLAS_TITLE = ROOT_DIR / "image" / "UI_Raw" / "entry_02165_5874.png"
PBD_ORIG_JSON = ROOT_DIR / "temp_pbd_dumps" / "entry_02161_5870.json"
PBD_ORIG_BIN = ROOT_DIR / "orig_fresh" / "entry_02161.bin"
if not PBD_ORIG_BIN.exists():
    PBD_ORIG_BIN = ROOT_DIR / "extracted_data" / "data" / "entry_02161_5870.bin"

raw_title_img = Image.open(RAW_ATLAS_TITLE).convert("RGBA")

CANVAS_W = 650
CANVAS_H = 780
COL1_X = 90   # Normal column
COL2_X = 350  # Hover column
START_Y = 30
ROW_STEP = 64
BOX_H = 48
BASELINE_OFFSET_Y = 34

TITLE_BUTTONS = {
    "cont":    {"row": 0, "w": 191, "h": 53, "cw": 191, "ch": BOX_H, "text": "TIẾP TỤC", "font_size": 26},
    "start":   {"row": 1, "w": 140, "h": 53, "cw": 140, "ch": BOX_H, "text": "BẮT ĐẦU",  "font_size": 26},
    "load":    {"row": 2, "w": 125, "h": 53, "cw": 125, "ch": BOX_H, "text": "TẢI",      "font_size": 26},
    "option":  {"row": 3, "w": 164, "h": 53, "cw": 164, "ch": BOX_H, "text": "TÙY CHỌN", "font_size": 26},
    "extra":   {"row": 4, "w": 160, "h": 53, "cw": 160, "ch": BOX_H, "text": "MỞ RỘNG",  "font_size": 25},
    "exit":    {"row": 5, "w": 115, "h": 53, "cw": 115, "ch": BOX_H, "text": "THOÁT",    "font_size": 26},
    "gallery": {"row": 6, "w": 170, "h": 53, "cw": 170, "ch": BOX_H, "text": "THƯ VIỆN", "font_size": 26},
    "music":   {"row": 7, "w": 140, "h": 53, "cw": 140, "ch": BOX_H, "text": "NHẠC",     "font_size": 26},
    "after":   {"row": 8, "w": 160, "h": 53, "cw": 160, "ch": BOX_H, "text": "AFTER",    "font_size": 26},
    "credits": {"row": 9, "w": 142, "h": 53, "cw": 142, "ch": BOX_H, "text": "ĐỘI NGŨ",  "font_size": 26},
    "back":    {"row": 10,"w": 130, "h": 53, "cw": 130, "ch": BOX_H, "text": "TRỞ LẠI",  "font_size": 26}
}

SLICE_INDEX_MAP = {
    0:  ("after",   "off"),
    1:  ("after",   "hover"),
    2:  ("back",    "off"),
    3:  ("back",    "hover"),
    4:  ("cont",    "off"),
    5:  ("cont",    "hover"),
    6:  ("copyright", None),
    7:  ("credits", "off"),
    8:  ("credits", "hover"),
    9:  ("exit",    "off"),
    10: ("exit",    "hover"),
    11: ("extra",   "off"),
    12: ("extra",   "hover"),
    13: ("gallery", "off"),
    14: ("gallery", "hover"),
    15: ("load",    "off"),
    16: ("load",    "hover"),
    17: ("music",   "off"),
    18: ("music",   "hover"),
    19: ("new",     None),
    20: ("option",  "off"),
    21: ("option",  "hover"),
    22: ("start",   "off"),
    23: ("start",   "hover"),
}

def render_button_pair_baseline(text, cw, ch, font_size=26):
    font = ImageFont.truetype(str(FONT_PATH), font_size)
    dummy = Image.new("RGBA", (1, 1), (0, 0, 0, 0))
    d = ImageDraw.Draw(dummy)
    
    center_x = cw // 2
    base_y = BASELINE_OFFSET_Y
    
    bbox = d.textbbox((center_x, base_y), text, font=font, anchor="ms")
    
    # 1. Normal (Chữ tối màu thanh lịch)
    im_normal = Image.new("RGBA", (cw, ch), (0, 0, 0, 0))
    d_norm = ImageDraw.Draw(im_normal)
    d_norm.text((center_x, base_y), text, font=font, fill=(55, 55, 55, 255), anchor="ms")
    
    # 2. Hover (Chữ phát sáng xanh + gạch chân sắc nét)
    im_hover = Image.new("RGBA", (cw, ch), (0, 0, 0, 0))
    line_y = base_y + 4
    line_x0 = bbox[0] - 2
    line_x1 = bbox[2] + 2
    
    glow_img = Image.new("RGBA", (cw, ch), (0, 0, 0, 0))
    gd = ImageDraw.Draw(glow_img)
    glow_color = (0, 168, 255, 220)
    for ox in range(-2, 3):
        for oy in range(-2, 3):
            gd.text((center_x + ox, base_y + oy), text, font=font, fill=glow_color, anchor="ms")
            gd.line([(line_x0 + ox, line_y + oy), (line_x1 + ox, line_y + oy)], fill=glow_color, width=2)
            
    glow_img = glow_img.filter(ImageFilter.GaussianBlur(1.5))
    im_hover.paste(glow_img, (0, 0), glow_img)
    
    d_hov = ImageDraw.Draw(im_hover)
    d_hov.text((center_x, base_y), text, font=font, fill=(255, 255, 255, 255), anchor="ms")
    d_hov.line([(line_x0, line_y), (line_x1, line_y)], fill=(255, 255, 255, 255), width=2)
    
    return im_normal, im_hover

atlas_base = Image.new("RGBA", (CANVAS_W, CANVAS_H), (0, 0, 0, 0))
atlas_guide = Image.new("RGBA", (CANVAS_W, CANVAS_H), (0, 0, 0, 0))

cr_orig = raw_title_img.crop((0, 0, 52, 347))
nw_orig = raw_title_img.crop((289, 283, 289 + 23, 283 + 55))
atlas_base.paste(cr_orig, (10, 20))
atlas_base.paste(nw_orig, (10, 380))

normal_layers_dict = {}
hover_layers_dict = {}
title_slice_coords = {}

for name, b in TITLE_BUTTONS.items():
    row = b["row"]
    cw = b["cw"]
    ch = b["ch"]
    cy = START_Y + row * ROW_STEP
    text = b["text"]
    fsize = b["font_size"]
    
    norm_img, hov_img = render_button_pair_baseline(text, cw, ch, fsize)
    
    # 1. Normal
    cx1 = COL1_X
    atlas_base.paste(norm_img, (cx1, cy), norm_img)
    normal_layers_dict[f"{name}_normal"] = {"img": norm_img, "box": (cx1, cy, cx1 + cw, cy + ch), "text": f"{text} (Thường)"}
    
    # 2. Hover
    cx2 = COL2_X
    atlas_base.paste(hov_img, (cx2, cy), hov_img)
    hover_layers_dict[f"{name}_hover"] = {"img": hov_img, "box": (cx2, cy, cx2 + cw, cy + ch), "text": f"{text} (Gạch chân)"}
    
    title_slice_coords[name] = {
        "normal": (cx1, cy, cw, ch),
        "hover":  (cx2, cy, cw, ch),
        "w": b["w"],
        "h": b["h"]
    }

base_png_path = GUIDE_DIR / "title_atlas_base.png"
atlas_base.save(base_png_path)
atlas_base.save(ROOT_DIR / "image" / "UI_Da_Sua" / "entry_02165_5874.png")

# Tạo layered PSD
def pil_to_pytoshop_layer(pil_img, name, left, top):
    arr = np.array(pil_img)
    h, w = arr.shape[:2]
    return nested_layers.Image(
        name=name, top=top, left=left, bottom=top + h, right=left + w,
        channels={0: arr[:, :, 0], 1: arr[:, :, 1], 2: arr[:, :, 2], -1: arr[:, :, 3]}
    )

normal_sublayers = [pil_to_pytoshop_layer(v["img"], v["text"], v["box"][0], v["box"][1]) for k, v in normal_layers_dict.items()]
hover_sublayers  = [pil_to_pytoshop_layer(v["img"], v["text"], v["box"][0], v["box"][1]) for k, v in hover_layers_dict.items()]

group_normal = nested_layers.Group(name="[TEXT_NORMAL] (Chữ Tối Màu - Baseline Cân Bằng)", layers=normal_sublayers, closed=False)
group_hover  = nested_layers.Group(name="[TEXT_HOVER_UNDERLINE] (Chữ Sáng + Gạch Chân)", layers=hover_sublayers, closed=False)

cr_layer = pil_to_pytoshop_layer(cr_orig, "Copyright_Text", 10, 20)
nw_layer = pil_to_pytoshop_layer(nw_orig, "New_Badge", 10, 380)
group_base = nested_layers.Group(name="[BASE_ELEMENTS]", layers=[cr_layer, nw_layer], closed=True)

psd_obj = nested_layers.nested_layers_to_psd([group_hover, group_normal, group_base], color_mode=3, size=atlas_base.size, compression=0)
psd_file = GUIDE_DIR / "title_template_guide.psd"
with open(psd_file, "wb") as f:
    psd_obj.write(f)
print(f"   + Đã tạo PSD Title Menu chuyên nghiệp: {psd_file.name} ({psd_file.stat().st_size:,} bytes)!")

# Update PBD entry_02161
with open(PBD_ORIG_JSON, "r", encoding="utf-8") as f:
    pbd_data = json.load(f)

packlist = pbd_data.get("packlist", [])
packlist[6][0] = 10
packlist[6][1] = 20
packlist[6][2] = 52
packlist[6][3] = 347

packlist[19][0] = 10
packlist[19][1] = 380
packlist[19][2] = 23
packlist[19][3] = 55

for s_idx, (bname, st_type) in SLICE_INDEX_MAP.items():
    if bname in title_slice_coords:
        coords = title_slice_coords[bname]
        cx, cy, cw, ch = coords["normal"] if st_type == "off" else coords["hover"]
        packlist[s_idx][0] = cx
        packlist[s_idx][1] = cy
        packlist[s_idx][2] = cw
        packlist[s_idx][3] = ch
        if len(packlist[s_idx]) > 7:
            packlist[s_idx][7] = None

res = pbd_data.get("result", {})
for bname, coords in title_slice_coords.items():
    if bname in res:
        node = res[bname]
        st = node.get("uistates", {})
        w_node = coords["w"]
        node["w"] = w_node
        
        # Nếu là nút extra (MỞ RỘNG), đặt x = 1188 để giữ tâm nút tại x = 1268
        if bname == "extra":
            node["x"] = 1188
            
        cw_norm = coords["normal"][2]
        ch_norm = coords["normal"][3]
        ox_norm = (w_node - cw_norm) // 2
        
        cw_hov = coords["hover"][2]
        ch_hov = coords["hover"][3]
        ox_hov = (w_node - cw_hov) // 2
        
        # 1. Trạng thái bình thường (off)
        if "off" in st:
            st["off"].update({
                "cx": coords["normal"][0], "cy": coords["normal"][1],
                "cw": cw_norm, "ch": ch_norm,
                "w": cw_norm, "h": ch_norm,
                "ox": ox_norm, "oy": 4, "cr": None
            })
            
        # 2. Trạng thái active (on)
        if "on" in st:
            st["on"].update({
                "cx": coords["hover"][0], "cy": coords["hover"][1],
                "cw": cw_hov, "ch": ch_hov,
                "w": cw_hov, "h": ch_hov,
                "ox": ox_hov, "oy": 4, "cr": None
            })
            
        # 3. Trạng thái rê chuột (over)
        if "over" in st:
            st["over"].update({
                "cx": coords["hover"][0], "cy": coords["hover"][1],
                "cw": cw_hov, "ch": ch_hov,
                "w": cw_hov, "h": ch_hov,
                "ox": ox_hov, "oy": 4, "cr": None
            })

temp_pbd_synced = Path("temp_title_pbd_synced.json")
with open(temp_pbd_synced, "w", encoding="utf-8") as f:
    json.dump(pbd_data, f, indent=2, ensure_ascii=False)

out_pbd_bin = PATCH_PBD_DIR / "entry_02161.bin"
cmd_pbd = [str(MSG_TOOL), "import", "-t", "kirikiri-tjs-ns0", str(PBD_ORIG_BIN), str(temp_pbd_synced), str(out_pbd_bin)]
subprocess.run(cmd_pbd, check=True)
print(f"   + Đã xuất PBD Title Menu: {out_pbd_bin.name} ({out_pbd_bin.stat().st_size:,} bytes)!")

# Re-export TLG5
out_title_tlg = TLG_MSGTOOL_DIR / "entry_02165_5874.tlg"
cmd_tlg = [str(MSG_TOOL), "import", "-t", "kirikiri-tlg", str(ROOT_DIR / "extracted_data" / "data" / "entry_02165_5874.bin"), str(base_png_path), str(out_title_tlg)]
subprocess.run(cmd_tlg, check=True)
patch_title_tlg = PATCH_UI_DIR / "entry_02165.bin"
patch_title_tlg.write_bytes(out_title_tlg.read_bytes())
print(f"   + Đã xuất TLG5 Title Menu: {out_title_tlg.name} ({out_title_tlg.stat().st_size:,} bytes)!")
