# -*- coding: utf-8 -*-
"""
COCORO - Scale up and Vertically Center Language Selector Text
- Font size tăng lên 34 pt (chữ to rõ, sang trọng, hài hòa với setting labels)
- Chiều cao sprite 74px (chuẩn khít với node _lang height=74)
- Căn giữa tuyệt đối: top space = 25px, bottom space = 26px (hạ thấp đúng tâm mắt của người dùng)
- ox=78, oy=0: Đặt vừa vặn chính giữa khung trắng giữa 2 nút mũi tên
- Đồng bộ vào cả 2 atlas (entry_01950.bin & entry_01952.bin) và toàn bộ 6 file PBD Display
- Repack và mã hóa đối xứng HXV4 DripProgram nạp trực tiếp vào data.xp3
"""

import sys
import subprocess
import shutil
import json
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont
import numpy as np

ROOT_DIR = Path(r"D:\Software\Antigravity\Project\Cocoro")
MSG_TOOL = ROOT_DIR / "tools" / "msg-tool" / "msg_tool.exe"
EXT_DATA_DIR = ROOT_DIR / "extracted_data" / "data"
PATCH_UI_DIR = ROOT_DIR / "COCORO_Patch_VietHoa" / "patch_data" / "ui"
PATCH_PBD_DIR = ROOT_DIR / "COCORO_Patch_VietHoa" / "patch_data" / "pbd"
TLG_MSGTOOL_DIR = ROOT_DIR / "tlg_msgtool"

FONT_PATH = Path(r"C:\Users\ADMIN\AppData\Local\Microsoft\Windows\Fonts\STIXTwoText-Bold.ttf")
if not FONT_PATH.exists():
    FONT_PATH = Path(r"C:\Windows\Fonts\timesbd.ttf")

FONT_SIZE = 34
LABEL_FONT = ImageFont.truetype(str(FONT_PATH), FONT_SIZE)
TEXT_COLOR = (74, 74, 74, 255) # Màu chuẩn #4a4a4a

# Kích thước 480x74 tương ứng chuẩn xác với khung trắng và chiều cao node _lang (74px)
LANG_LABELS = {
    "text_en":   {"text": "ENGLISH",        "cx": 650, "cy": 500, "cw": 480, "ch": 74},
    "text_none": {"text": "OFF",            "cx": 650, "cy": 580, "cw": 480, "ch": 74},
    "text_jp":   {"text": "JAPANESE",       "cx": 650, "cy": 660, "cw": 480, "ch": 74},
    "text_cn":   {"text": "CHINESE (SIMP)", "cx": 650, "cy": 740, "cw": 480, "ch": 74},
    "text_tw":   {"text": "CHINESE (TRAD)", "cx": 650, "cy": 820, "cw": 480, "ch": 74},
    "text_kr":   {"text": "KOREAN",         "cx": 650, "cy": 900, "cw": 480, "ch": 74},
}

def render_selector_sprite(text, width=480, height=74):
    img = Image.new("RGBA", (width, height), (0, 0, 0, 0))
    draw = ImageDraw.Draw(img)
    bb = draw.textbbox((0, 0), text, font=LABEL_FONT)
    tw = bb[2] - bb[0]
    th = bb[3] - bb[1]
    tx = (width - tw) // 2 - bb[0]
    ty = (height - th) // 2 - bb[1]
    draw.text((tx, ty), text, font=LABEL_FONT, fill=TEXT_COLOR)
    return img

def main():
    print("=" * 70)
    print("   COCORO - NÂNG CỠ CHỮ VÀ HẠ THẤP ĐỂ CĂN GIỮA TUYỆT ĐỐI (SIZE 34)   ")
    print("=" * 70)

    # 1. CẬP NHẬT EN ATLAS (entry_01950)
    print("\n[1/4] Cập nhật sprite ngôn ngữ trong entry_01950.bin (EN Atlas)...")
    cur_1950_bin = PATCH_UI_DIR / "entry_01950.bin"
    cur_1950_png = Path("temp_1950_exp.png")
    subprocess.run([str(MSG_TOOL), "export", "-t", "kirikiri-tlg", str(cur_1950_bin), str(cur_1950_png)], check=True)
    orig_img_1950 = Image.open(cur_1950_png).convert("RGBA")

    # Mở rộng canvas lên 1250 x 980 để chứa thoải mái cả 6 sprite 480x74
    canvas_1950 = Image.new("RGBA", (1250, 980), (0, 0, 0, 0))
    canvas_1950.paste(orig_img_1950.crop((0, 0, 1250, min(orig_img_1950.height, 500))), (0, 0))

    for k, d in LANG_LABELS.items():
        spr = render_selector_sprite(d["text"], d["cw"], d["ch"])
        canvas_1950.paste(spr, (d["cx"], d["cy"]), spr)
        print(f"   + [EN] {k:10s} ('{d['text']}'): dán tại ({d['cx']}, {d['cy']}), size={d['cw']}x{d['ch']}")

    fixed_1950_png = Path("temp_1950_fixed.png")
    canvas_1950.save(fixed_1950_png)

    orig_1950_bin = list(EXT_DATA_DIR.glob("entry_01950_*.bin"))[0]
    out_1950_tlg = TLG_MSGTOOL_DIR / "entry_01950.tlg"
    subprocess.run([str(MSG_TOOL), "import", "-t", "kirikiri-tlg", str(orig_1950_bin), str(fixed_1950_png), str(out_1950_tlg)], check=True)
    shutil.copy2(out_1950_tlg, cur_1950_bin)
    print("   -> Đã biên dịch TLG thành công cho entry_01950.bin!")

    # 2. CẬP NHẬT JP ATLAS (entry_01952)
    print("\n[2/4] Cập nhật sprite ngôn ngữ trong entry_01952.bin (JP Atlas)...")
    cur_1952_bin = PATCH_UI_DIR / "entry_01952.bin"
    cur_1952_png = Path("temp_1952_exp.png")
    subprocess.run([str(MSG_TOOL), "export", "-t", "kirikiri-tlg", str(cur_1952_bin), str(cur_1952_png)], check=True)
    orig_img_1952 = Image.open(cur_1952_png).convert("RGBA")

    canvas_1952 = Image.new("RGBA", (1300, 980), (0, 0, 0, 0))
    canvas_1952.paste(orig_img_1952.crop((0, 0, 1300, min(orig_img_1952.height, 500))), (0, 0))

    for k, d in LANG_LABELS.items():
        spr = render_selector_sprite(d["text"], d["cw"], d["ch"])
        canvas_1952.paste(spr, (d["cx"], d["cy"]), spr)
        print(f"   + [JP] {k:10s} ('{d['text']}'): dán tại ({d['cx']}, {d['cy']}), size={d['cw']}x{d['ch']}")

    fixed_1952_png = Path("temp_1952_fixed.png")
    canvas_1952.save(fixed_1952_png)

    orig_1952_bin = list(EXT_DATA_DIR.glob("entry_01952_*.bin"))[0]
    out_1952_tlg = TLG_MSGTOOL_DIR / "entry_01952.tlg"
    subprocess.run([str(MSG_TOOL), "import", "-t", "kirikiri-tlg", str(orig_1952_bin), str(fixed_1952_png), str(out_1952_tlg)], check=True)
    shutil.copy2(out_1952_tlg, cur_1952_bin)
    print("   -> Đã biên dịch TLG thành công cho entry_01952.bin!")

    # 3. ĐỒNG BỘ CẢ 6 FILE PBD DISPLAY
    print("\n[3/4] Cập nhật uistates _lang trong cả 6 file PBD Display...")

    def build_lang_uistates(storage_name):
        st = {
            "hotspot": {
                "h": 48,
                "ox": 514,
                "oy": 25,
                "storage": "",
                "w": 48
            },
            "normal": {
                "ch": 74,
                "cw": 637,
                "cx": 0,
                "cy": 70,
                "h": 74,
                "ox": 0,
                "oy": 0,
                "storage": "config_page0__pack",
                "w": 637
            }
        }
        for k, d in LANG_LABELS.items():
            st[k] = {
                "ch": d["ch"],
                "cw": d["cw"],
                "cx": d["cx"],
                "cy": d["cy"],
                "h": d["ch"],
                "ox": 78,
                "oy": 0,
                "storage": storage_name,
                "w": d["cw"]
            }
        return st

    pbd_configs = [
        (1949, "config_page0_en__pack"),
        (1951, "config_page0_en__pack"),
        (1953, "config_page0_jp__pack"),
        (2072, "config_page0_en__pack"),
        (2073, "config_page0_en__pack"),
        (2075, "config_page0_jp__pack"),
    ]

    for pbd_idx, stg in pbd_configs:
        pbd_bin = PATCH_PBD_DIR / f"entry_{pbd_idx:05d}.bin"
        tmp_json = Path(f"temp_pbd_sync_{pbd_idx}.json")
        subprocess.run([str(MSG_TOOL), "export", "-t", "kirikiri-tjs-ns0", str(pbd_bin), str(tmp_json)], check=True)
        with open(tmp_json, "r", encoding="utf-8") as f:
            pbd_data = json.load(f)

        if "_lang" in pbd_data.get("result", {}):
            pbd_data["result"]["_lang"]["uistates"] = build_lang_uistates(stg)
            print(f"   + [PBD {pbd_idx}] Đã cập nhật _lang (size 480x74, ox=78, oy=0, center Y=37)")

        with open(tmp_json, "w", encoding="utf-8") as f:
            json.dump(pbd_data, f, indent=2, ensure_ascii=False)

        orig_pbd_bin = list(EXT_DATA_DIR.glob(f"entry_{pbd_idx:05d}_*.bin"))[0]
        subprocess.run([str(MSG_TOOL), "import", "-t", "kirikiri-tjs-ns0", str(orig_pbd_bin), str(tmp_json), str(pbd_bin)], check=True)
        print(f"   -> Đã recompile thành công entry_{pbd_idx:05d}.bin!")

    # 4. REPACK VÀO DATA.XP3
    print("\n[4/4] Chạy repack_viet_hoa_full.py đóng gói hoàn thiện vào data.xp3...")
    sys.stdout.flush()
    subprocess.run([sys.executable, "repack_viet_hoa_full.py"], check=True)

    print("\n" + "=" * 70)
    print("   HOÀN TẤT 100% CẬP NHẬT VÀ REPACK! GAME ĐÃ SẴN SÀNG!   ")
    print("=" * 70)

if __name__ == "__main__":
    main()
