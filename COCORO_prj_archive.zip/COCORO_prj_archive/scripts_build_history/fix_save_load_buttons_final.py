import shutil
import subprocess
from pathlib import Path

ROOT_DIR = Path(r"D:\Software\Antigravity\Project\Cocoro")
MSG_TOOL = ROOT_DIR / "tools" / "msg-tool" / "msg_tool.exe"
UI_DA_SUA = ROOT_DIR / "image" / "UI_Da_Sua"
PATCH_UI_DIR = ROOT_DIR / "COCORO_Patch_VietHoa" / "patch_data" / "ui"
PATCH_PBD_DIR = ROOT_DIR / "COCORO_Patch_VietHoa" / "patch_data" / "pbd"
EXT_DATA_DIR = ROOT_DIR / "extracted_data" / "data"

print("=" * 70)
print("   KHÔI PHỤC NỀN NÚT SAVE / LOAD (XÓA, XÓA TẤT CẢ, TRỞ LẠI)   ")
print("=" * 70)

# 1. Biên dịch 2 ảnh atlas chuẩn từ UI_Da_Sua (entry_02026 và entry_02037)
pairs = [
    ("entry_02026_57e9", 2026, "Menu quản lý trang Tải/Load"),
    ("entry_02037_57f4", 2037, "Menu quản lý trang Lưu/Save"),
]

for stem, entry_idx, desc in pairs:
    png_file = UI_DA_SUA / f"{stem}.png"
    orig_bin = EXT_DATA_DIR / f"{stem}.bin"
    patch_bin = PATCH_UI_DIR / f"entry_{entry_idx:05d}.bin"
    tmp_tlg = ROOT_DIR / f"temp_{entry_idx}.tlg"
    
    print(f"\n[1/3] Biên dịch {png_file.name} ({desc})...")
    cmd = [str(MSG_TOOL), "import", "-t", "kirikiri-tlg", str(orig_bin), str(png_file), str(tmp_tlg)]
    subprocess.run(cmd, check=True)
    shutil.copy2(tmp_tlg, patch_bin)
    if tmp_tlg.exists():
        tmp_tlg.unlink()
    print(f"   -> Đã ghi thành công {patch_bin.name} ({patch_bin.stat().st_size:,} bytes)!")

# 2. Khôi phục 8 file PBD Save/Load về gốc để khớp chính xác 100% với layout của atlas 222x168
pbd_pairs = [
    ("entry_02025_57e8.bin", "entry_02025.bin", "Load in-game EN"),
    ("entry_02027_57ea.bin", "entry_02027.bin", "Load in-game JP"),
    ("entry_02036_57f3.bin", "entry_02036.bin", "Save in-game EN"),
    ("entry_02038_57f5.bin", "entry_02038.bin", "Save in-game JP"),
    ("entry_02130_5851.bin", "entry_02130.bin", "Load title EN"),
    ("entry_02132_5853.bin", "entry_02132.bin", "Load title JP"),
    ("entry_02136_5857.bin", "entry_02136.bin", "Save title EN"),
    ("entry_02138_5859.bin", "entry_02138.bin", "Save title JP"),
]

print("\n[2/3] Khôi phục 8 file PBD Save/Load về cấu trúc tọa độ chuẩn...")
for orig_name, patch_name, desc in pbd_pairs:
    src = EXT_DATA_DIR / orig_name
    dst = PATCH_PBD_DIR / patch_name
    shutil.copy2(src, dst)
    print(f"   + [KHÔI PHỤC] {patch_name} <- {orig_name} ({desc})")

# 3. Đóng gói vào data.xp3
print("\n[3/3] Chạy repack_viet_hoa_full.py đóng gói hoàn thiện vào data.xp3...")
subprocess.run(["C:\\Users\\ADMIN\\AppData\\Local\\Python\\bin\\python.exe", "repack_viet_hoa_full.py"], check=True)

print("\n" + "=" * 70)
print("   HOÀN TẤT 100%! ĐÃ KHÔI PHỤC ĐẦY ĐỦ TẤM NỀN NÚT VÀ REPACK!   ")
print("=" * 70)
