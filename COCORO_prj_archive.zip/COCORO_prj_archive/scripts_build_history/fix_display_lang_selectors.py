# -*- coding: utf-8 -*-
"""
COCORO - Fix Missing Language Selector Sprites in Display Tab (entry_01950 & entry_01952)
1. Khôi phục hoàn toàn 6 sprite chữ lựa chọn ngôn ngữ:
   - text_en (ENGLISH)
   - text_none (OFF)
   - text_jp (JAPANESE)
   - text_cn (SIMPLIFIED CHINESE)
   - text_tw (TRADITIONAL CHINESE)
   - text_kr (KOREAN)
2. Loại bỏ sạch 100% pixel magenta padding để không sinh viền tím rác
3. Ghi đè vào entry_01950 (EN atlas) và entry_01952 (JP atlas)
4. Đồng bộ _lang node trong toàn bộ 6 file PBD Display:
   (entry_01949, entry_01951, entry_01953, entry_02072, entry_02073, entry_02075)
5. Repack toàn diện vào data.xp3
"""

import sys
import subprocess
import shutil
import json
from pathlib import Path
from PIL import Image
import numpy as np

ROOT_DIR = Path(r"D:\Software\Antigravity\Project\Cocoro")
MSG_TOOL = ROOT_DIR / "tools" / "msg-tool" / "msg_tool.exe"
FRESH_DIR = ROOT_DIR / "orig_fresh"
EXT_DATA_DIR = ROOT_DIR / "extracted_data" / "data"
PATCH_UI_DIR = ROOT_DIR / "COCORO_Patch_VietHoa" / "patch_data" / "ui"
PATCH_PBD_DIR = ROOT_DIR / "COCORO_Patch_VietHoa" / "patch_data" / "pbd"
TLG_MSGTOOL_DIR = ROOT_DIR / "tlg_msgtool"

def clean_magenta(im):
    arr = np.array(im)
    if len(arr.shape) >= 3 and arr.shape[2] >= 3:
        # Mask magenta pixels (R > 180, G < 60, B > 180)
        mask = (arr[:, :, 0] > 180) & (arr[:, :, 1] < 60) & (arr[:, :, 2] > 180)
        arr[mask] = [0, 0, 0, 0]
    return Image.fromarray(arr)

def main():
    print("=" * 70)
    print("   COCORO - FIX VÀ KHÔI PHỤC CHỮ LỰA CHỌN NGÔN NGỮ TRANG HIỂN THỊ   ")
    print("=" * 70)

    # 1. XỬ LÝ EN ATLAS (entry_01950)
    print("\n[1/4] Khôi phục sprite ngôn ngữ trong entry_01950.bin (EN Atlas)...")
    cur_1950_bin = PATCH_UI_DIR / "entry_01950.bin"
    cur_1950_png = Path("temp_1950_current.png")
    subprocess.run([str(MSG_TOOL), "export", "-t", "kirikiri-tlg", str(cur_1950_bin), str(cur_1950_png)], check=True)
    img_1950 = Image.open(cur_1950_png).convert("RGBA")

    fresh_1950_png = FRESH_DIR / "entry_01950.png"
    fresh_1950 = Image.open(fresh_1950_png).convert("RGBA")

    # Slices ngôn ngữ trong EN atlas
    en_slices = {
        "text_cn":   (415, 91, 126, 41),
        "text_en":   (375, 137, 204, 34),
        "text_jp":   (516, 550, 121, 41),
        "text_kr":   (541, 91, 78, 40),
        "text_none": (516, 591, 93, 34),
        "text_tw":   (458, 46, 126, 41)
    }

    for name, (cx, cy, cw, ch) in en_slices.items():
        crop = fresh_1950.crop((cx, cy, cx + cw, cy + ch))
        crop_clean = clean_magenta(crop)
        nz = np.count_nonzero(np.array(crop_clean)[:, :, 3])
        print(f"   + [EN] {name} tại ({cx}, {cy}, {cw}, {ch}): {nz} text pixels khôi phục")
        # Dán đè vào vị trí chuẩn trong img_1950
        # Xóa vùng trước khi dán để trong suốt sạch sẽ
        draw_clear = Image.new("RGBA", (cw, ch), (0, 0, 0, 0))
        img_1950.paste(draw_clear, (cx, cy))
        img_1950.paste(crop_clean, (cx, cy), crop_clean)

    out_1950_png = Path("temp_1950_restored.png")
    img_1950.save(out_1950_png)

    # Đóng gói TLG cho entry_01950
    orig_1950_bin = list(EXT_DATA_DIR.glob("entry_01950_*.bin"))[0]
    out_1950_tlg = TLG_MSGTOOL_DIR / "entry_01950.tlg"
    subprocess.run([str(MSG_TOOL), "import", "-t", "kirikiri-tlg", str(orig_1950_bin), str(out_1950_png), str(out_1950_tlg)], check=True)
    shutil.copy2(out_1950_tlg, cur_1950_bin)
    print("   -> Đã cập nhật thành công entry_01950.bin!")

    # 2. XỬ LÝ JP ATLAS (entry_01952)
    print("\n[2/4] Khôi phục sprite ngôn ngữ trong entry_01952.bin (JP Atlas)...")
    cur_1952_bin = PATCH_UI_DIR / "entry_01952.bin"
    cur_1952_png = Path("temp_1952_current.png")
    subprocess.run([str(MSG_TOOL), "export", "-t", "kirikiri-tlg", str(cur_1952_bin), str(cur_1952_png)], check=True)
    img_1952 = Image.open(cur_1952_png).convert("RGBA")

    fresh_1952_png = FRESH_DIR / "entry_01952.png"
    fresh_1952 = Image.open(fresh_1952_png).convert("RGBA")

    jp_slices = {
        "text_cn":   (519, 532, 126, 41),
        "text_en":   (282, 583, 204, 34),
        "text_jp":   (502, 47, 121, 41),
        "text_kr":   (564, 291, 78, 40),
        "text_none": (562, 448, 93, 34),
        "text_tw":   (519, 573, 126, 41)
    }

    # Lấy sprite text_none và text_en từ EN fresh để đảm bảo chữ OFF và ENGLISH sắc nét
    crop_en_clean = clean_magenta(fresh_1950.crop((375, 137, 375 + 204, 137 + 34)))
    crop_off_clean = clean_magenta(fresh_1950.crop((516, 591, 516 + 93, 591 + 34)))

    for name, (cx, cy, cw, ch) in jp_slices.items():
        if name == "text_en":
            crop_clean = crop_en_clean
        elif name == "text_none":
            crop_clean = crop_off_clean
        else:
            crop = fresh_1952.crop((cx, cy, cx + cw, cy + ch))
            crop_clean = clean_magenta(crop)

        nz = np.count_nonzero(np.array(crop_clean)[:, :, 3])
        print(f"   + [JP] {name} tại ({cx}, {cy}, {cw}, {ch}): {nz} text pixels khôi phục")
        draw_clear = Image.new("RGBA", (cw, ch), (0, 0, 0, 0))
        img_1952.paste(draw_clear, (cx, cy))
        img_1952.paste(crop_clean, (cx, cy), crop_clean)

    out_1952_png = Path("temp_1952_restored.png")
    img_1952.save(out_1952_png)

    orig_1952_bin = list(EXT_DATA_DIR.glob("entry_01952_*.bin"))[0]
    out_1952_tlg = TLG_MSGTOOL_DIR / "entry_01952.tlg"
    subprocess.run([str(MSG_TOOL), "import", "-t", "kirikiri-tlg", str(orig_1952_bin), str(out_1952_png), str(out_1952_tlg)], check=True)
    shutil.copy2(out_1952_tlg, cur_1952_bin)
    print("   -> Đã cập nhật thành công entry_01952.bin!")

    # 3. ĐỒNG BỘ CẢ 6 FILE PBD DISPLAY
    print("\n[3/4] Đồng bộ _lang node trong toàn bộ 6 file PBD Display...")
    # Cấu hình chuẩn uistates trỏ vào config_page0_en__pack
    en_lang_states = {
        "hotspot": {"h": 48, "ox": 514, "oy": 25, "storage": "", "w": 48},
        "normal": {"ch": 74, "cw": 637, "cx": 0, "cy": 70, "h": 74, "ox": 0, "oy": 0, "storage": "config_page0__pack", "w": 637},
        "text_cn": {"ch": 41, "cw": 126, "cx": 415, "cy": 91, "h": 41, "ox": 257, "oy": 17, "storage": "config_page0_en__pack", "w": 126},
        "text_en": {"ch": 34, "cw": 204, "cx": 375, "cy": 137, "h": 34, "ox": 218, "oy": 21, "storage": "config_page0_en__pack", "w": 204},
        "text_jp": {"ch": 41, "cw": 121, "cx": 516, "cy": 550, "h": 41, "ox": 263, "oy": 17, "storage": "config_page0_en__pack", "w": 121},
        "text_kr": {"ch": 40, "cw": 78, "cx": 541, "cy": 91, "h": 40, "ox": 281, "oy": 18, "storage": "config_page0_en__pack", "w": 78},
        "text_none": {"ch": 34, "cw": 93, "cx": 516, "cy": 591, "h": 34, "ox": 274, "oy": 21, "storage": "config_page0_en__pack", "w": 93},
        "text_tw": {"ch": 41, "cw": 126, "cx": 458, "cy": 46, "h": 41, "ox": 257, "oy": 17, "storage": "config_page0_en__pack", "w": 126}
    }

    # Đối với JP PBD (1953 & 2075), trỏ vào config_page0_jp__pack
    jp_lang_states = {
        "hotspot": {"h": 48, "ox": 514, "oy": 25, "storage": "", "w": 48},
        "normal": {"ch": 74, "cw": 637, "cx": 0, "cy": 70, "h": 74, "ox": 0, "oy": 0, "storage": "config_page0__pack", "w": 637},
        "text_cn": {"ch": 41, "cw": 126, "cx": 519, "cy": 532, "h": 41, "ox": 257, "oy": 17, "storage": "config_page0_jp__pack", "w": 126},
        "text_en": {"ch": 34, "cw": 204, "cx": 282, "cy": 583, "h": 34, "ox": 218, "oy": 21, "storage": "config_page0_jp__pack", "w": 204},
        "text_jp": {"ch": 41, "cw": 121, "cx": 502, "cy": 47, "h": 41, "ox": 263, "oy": 17, "storage": "config_page0_jp__pack", "w": 121},
        "text_kr": {"ch": 40, "cw": 78, "cx": 564, "cy": 291, "h": 40, "ox": 281, "oy": 18, "storage": "config_page0_jp__pack", "w": 78},
        "text_none": {"ch": 34, "cw": 93, "cx": 562, "cy": 448, "h": 34, "ox": 274, "oy": 21, "storage": "config_page0_jp__pack", "w": 93},
        "text_tw": {"ch": 41, "cw": 126, "cx": 519, "cy": 573, "h": 41, "ox": 257, "oy": 17, "storage": "config_page0_jp__pack", "w": 126}
    }

    pbd_list = [
        (1949, en_lang_states),
        (1951, en_lang_states),
        (1953, jp_lang_states),
        (2072, en_lang_states),
        (2073, en_lang_states),
        (2075, jp_lang_states),
    ]

    for pbd_idx, states in pbd_list:
        pbd_bin = PATCH_PBD_DIR / f"entry_{pbd_idx:05d}.bin"
        tmp_json = Path(f"temp_pbd_sync_{pbd_idx}.json")
        subprocess.run([str(MSG_TOOL), "export", "-t", "kirikiri-tjs-ns0", str(pbd_bin), str(tmp_json)], check=True)
        with open(tmp_json, "r", encoding="utf-8") as f:
            pbd_data = json.load(f)

        # Cập nhật _lang node
        if "_lang" in pbd_data.get("result", {}):
            pbd_data["result"]["_lang"]["uistates"] = states
            print(f"   + [PBD {pbd_idx}] Đã cập nhật uistates cho node _lang")

        with open(tmp_json, "w", encoding="utf-8") as f:
            json.dump(pbd_data, f, indent=2, ensure_ascii=False)

        orig_pbd_bin = list(EXT_DATA_DIR.glob(f"entry_{pbd_idx:05d}_*.bin"))[0]
        subprocess.run([str(MSG_TOOL), "import", "-t", "kirikiri-tjs-ns0", str(orig_pbd_bin), str(tmp_json), str(pbd_bin)], check=True)
        print(f"   -> Đã recompile thành công entry_{pbd_idx:05d}.bin!")

    # 4. REPACK TOÀN DIỆN VÀO DATA.XP3
    print("\n[4/4] Chạy repack_viet_hoa_full.py để đóng gói hoàn thiện vào data.xp3...")
    sys.stdout.flush()
    subprocess.run([sys.executable, "repack_viet_hoa_full.py"], check=True)

    print("\n" + "=" * 70)
    print("   HOÀN TẤT 100% QUÁ TRÌNH KHÔI PHỤC VÀ REPACK! GAME ĐÃ SẴN SÀNG!   ")
    print("=" * 70)

if __name__ == "__main__":
    main()
