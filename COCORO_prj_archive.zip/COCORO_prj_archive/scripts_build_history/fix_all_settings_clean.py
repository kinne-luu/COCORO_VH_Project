# -*- coding: utf-8 -*-
"""
Khôi phục và xây dựng lại toàn bộ Cài Đặt (Sound, Text, Display, Dialog)
- Sử dụng bản gốc sạch 100% từ orig_fresh
- Tuyệt đối KHÔNG đè lên slider, slider track, slider thumb (nguyên nhân gây biến dạng slider tím/hồng và dính chữ)
- Chỉ cập nhật các node head_* (nhãn tiêu đề)
- Nhãn tiếng Việt không ngoặc, font STIX Two Text Bold size 32, ox=68
- Xuất TLG và PBD chuẩn vào COCORO_Patch_VietHoa/patch_data
"""

import sys
import json
import shutil
import subprocess
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont

ROOT_DIR = Path(r"D:\Software\Antigravity\Project\Cocoro")
MSG_TOOL = ROOT_DIR / "tools" / "msg-tool" / "msg_tool.exe"
FRESH_DIR = ROOT_DIR / "orig_fresh"
PATCH_UI_DIR = ROOT_DIR / "COCORO_Patch_VietHoa" / "patch_data" / "ui"
PATCH_PBD_DIR = ROOT_DIR / "COCORO_Patch_VietHoa" / "patch_data" / "pbd"
TLG_MSGTOOL_DIR = ROOT_DIR / "tlg_msgtool"

PATCH_UI_DIR.mkdir(parents=True, exist_ok=True)
PATCH_PBD_DIR.mkdir(parents=True, exist_ok=True)
TLG_MSGTOOL_DIR.mkdir(parents=True, exist_ok=True)

FONT_PATH = Path(r"C:\Users\ADMIN\AppData\Local\Microsoft\Windows\Fonts\STIXTwoText-Bold.ttf")
if not FONT_PATH.exists():
    FONT_PATH = Path(r"C:\Windows\Fonts\timesbd.ttf")

LABEL_FONT = ImageFont.truetype(str(FONT_PATH), 32)
TEXT_COLOR = (50, 55, 60, 255)

def render_left_label(text, width=600, height=48, margin_left=5):
    img = Image.new("RGBA", (width, height), (0, 0, 0, 0))
    draw = ImageDraw.Draw(img)
    bb = draw.textbbox((0, 0), text, font=LABEL_FONT)
    th = bb[3] - bb[1]
    tx = margin_left
    ty = (height - th) // 2 - bb[1]
    draw.text((tx, ty), text, font=LABEL_FONT, fill=TEXT_COLOR)
    return img

print("=" * 70)
print("   BẮT ĐẦU XÂY DỰNG LẠI CÀI ĐẶT SẠCH 100% (KHÔNG CHẠM VÀO SLIDER)   ")
print("=" * 70)

# ======================================================================
# 1. TRANG SOUND (CONFIG_P3)
# ======================================================================
print("\n[1/4] Xây dựng trang Âm Thanh (Sound - config_p3)...")
sound_orig_img = Image.open(FRESH_DIR / "entry_01979.png").convert("RGBA")
canvas_sound = Image.new("RGBA", (1200, 480), (0, 0, 0, 0))
canvas_sound.paste(sound_orig_img, (0, 0)) # Giữ nguyên gốc 100%

sound_labels = {
    0: ("bgm", "Nhạc nền"),
    1: ("down", "Chế độ Downmix"),
    2: ("movie", "Âm lượng phim"),
    3: ("se", "Hiệu ứng âm thanh"),
    4: ("sysvo", "Giọng hệ thống"),
    5: ("voice", "Lời thoại"),
    6: ("voicecut", "Ngắt giọng khi bấm qua"),
    7: ("wave", "Âm lượng tổng")
}

sound_layout = {}
for s_idx, (key, text) in sound_labels.items():
    nx = 520
    ny = s_idx * 55
    nw = 600
    nh = 48
    lbl_img = render_left_label(text, width=nw, height=nh)
    canvas_sound.paste(lbl_img, (nx, ny), lbl_img)
    sound_layout[s_idx] = {"key": key, "x": nx, "y": ny, "w": nw, "h": nh}

sound_atlas_png = Path("temp_sound_atlas.png")
canvas_sound.save(sound_atlas_png)

def update_sound_pbd(json_in, bin_template, bin_out):
    with open(json_in, "r", encoding="utf-8") as f:
        pbd = json.load(f)
    packlist = pbd.get("packlist", [])
    for s_idx, d in sound_layout.items():
        if s_idx < len(packlist):
            packlist[s_idx][0] = d["x"]
            packlist[s_idx][1] = d["y"]
            packlist[s_idx][2] = d["w"]
            packlist[s_idx][3] = d["h"]
            if len(packlist[s_idx]) > 7:
                packlist[s_idx][7] = None
    def walk(node):
        if isinstance(node, dict):
            uiname = node.get("uiname", "")
            # CHỈ DUYỆT CÁC NODE BẮT ĐẦU BẰNG head_
            if uiname.startswith("head_") and "uistates" in node:
                st = node["uistates"]
                for s_idx, d in sound_layout.items():
                    k = d["key"]
                    if k in st:
                        st[k].update({
                            "cx": d["x"], "cy": d["y"], "cw": d["w"], "ch": d["h"],
                            "w": d["w"], "h": d["h"], "ox": 68, "oy": 3, "cr": None
                        })
            for k, v in node.items():
                if k != "uistates": walk(v)
        elif isinstance(node, list):
            for it in node: walk(it)
    walk(pbd.get("result", {}))
    synced_json = Path("temp_sound_synced.json")
    with open(synced_json, "w", encoding="utf-8") as f:
        json.dump(pbd, f, indent=2, ensure_ascii=False)
    subprocess.run([str(MSG_TOOL), "import", "-t", "kirikiri-tjs-ns0", str(bin_template), str(synced_json), str(bin_out)], check=True)

update_sound_pbd(FRESH_DIR / "entry_01978.json", FRESH_DIR / "entry_01978.bin", PATCH_PBD_DIR / "entry_01978.bin")
update_sound_pbd(FRESH_DIR / "entry_01980.json", FRESH_DIR / "entry_01980.bin", PATCH_PBD_DIR / "entry_01980.bin")

# Import TLG Sound
raw_sound_tlg = FRESH_DIR / "entry_01979.bin"
tlg_p3_en = TLG_MSGTOOL_DIR / "entry_01977_57b8.tlg"
tlg_p3_jp = TLG_MSGTOOL_DIR / "entry_01979_57ba.tlg"
subprocess.run([str(MSG_TOOL), "import", "-t", "kirikiri-tlg", str(raw_sound_tlg), str(sound_atlas_png), str(tlg_p3_en)], check=True)
subprocess.run([str(MSG_TOOL), "import", "-t", "kirikiri-tlg", str(raw_sound_tlg), str(sound_atlas_png), str(tlg_p3_jp)], check=True)
shutil.copy2(tlg_p3_en, PATCH_UI_DIR / "entry_01977.bin")
shutil.copy2(tlg_p3_jp, PATCH_UI_DIR / "entry_01979.bin")
print("   + Hoàn tất trang Sound (PBD 1978/1980, TLG 1977/1979) - Slider bảo toàn 100%!")

# ======================================================================
# 2. TRANG TEXT (CONFIG_P1)
# ======================================================================
print("\n[2/4] Xây dựng trang Văn Bản (Text - config_p1)...")
text_orig_img = Image.open(FRESH_DIR / "entry_01961.png").convert("RGBA")
canvas_text = Image.new("RGBA", (1500, 800), (0, 0, 0, 0))
canvas_text.paste(text_orig_img, (0, 0)) # Giữ nguyên gốc 100%

text_labels = {
    15: ("autospeed",  "Tốc độ tự đọc"),
    16: ("autovwait",  "Chờ hết giọng khi tự đọc"),
    17: ("ctrlskip",   "Tua nhanh bằng phím Ctrl"),
    18: ("readskip",   "Bỏ qua thoại đã đọc"),
    19: ("rtextcol",   "Đổi màu chữ đã đọc"),
    20: ("skipall",    "Bỏ qua toàn bộ thoại"),
    21: ("textspeed",  "Tốc độ hiển thị chữ"),
    22: ("winopac",    "Độ mờ khung thoại")
}

text_layout = {}
for idx, (s_idx, (key, text)) in enumerate(text_labels.items()):
    nx = 860
    ny = idx * 55
    nw = 600
    nh = 48
    lbl_img = render_left_label(text, width=nw, height=nh)
    canvas_text.paste(lbl_img, (nx, ny), lbl_img)
    text_layout[s_idx] = {"key": key, "x": nx, "y": ny, "w": nw, "h": nh}

text_atlas_png = Path("temp_text_atlas.png")
canvas_text.save(text_atlas_png)

def update_text_pbd(json_in, bin_template, bin_out):
    with open(json_in, "r", encoding="utf-8") as f:
        pbd = json.load(f)
    packlist = pbd.get("packlist", [])
    for s_idx, d in text_layout.items():
        if s_idx < len(packlist):
            packlist[s_idx][0] = d["x"]
            packlist[s_idx][1] = d["y"]
            packlist[s_idx][2] = d["w"]
            packlist[s_idx][3] = d["h"]
            if len(packlist[s_idx]) > 7:
                packlist[s_idx][7] = None
    def walk(node):
        if isinstance(node, dict):
            uiname = node.get("uiname", "")
            # CHỈ DUYỆT CÁC NODE BẮT ĐẦU BẰNG head_
            if uiname.startswith("head_") and "uistates" in node:
                st = node["uistates"]
                for s_idx, d in text_layout.items():
                    k = d["key"]
                    if k in st:
                        st[k].update({
                            "cx": d["x"], "cy": d["y"], "cw": d["w"], "ch": d["h"],
                            "w": d["w"], "h": d["h"], "ox": 68, "oy": 3, "cr": None
                        })
            for k, v in node.items():
                if k != "uistates": walk(v)
        elif isinstance(node, list):
            for it in node: walk(it)
    walk(pbd.get("result", {}))
    synced_json = Path("temp_text_synced.json")
    with open(synced_json, "w", encoding="utf-8") as f:
        json.dump(pbd, f, indent=2, ensure_ascii=False)
    subprocess.run([str(MSG_TOOL), "import", "-t", "kirikiri-tjs-ns0", str(bin_template), str(synced_json), str(bin_out)], check=True)

update_text_pbd(FRESH_DIR / "entry_01960.json", FRESH_DIR / "entry_01960.bin", PATCH_PBD_DIR / "entry_01960.bin")
update_text_pbd(FRESH_DIR / "entry_01962.json", FRESH_DIR / "entry_01962.bin", PATCH_PBD_DIR / "entry_01962.bin")

# Import TLG Text
raw_text_tlg = FRESH_DIR / "entry_01961.bin"
tlg_p1_en = TLG_MSGTOOL_DIR / "entry_01961_57a8.tlg"
subprocess.run([str(MSG_TOOL), "import", "-t", "kirikiri-tlg", str(raw_text_tlg), str(text_atlas_png), str(tlg_p1_en)], check=True)
shutil.copy2(tlg_p1_en, PATCH_UI_DIR / "entry_01961.bin")
print("   + Hoàn tất trang Text (PBD 1960/1962, TLG 1961) - Slider bảo toàn 100%!")

# ======================================================================
# 3. TRANG DISPLAY (CONFIG_P0)
# ======================================================================
print("\n[3/4] Xây dựng trang Hiển Thị (Display - config_p0)...")
display_orig_img = Image.open(FRESH_DIR / "entry_01952.png").convert("RGBA")
canvas_display = Image.new("RGBA", (1300, 650), (0, 0, 0, 0))
canvas_display.paste(display_orig_img, (0, 0)) # Giữ nguyên gốc 100%

display_labels = {
    11: ("drawspeed",   "Tốc độ vẽ"),
    12: ("fullscreen",  "Chế độ hiển thị"),
    13: ("savequit",    "Quay lại game sau khi lưu"),
    14: ("sublang",     "Phụ đề ngôn ngữ phụ"),
    15: ("textlang",    "Ngôn ngữ văn bản chính"),
    16: ("touchmode",   "Chế độ cảm ứng"),
    17: ("uilang",      "Ngôn ngữ giao diện"),
    18: ("voicespeed",  "Tốc độ giọng nói"),
    19: ("vspeedsync",  "Đồng bộ tốc độ thoại")
}

display_layout = {}
for idx, (s_idx, (key, text)) in enumerate(display_labels.items()):
    nx = 650
    ny = idx * 55
    nw = 600
    nh = 48
    lbl_img = render_left_label(text, width=nw, height=nh)
    canvas_display.paste(lbl_img, (nx, ny), lbl_img)
    display_layout[s_idx] = {"key": key, "x": nx, "y": ny, "w": nw, "h": nh}

display_atlas_png = Path("temp_display_atlas.png")
canvas_display.save(display_atlas_png)

def update_display_pbd(json_in, bin_template, bin_out):
    with open(json_in, "r", encoding="utf-8") as f:
        pbd = json.load(f)
    packlist = pbd.get("packlist", [])
    for s_idx, d in display_layout.items():
        if s_idx < len(packlist):
            packlist[s_idx][0] = d["x"]
            packlist[s_idx][1] = d["y"]
            packlist[s_idx][2] = d["w"]
            packlist[s_idx][3] = d["h"]
            if len(packlist[s_idx]) > 7:
                packlist[s_idx][7] = None
    def walk(node):
        if isinstance(node, dict):
            uiname = node.get("uiname", "")
            if uiname.startswith("head_") and "uistates" in node:
                st = node["uistates"]
                for s_idx, d in display_layout.items():
                    k = d["key"]
                    if k in st:
                        st[k].update({
                            "cx": d["x"], "cy": d["y"], "cw": d["w"], "ch": d["h"],
                            "w": d["w"], "h": d["h"], "ox": 68, "oy": 3, "cr": None
                        })
            for k, v in node.items():
                if k != "uistates": walk(v)
        elif isinstance(node, list):
            for it in node: walk(it)
    walk(pbd.get("result", {}))
    synced_json = Path("temp_display_synced.json")
    with open(synced_json, "w", encoding="utf-8") as f:
        json.dump(pbd, f, indent=2, ensure_ascii=False)
    subprocess.run([str(MSG_TOOL), "import", "-t", "kirikiri-tjs-ns0", str(bin_template), str(synced_json), str(bin_out)], check=True)

update_display_pbd(FRESH_DIR / "entry_01951.json", FRESH_DIR / "entry_01951.bin", PATCH_PBD_DIR / "entry_01951.bin")
update_display_pbd(FRESH_DIR / "entry_01953.json", FRESH_DIR / "entry_01953.bin", PATCH_PBD_DIR / "entry_01953.bin")

# Import TLG Display
raw_display_tlg = FRESH_DIR / "entry_01952.bin"
tlg_p0_en = TLG_MSGTOOL_DIR / "entry_01950_579d.tlg"
tlg_p0_jp = TLG_MSGTOOL_DIR / "entry_01952_579f.tlg"
subprocess.run([str(MSG_TOOL), "import", "-t", "kirikiri-tlg", str(raw_display_tlg), str(display_atlas_png), str(tlg_p0_en)], check=True)
subprocess.run([str(MSG_TOOL), "import", "-t", "kirikiri-tlg", str(raw_display_tlg), str(display_atlas_png), str(tlg_p0_jp)], check=True)
shutil.copy2(tlg_p0_en, PATCH_UI_DIR / "entry_01950.bin")
shutil.copy2(tlg_p0_jp, PATCH_UI_DIR / "entry_01952.bin")
print("   + Hoàn tất trang Display (PBD 1951/1953, TLG 1950/1952)!")

# ======================================================================
# 4. TRANG DIALOG (CONFIG_P2)
# ======================================================================
print("\n[4/4] Xây dựng trang Hội Thoại / Xác Nhận (Dialog - config_p2)...")
dialog_orig_img = Image.open(FRESH_DIR / "entry_01970.png").convert("RGBA")
canvas_dialog = Image.new("RGBA", (1550, 890), (0, 0, 0, 0))
canvas_dialog.paste(dialog_orig_img, (0, 0)) # Giữ nguyên gốc 100%

dialog_labels = {
    6:  ("cf_allremove1", "Xác nhận xóa toàn bộ dữ liệu"),
    7:  ("cf_allremove2", "Xác nhận xóa toàn bộ thiết lập"),
    8:  ("cf_backto",     "Xác nhận trở về trước đó"),
    9:  ("cf_delete",     "Xác nhận xóa file lưu"),
    10: ("cf_exit",       "Xác nhận thoát trò chơi"),
    11: ("cf_init",       "Xác nhận khôi phục mặc định"),
    12: ("cf_jump",       "Xác nhận nhảy đến cảnh"),
    13: ("cf_load",       "Xác nhận tải file lưu"),
    14: ("cf_next",       "Xác nhận chuyển cảnh tiếp"),
    15: ("cf_overwrite",  "Xác nhận ghi đè file lưu"),
    16: ("cf_qload",      "Xác nhận tải nhanh"),
    17: ("cf_qsave",      "Xác nhận lưu nhanh"),
    18: ("cf_title",      "Xác nhận về màn hình chính")
}

dialog_layout = {}
for idx, (s_idx, (key, text)) in enumerate(dialog_labels.items()):
    nx = 900
    ny = idx * 55
    nw = 600
    nh = 48
    lbl_img = render_left_label(text, width=nw, height=nh)
    canvas_dialog.paste(lbl_img, (nx, ny), lbl_img)
    dialog_layout[s_idx] = {"key": key, "x": nx, "y": ny, "w": nw, "h": nh}

dialog_atlas_png = Path("temp_dialog_atlas.png")
canvas_dialog.save(dialog_atlas_png)

def update_dialog_pbd(json_in, bin_template, bin_out):
    with open(json_in, "r", encoding="utf-8") as f:
        pbd = json.load(f)
    packlist = pbd.get("packlist", [])
    for s_idx, d in dialog_layout.items():
        if s_idx < len(packlist):
            packlist[s_idx][0] = d["x"]
            packlist[s_idx][1] = d["y"]
            packlist[s_idx][2] = d["w"]
            packlist[s_idx][3] = d["h"]
            if len(packlist[s_idx]) > 7:
                packlist[s_idx][7] = None
    def walk(node):
        if isinstance(node, dict):
            uiname = node.get("uiname", "")
            if uiname.startswith("head_") and "uistates" in node:
                st = node["uistates"]
                for s_idx, d in dialog_layout.items():
                    k = d["key"]
                    if k in st:
                        st[k].update({
                            "cx": d["x"], "cy": d["y"], "cw": d["w"], "ch": d["h"],
                            "w": d["w"], "h": d["h"], "ox": 68, "oy": 3, "cr": None
                        })
            for k, v in node.items():
                if k != "uistates": walk(v)
        elif isinstance(node, list):
            for it in node: walk(it)
    walk(pbd.get("result", {}))
    synced_json = Path("temp_dialog_synced.json")
    with open(synced_json, "w", encoding="utf-8") as f:
        json.dump(pbd, f, indent=2, ensure_ascii=False)
    subprocess.run([str(MSG_TOOL), "import", "-t", "kirikiri-tjs-ns0", str(bin_template), str(synced_json), str(bin_out)], check=True)

update_dialog_pbd(FRESH_DIR / "entry_01969.json", FRESH_DIR / "entry_01969.bin", PATCH_PBD_DIR / "entry_01969.bin")
update_dialog_pbd(FRESH_DIR / "entry_01971.json", FRESH_DIR / "entry_01971.bin", PATCH_PBD_DIR / "entry_01971.bin")

# Import TLG Dialog
raw_dialog_tlg = FRESH_DIR / "entry_01970.bin"
tlg_p2_en = TLG_MSGTOOL_DIR / "entry_01968_57af.tlg"
tlg_p2_jp = TLG_MSGTOOL_DIR / "entry_01970_57b1.tlg"
subprocess.run([str(MSG_TOOL), "import", "-t", "kirikiri-tlg", str(raw_dialog_tlg), str(dialog_atlas_png), str(tlg_p2_en)], check=True)
subprocess.run([str(MSG_TOOL), "import", "-t", "kirikiri-tlg", str(raw_dialog_tlg), str(dialog_atlas_png), str(tlg_p2_jp)], check=True)
shutil.copy2(tlg_p2_en, PATCH_UI_DIR / "entry_01968.bin")
shutil.copy2(tlg_p2_jp, PATCH_UI_DIR / "entry_01970.bin")
print("   + Hoàn tất trang Dialog (PBD 1969/1971, TLG 1968/1970)!")

print("\n" + "=" * 70)
print("   ĐÃ HOÀN TẤT XÂY DỰNG TOÀN BỘ CÀI ĐẶT SẠCH SẼ HOÀN HẢO!   ")
print("=" * 70)
