from PIL import Image
import numpy as np

im = Image.open("stacked_user_buttons.png").convert("RGBA")
arr = np.array(im)

nodes_order = ['save', 'load', 'qsave', 'qload', 'xprev', 'next', 'auto', 'skip', 'log', 'option', 'manual', 'title']

print("--- MEASURE BUTTONS IN stacked_user_buttons.png ---")
for idx, name in enumerate(nodes_order):
    crop = arr[idx*59 : (idx+1)*59, :, :]
    # Đo viên thuốc (alpha > 100)
    alpha = crop[:, :, 3]
    cap_xs = []
    for y in range(15, 45):
        row = alpha[y, :]
        dark = np.where(row > 100)[0]
        if len(dark) > 0:
            cap_xs.append(dark[0])
            
    # Đo icon (white pixels ở x < 60)
    white_icon = np.where((crop[:, :60, 0] > 180) & (crop[:, :60, 1] > 180) & (crop[:, :60, 2] > 180))
    icon_left = np.min(white_icon[1]) if len(white_icon[1]) > 0 else None
    icon_right = np.max(white_icon[1]) if len(white_icon[1]) > 0 else None
    
    # Đo text (white pixels ở x >= 60)
    white_text = np.where((crop[:, 60:, 0] > 180) & (crop[:, 60:, 1] > 180) & (crop[:, 60:, 2] > 180))
    text_left = (np.min(white_text[1]) + 60) if len(white_text[1]) > 0 else None
    
    print(f"Node {idx:2d} ({name:8s}): cap_left={min(cap_xs)}, icon_left={icon_left}, icon_right={icon_right}, text_left={text_left}")
