import subprocess
import shutil
from pathlib import Path

ROOT_DIR = Path(r"D:\Software\Antigravity\Project\Cocoro")
CONF_PATCH_DIR = ROOT_DIR / "COCORO_Patch_VietHoa" / "patch_data" / "conf"
CONF_PATCH_DIR.mkdir(parents=True, exist_ok=True)

# 1. Đọc temp_help_conf.txt gốc
txt_path = ROOT_DIR / "temp_help_conf.txt"
if not txt_path.exists():
    cmd = [
        str(ROOT_DIR / "tools" / "msg-tool" / "msg_tool.exe"),
        "export", "-t", "kirikiri-simple-crypt",
        str(ROOT_DIR / "extracted_data" / "data" / "entry_00606_525d.bin"),
        str(txt_path)
    ]
    subprocess.run(cmd, check=True)

# Đọc text bỏ BOM \ufeff
raw_text = txt_path.read_text(encoding="utf-16le")
if raw_text.startswith("\ufeff"):
    raw_text = raw_text[1:]

# Danh sách dịch thuật chính xác 100% theo tài liệu người dùng
TRANSLATIONS = [
    # 6 mục điều chỉnh mới
    (["autospeed"], "Cài đặt tốc độ chuyển câu khi ở chế độ Tự động"),
    (["readskip_on", "readskip_off", "readskip_help"], 'Chọn "On" để chỉ tự động tua nhanh qua các câu thoại đã đọc.'),
    (["bgmvolume", "bgmvolume_mute"], "Điều chỉnh âm lượng nhạc nền"),
    (["sevolume", "sevolume_mute"], "Điều chỉnh âm lượng hiệu ứng âm thanh"),
    (["cf_qsave_help"], "Hiển thị hộp thoại xác nhận trước khi Lưu nhanh"),
    (["cf_qload_help"], "Hiển thị hộp thoại xác nhận trước khi Tải nhanh"),

    # A. Tab Văn bản
    (["textspeed"], "Cài đặt tốc độ hiển thị chữ."),
    (["autovwait_help"], "Bật để chế độ Tự động chờ đọc hết giọng lồng tiếng mới chuyển sang câu tiếp theo."),
    (["automode_n", "autovwait_0"], "Bật để chế độ Tự động chờ đọc hết giọng lồng tiếng mới chuyển sang câu tiếp theo."),
    (["automode_v", "autovwait_1"], "Bật để chế độ Tự động chờ đọc hết giọng lồng tiếng mới chuyển sang câu tiếp theo (chỉ khi câu tiếp theo có lồng tiếng)."),
    (["automode_s", "autovwait_2"], "Chế độ Tự động sẽ chuyển câu theo tốc độ cài đặt mà không cần chờ hết giọng lồng tiếng."),
    (["ctrlskip_help"], "Bật/Tắt tính năng tua nhanh văn bản bằng phím Ctrl."),
    (["skipall", "skipread", "skipall_help"], "Bật/Tắt việc tiếp tục tua nhanh sau khi xuất hiện lựa chọn."),
    (["winopac"], "Điều chỉnh độ đậm / mờ của khung thoại trong game."),
    (["rtextcol_on", "rtextcol_off", "rtextcol_help"], "Đổi màu các câu thoại đã đọc để dễ nhận biết."),
    (["skipspeed"], "Điều chỉnh tốc độ tua văn bản trong chế độ Skip."),
    (["speedsample"], "Khung hiển thị mẫu văn bản. Nhấp vào đây để đổi phông chữ."),

    # B. Tab Hiển thị & Hệ thống
    (["window", "fullscreen"], "Chuyển đổi giữa chế độ toàn màn hình và cửa sổ."),
    (["gamespeed", "drawspeed_help"], "Cài đặt tốc độ hoạt họa hình ảnh trong game."),
    (["vspeedsync"], "Đồng bộ tốc độ hiển thị chữ theo giọng nói nhân vật."),
    (["voicespeed", "voicespeed_help"], "Điều chỉnh tốc độ phát âm thanh giọng nói nhân vật."),
    (["touchmode"], "Bật/Tắt chế độ điều khiển cảm ứng cho màn hình cảm ứng."),
    (["lang_ui", "uilang_prev", "uilang_next", "uilang"], "Thay đổi ngôn ngữ hiển thị giao diện."),
    (["lang_text", "textlang_prev", "textlang_next", "textlang"], "Thay đổi ngôn ngữ văn bản trong game."),
    (["lang_sub"], "Thay đổi ngôn ngữ phụ đề hiển thị kèm theo."),

    # C. Tab Âm thanh
    (["wavevolume", "wavevolume_mute"], "Điều chỉnh âm lượng tổng thể của trò chơi."),
    (["voicevolume", "voicevolume_mute"], "Điều chỉnh âm lượng giọng nói của nhân vật."),
    (["movievolume", "movievolume_mute"], "Điều chỉnh âm lượng phim và video cắt cảnh."),
    (["sysvovolume", "sysvo_help"], "Điều chỉnh âm lượng giọng đọc hệ thống."),
    (["sysvo", "sysvosel_help"], "Chọn nhân vật lồng tiếng hướng dẫn trong menu hệ thống."),
    (["voicecut_help"], "Bật/Tắt tự động ngắt giọng nói khi chuyển sang câu tiếp theo."),
    (["voicecut_on"], "Bật/Tắt tự động ngắt giọng nói khi chuyển sang câu tiếp theo.\tGiọng lồng tiếng sẽ bị ngắt ngay khi chuyển sang câu thoại tiếp theo."),
    (["voicecut_off"], "Bật/Tắt tự động ngắt giọng nói khi chuyển sang câu tiếp theo.\tGiọng lồng tiếng sẽ phát hết trước khi chuyển sang câu thoại tiếp theo."),
    (["downvolume"], "Tự động hạ nhỏ nhạc nền khi nhân vật đang nói chuyện."),
    (["bgmdown"], "Tự động hạ nhỏ nhạc nền khi nhân vật đang nói chuyện."),
    (["bgmdown_on", "bgmdown_off"], "Tự động hạ nhỏ nhạc nền khi nhân vật đang nói chuyện."),
    (["charea", "help_chvoice"], "Điều chỉnh âm lượng giọng nói riêng cho từng nhân vật."),

    # D. Tab Hộp thoại xác nhận
    (["cf_title_help"], "Hiển thị hộp thoại xác nhận trước khi quay về màn hình chính."),
    (["cf_exit_help"], "Hiển thị hộp thoại xác nhận trước khi thoát trò chơi."),
    (["cf_load_help"], "Hiển thị hộp thoại xác nhận trước khi tải tệp lưu (Load)."),
    (["cf_overwrite_help"], "Hiển thị hộp thoại xác nhận trước khi ghi đè tệp lưu."),
    (["cf_delete_help"], "Hiển thị hộp thoại xác nhận trước khi xóa tệp lưu."),
    (["cf_jump_help"], "Hiển thị hộp thoại xác nhận trước khi chuyển đến câu trong lịch sử."),
    (["cf_next_help"], "Hiển thị hộp thoại xác nhận trước khi nhảy tới lựa chọn tiếp theo."),
    (["cf_init_help"], "Hiển thị hộp thoại xác nhận trước khi khôi phục cài đặt gốc."),
    (["cf_allremove1_help"], "Hiển thị hộp thoại xác nhận trước khi xóa toàn bộ dữ liệu lưu."),

    # E. Các nút điều khiển chung
    (["init"], "Đưa tất cả các cài đặt trên trang này về giá trị mặc định."),
    (["back"], "Đóng menu Cài đặt và quay trở lại màn hình trước."),
]

lines = raw_text.splitlines()
out_lines = []
i = 0
modified_count = 0

while i < len(lines):
    line = lines[i]
    stripped = line.strip()
    
    if not line.startswith("\t") and stripped and not stripped.startswith("#"):
        keys_on_line = [k.strip() for k in stripped.split("\t") if k.strip()]
        
        matched_trans = None
        for rule_keys, new_vn in TRANSLATIONS:
            if any(rk in keys_on_line for rk in rule_keys):
                matched_trans = new_vn
                break
        
        out_lines.append(line)
        i += 1
        
        if i < len(lines) and lines[i].startswith("\t"):
            if matched_trans:
                out_lines.append(f"\t{matched_trans}")
                modified_count += 1
            else:
                out_lines.append(lines[i])
            i += 1
    else:
        out_lines.append(line)
        i += 1

print(f"[1/4] Đã thay thế thành công {modified_count} mục giải thích tiếng Việt!")

# Ghép bằng \r\n chuẩn Kirikiri Windows
final_text = "\r\n".join(out_lines) + "\r\n"
assert not final_text.startswith("\ufeff"), "Lỗi: Không được có BOM ở đầu chuỗi!"
assert final_text.startswith("#"), f"Lỗi: Ký tự đầu tiên phải là '#', nhận được: {final_text[:10]}"

# Encode UTF-16LE without BOM
payload_bytes = final_text.encode("utf-16le")

def bit_swap_16(val):
    return ((val & 0xAAAA) >> 1) | ((val & 0x5555) << 1)

enc_bin = bytearray(b"\xfe\xfe\x01\xff\xfe")
for idx in range(0, len(payload_bytes)-1, 2):
    w = payload_bytes[idx] | (payload_bytes[idx+1] << 8)
    w_swapped = bit_swap_16(w)
    enc_bin.extend(w_swapped.to_bytes(2, "little"))

print(f"[2/4] Đã mã hóa SimpleCrypt chuẩn 100%: {len(enc_bin):,} bytes (Header 5 bytes: {enc_bin[:5].hex()}, First payload word: {enc_bin[5:7].hex()})")
assert enc_bin[:5] == b"\xfe\xfe\x01\xff\xfe"
assert enc_bin[5:7] == b"\x13\x00", f"Byte đầu tiên của payload phải là 0x1300 ('#'), nhận được: {enc_bin[5:7].hex()}"

p606 = CONF_PATCH_DIR / "entry_00606.bin"
p608 = CONF_PATCH_DIR / "entry_00608.bin"

p606.write_bytes(enc_bin)
p608.write_bytes(enc_bin)
print(f"   + [CONF] Đã ghi {p606.name} ({len(enc_bin):,} bytes)")
print(f"   + [CONF] Đã ghi {p608.name} ({len(enc_bin):,} bytes)")

# 3. Chạy repack_viet_hoa_full.py
print("\n[3/4] Chạy repack_viet_hoa_full.py đóng gói vào data.xp3...")
subprocess.run(["C:\\Users\\ADMIN\\AppData\\Local\\Python\\bin\\python.exe", "repack_viet_hoa_full.py"], check=True)

# 4. Sao lưu
print("\n[4/4] Đồng bộ bản sao lưu data.xp3.viet_hoa.bak...")
game_xp3 = Path(r"E:\Games\COCORO.FIXED\game\data.xp3")
bak_xp3 = Path(r"E:\Games\COCORO.FIXED\game\data.xp3.viet_hoa.bak")
shutil.copy2(game_xp3, bak_xp3)
print(f"   + Đã sao lưu thành công sang {bak_xp3.name} ({bak_xp3.stat().st_size:,} bytes)!")

print("\n" + "=" * 70)
print("   HOÀN TẤT 100%! LỖI ĐÃ ĐƯỢC KHẮC PHỤC TRIỆT ĐỂ!   ")
print("=" * 70)
