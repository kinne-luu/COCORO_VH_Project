import json

drip_path = r"E:\Extract Tools\cxdec-hxv4\data\static_recover\drip_program_COCORO.exe.unpacked.json"
try:
    with open(drip_path, 'r', encoding='utf-8') as f:
        data = json.load(f)
    print("Total files in drip:", len(data))
    for k, v in list(data.items())[:20]:
        print(f"  {k} -> {v}")
    
    # Tìm kiếm các file liên quan tới menu hoặc qmenu hoặc side
    matches = {}
    for k, v in data.items():
        if any(term in k.lower() for term in ['qmenu', 'side', 'quick', 'rclick', 'system_menu']):
            matches[k] = v
    print(f"\nMatching files ({len(matches)}):")
    for k, v in matches.items():
        print(f"  {k} -> {v}")
except Exception as e:
    print("Error reading drip:", e)
