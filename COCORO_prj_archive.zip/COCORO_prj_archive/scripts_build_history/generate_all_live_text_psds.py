# -*- coding: utf-8 -*-
"""
Tự động tạo các file PSD chứa Live Text Layer (chữ sống) qua Photoshop COM:
1. Mở từng file PSD từ 01_PSD_Chinh_Sua_Hieu_Ung
2. Giữ nguyên 100% các layer ảnh/bitmap cũ để người dùng đối chiếu
3. Thêm các Group chứa Text Layer chữ sống (Live Text):
   - Đúng nội dung tiếng Việt
   - Căn giữa (Center Justification)
   - Đặt đúng tọa độ tâm, kích thước font, màu sắc
4. Lưu thành file PSD hoàn chỉnh vào thư mục riêng:
   01_PSD_Live_Text_Chinh_Sua
"""

import os
import sys
import shutil
import win32com.client
from pathlib import Path

BASE_DIR = Path(r"D:\Workspace\Creative\2D\Projects\Photoshop\COCORO Prj\wireframe_guide")
SRC_DIR = BASE_DIR / "01_PSD_Chinh_Sua_Hieu_Ung"
OUT_DIR = BASE_DIR / "01_PSD_Live_Text_Chinh_Sua"
OUT_DIR.mkdir(parents=True, exist_ok=True)

print("=" * 70)
print("   BẮT ĐẦU TẠO BỘ FILE PSD LIVE TEXT (CHỮ SỐNG) QUA PHOTOSHOP COM   ")
print("=" * 70)

ps = win32com.client.Dispatch("Photoshop.Application")
# Thiết lập đơn vị đo
ps.Preferences.RulerUnits = 1 # psPixels
ps.Preferences.TypeUnits  = 1 # psPoints

def make_color(hex_str):
    c = win32com.client.Dispatch("Photoshop.SolidColor")
    c.RGB.HexValue = hex_str
    return c

def add_live_text(parent_group, text, x, y, size_pt, hex_color, justification=2, font_name="STIXTwoText-Bold"):
    layer = parent_group.ArtLayers.Add()
    layer.Name = f"[LiveText] {text}"
    layer.Kind = 2 # psTextLayer
    ti = layer.TextItem
    ti.Contents = text
    try:
        ti.Font = font_name
    except:
        ti.Font = "TimesNewRomanPS-BoldMT"
    ti.Size = size_pt
    ti.Position = [x, y]
    ti.Justification = justification # 2 = psCenter, 1 = psLeft
    ti.Color = make_color(hex_color)
    return layer

# ======================================================================
# 1. TITLE MENU (title_template_guide.psd)
# ======================================================================
print("\n[1/3] Tạo Live Text cho Title Menu (title_template_guide.psd)...")
title_src = SRC_DIR / "title_template_guide.psd"
title_out = OUT_DIR / "title_template_guide.psd"

if title_src.exists():
    doc = ps.Open(str(title_src))
    
    # 1. Group Live Text Hover (Cột 2: x=350 + cw/2)
    grp_hover = doc.LayerSets.Add()
    grp_hover.Name = "[LIVE_TEXT_HOVER] (Chữ Sống - Cột Phải)"
    
    # 2. Group Live Text Normal (Cột 1: x=90 + cw/2)
    grp_normal = doc.LayerSets.Add()
    grp_normal.Name = "[LIVE_TEXT_NORMAL] (Chữ Sống - Cột Trái)"
    
    title_buttons = [
        # (text, row, cw)
        ("TIẾP TỤC", 0, 191),
        ("BẮT ĐẦU",  1, 160),
        ("TẢI",      2, 125),
        ("TÙY CHỌN", 3, 164),
        ("MỞ RỘNG",  4, 160),
        ("THOÁT",    5, 115),
        ("THƯ VIỆN", 6, 170),
        ("NHẠC",     7, 140),
        ("AFTER",    8, 160),
        ("ĐỘI NGŨ",  9, 142),
        ("TRỞ LẠI",  10, 130),
    ]
    
    for text, row, cw in title_buttons:
        base_y = 30 + row * 64 + 34
        norm_x = 90 + cw // 2
        hov_x  = 350 + cw // 2
        
        # Chữ sống Normal (Màu xám đậm #373737)
        add_live_text(grp_normal, text, norm_x, base_y, 24, "373737", justification=2)
        
        # Chữ sống Hover (Màu trắng #FFFFFF)
        add_live_text(grp_hover, text, hov_x, base_y, 24, "FFFFFF", justification=2)
        
    doc.SaveAs(str(title_out))
    doc.Close(2) # psDoNotSaveChanges
    print(f"   + Đã xuất thành công: {title_out.name} ({title_out.stat().st_size:,} bytes)!")

# ======================================================================
# 2. CONFIG BASE (config_base_template_guide.psd)
# ======================================================================
print("\n[2/3] Tạo Live Text cho Tab Base Cài Đặt (config_base_template_guide.psd)...")
cfg_src = SRC_DIR / "config_base_template_guide.psd"
cfg_out = OUT_DIR / "config_base_template_guide.psd"

if cfg_src.exists():
    doc = ps.Open(str(cfg_src))
    
    grp_hover = doc.LayerSets.Add()
    grp_hover.Name = "[LIVE_TEXT_HOVER] (Chữ Sống Sáng - Hàng Dưới)"
    
    grp_normal = doc.LayerSets.Add()
    grp_normal.Name = "[LIVE_TEXT_NORMAL] (Chữ Sống Thường - Hàng Trên)"
    
    tabs = [
        ("HIỂN THỊ", 115),
        ("VĂN BẢN",  335),
        ("HỘI THOẠI",555),
        ("ÂM THANH", 775),
        ("GIỌNG NÓI",995),
    ]
    
    for text, center_x in tabs:
        # Hàng 1 (Normal): y = 351
        add_live_text(grp_normal, text, center_x, 351, 28, "A0B4C3", justification=2)
        
        # Hàng 2 (Hover): y = 411
        add_live_text(grp_hover, text, center_x, 411, 28, "FFFFFF", justification=2)
        
    doc.SaveAs(str(cfg_out))
    doc.Close(2)
    print(f"   + Đã xuất thành công: {cfg_out.name} ({cfg_out.stat().st_size:,} bytes)!")

# ======================================================================
# 3. DIALOG CONFIRM (dialog_confirm_guide.psd)
# ======================================================================
print("\n[3/3] Tạo Live Text cho Hộp thoại xác nhận (dialog_confirm_guide.psd)...")
dlg_src = SRC_DIR / "dialog_confirm_guide.psd"
dlg_out = OUT_DIR / "dialog_confirm_guide.psd"

if dlg_src.exists():
    doc = ps.Open(str(dlg_src))
    
    grp_live = doc.LayerSets.Add()
    grp_live.Name = "[LIVE_TEXT_POPUP] (Chữ Sống Hộp Thoại)"
    
    dlg_items = [
        ("cf_allremove1", "Xác nhận xóa toàn bộ dữ liệu"),
        ("cf_allremove2", "Xác nhận xóa toàn bộ thiết lập"),
        ("cf_backto",     "Xác nhận trở về trước đó"),
        ("cf_delete",     "Xác nhận xóa file lưu"),
        ("cf_exit",       "Xác nhận thoát trò chơi"),
        ("cf_init",       "Xác nhận khôi phục mặc định"),
        ("cf_jump",       "Xác nhận nhảy đến cảnh"),
        ("cf_load",       "Xác nhận tải file lưu"),
        ("cf_next",       "Xác nhận chuyển cảnh tiếp"),
        ("cf_overwrite",  "Xác nhận ghi đè file lưu"),
        ("cf_qload",      "Xác nhận tải nhanh"),
        ("cf_qsave",      "Xác nhận lưu nhanh"),
        ("cf_title",      "Xác nhận về màn hình chính")
    ]
    
    for idx, (k, text) in enumerate(dlg_items):
        ly = idx * 55 + 32
        add_live_text(grp_live, text, 900, ly, 30, "32373C", justification=1)
        
    doc.SaveAs(str(dlg_out))
    doc.Close(2)
    print(f"   + Đã xuất thành công: {dlg_out.name} ({dlg_out.stat().st_size:,} bytes)!")

# Sao chép các file PSD còn lại sang folder mới để đầy đủ 100%
for f in SRC_DIR.glob("*.psd"):
    dst = OUT_DIR / f.name
    if not dst.exists():
        shutil.copy2(f, dst)

ps.Quit()

print("\n" + "=" * 70)
print("   HOÀN TẤT TẠO BỘ PSD LIVE TEXT CHỮ SỐNG CHUYÊN NGHIỆP!   ")
print("=" * 70)
