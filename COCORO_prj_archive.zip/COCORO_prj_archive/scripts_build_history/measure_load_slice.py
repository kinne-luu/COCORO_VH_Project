from PIL import Image
import numpy as np

im_user = Image.open("image/UI_Da_Sua/entry_02055_5806.png").convert("RGBA")
im_orig = Image.open("image/UI_Raw/entry_02055_5806.png").convert("RGBA")

# Đo mép trái viên thuốc của load (normal, on, over) trong im_user và im_orig
for st_name, (cx, cy, cw, ch) in [('normal', (0, 177, 343, 59)), ('on', (343, 177, 343, 59)), ('over', (0, 236, 343, 59))]:
    crop_u = im_user.crop((cx, cy, cx+cw, cy+ch))
    crop_o = im_orig.crop((cx, cy, cx+cw, cy+ch))
    
    arr_u = np.array(crop_u)
    arr_o = np.array(crop_o)
    
    # Tìm mép trái ở dòng y = 29
    xs_u = np.where(arr_u[29, :, 3] > 100)[0]
    xs_o = np.where(arr_o[29, :, 3] > 100)[0]
    
    icon_u = np.where((arr_u[29, :, 0] > 180) & (arr_u[29, :, 1] > 180) & (arr_u[29, :, 2] > 180))[0]
    icon_o = np.where((arr_o[29, :, 0] > 180) & (arr_o[29, :, 1] > 180) & (arr_o[29, :, 2] > 180))[0]
    
    print(f"load ({st_name}):")
    print(f"  User: capsule_left={xs_u[0] if len(xs_u)>0 else None}, icon_left={icon_u[0] if len(icon_u)>0 else None}")
    print(f"  Orig: capsule_left={xs_o[0] if len(xs_o)>0 else None}, icon_left={icon_o[0] if len(icon_o)>0 else None}")
