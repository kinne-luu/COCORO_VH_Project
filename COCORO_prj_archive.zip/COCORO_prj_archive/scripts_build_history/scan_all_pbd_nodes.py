import json

with open("orig_fresh/entry_01978.json", "r", encoding="utf-8") as f:
    pbd = json.load(f)

def scan(node, path=""):
    if isinstance(node, dict):
        uiname = node.get("uiname", "")
        curr = f"{path}/{uiname}" if uiname else path
        x = node.get("x", None)
        y = node.get("y", None)
        w = node.get("w", None)
        h = node.get("h", None)
        st = node.get("uistates", {})
        if st:
            for sname, sval in st.items():
                storage = sval.get("storage")
                if storage:
                    print(f"{curr} [{sname}]: x={x}, y={y}, w={w}, h={h}, stg={storage}, (cx,cy,cw,ch)={(sval.get('cx'), sval.get('cy'), sval.get('cw'), sval.get('ch'))}, (ox,oy)={(sval.get('ox'), sval.get('oy'))}")
        for k, v in node.items():
            if k != "uistates":
                scan(v, curr)
    elif isinstance(node, list):
        for i, it in enumerate(node):
            scan(it, f"{path}[{i}]")

scan(pbd.get("result", {}))
