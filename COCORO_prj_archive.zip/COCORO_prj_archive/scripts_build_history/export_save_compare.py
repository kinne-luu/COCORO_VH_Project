from PIL import Image

im_orig = Image.open("image/UI_Raw/entry_02055_5806.png").convert("RGBA")
im_user = Image.open("image/UI_Da_Sua/entry_02055_5806.png").convert("RGBA")

# Save normal
crop_orig_norm = im_orig.crop((343, 649, 343+59, 649+343))
crop_user_norm = im_user.crop((343, 649, 343+59, 649+343))

# Thử xoay
for rot_name, rot in [("rot90", Image.Transpose.ROTATE_90), ("rot270", Image.Transpose.ROTATE_270)]:
    crop_orig_norm.transpose(rot).save(f"orig_save_{rot_name}.png")
    crop_user_norm.transpose(rot).save(f"user_save_{rot_name}.png")

# Load normal (không xoay)
im_orig.crop((0, 177, 343, 177+59)).save("orig_load.png")
im_user.crop((0, 177, 343, 177+59)).save("user_load.png")
