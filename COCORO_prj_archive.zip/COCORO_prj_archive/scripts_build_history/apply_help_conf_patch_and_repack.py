import subprocess
import shutil
from pathlib import Path

ROOT_DIR = Path(r"D:\Software\Antigravity\Project\Cocoro")
CONF_PATCH_DIR = ROOT_DIR / "COCORO_Patch_VietHoa" / "patch_data" / "conf"
CONF_PATCH_DIR.mkdir(parents=True, exist_ok=True)

def bit_swap_16(val):
    return ((val & 0xAAAA) >> 1) | ((val & 0x5555) << 1)

def encode_krkr_mode1_utf16(text_str):
    # Header: 5 bytes FE FE 01 FF FE
    header = bytes([0xFE, 0xFE, 0x01, 0xFF, 0xFE])
    # Encode UTF-16LE without BOM
    raw_utf16 = text_str.encode('utf-16le')
    payload = bytearray()
    for i in range(0, len(raw_utf16)-1, 2):
        w = raw_utf16[i] | (raw_utf16[i+1] << 8)
        w_swapped = bit_swap_16(w)
        payload.extend(w_swapped.to_bytes(2, 'little'))
    return header + bytes(payload)

print("=" * 70)
print("   ĐÓNG GÓI CHUỖI GIẢI THÍCH (TOOLTIP GUIDE TEXT) VÀO GAME   ")
print("=" * 70)

# 1. Đọc bản text Việt hóa
txt_path = ROOT_DIR / "help_conf_viet_hoa.txt"
text_vn = txt_path.read_text(encoding="utf-16le")

# 2. Mã hóa Kirikiri Mode 1 (SimpleCrypt)
encoded_bin = encode_krkr_mode1_utf16(text_vn)
print(f"[1/3] Đã mã hóa help_conf_viet_hoa.txt thành {len(encoded_bin):,} bytes nhị phân chuẩn Kirikiri Mode 1!")

# 3. Ghi ra entry_00606.bin (EN) và entry_00608.bin (JP)
p606 = CONF_PATCH_DIR / "entry_00606.bin"
p608 = CONF_PATCH_DIR / "entry_00608.bin"

p606.write_bytes(encoded_bin)
p608.write_bytes(encoded_bin)
print(f"   + [CONF] Đã tạo {p606.name} ({len(encoded_bin):,} bytes)")
print(f"   + [CONF] Đã tạo {p608.name} ({len(encoded_bin):,} bytes)")

# 4. Chạy repack_viet_hoa_full.py
print("\n[2/3] Chạy repack_viet_hoa_full.py để đóng gói hoàn thiện vào data.xp3...")
subprocess.run(["C:\\Users\\ADMIN\\AppData\\Local\\Python\\bin\\python.exe", "repack_viet_hoa_full.py"], check=True)

# 5. Cập nhật bản sao lưu data.xp3.viet_hoa.bak
print("\n[3/3] Đồng bộ bản sao lưu data.xp3.viet_hoa.bak...")
game_xp3 = Path(r"E:\Games\COCORO.FIXED\game\data.xp3")
bak_xp3 = Path(r"E:\Games\COCORO.FIXED\game\data.xp3.viet_hoa.bak")
shutil.copy2(game_xp3, bak_xp3)
print(f"   + Đã sao lưu thành công sang {bak_xp3.name} ({bak_xp3.stat().st_size:,} bytes)!")

print("\n" + "=" * 70)
print("   HOÀN TẤT 100%! TOOLTIP GUIDE TEXT ĐÃ SẴN SÀNG TRONG GAME!   ")
print("=" * 70)
