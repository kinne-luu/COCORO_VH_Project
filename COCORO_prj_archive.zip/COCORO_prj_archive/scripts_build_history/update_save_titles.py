import zlib
import json
import struct
from pathlib import Path

ksd_path = Path(r"E:\Games\COCORO.FIXED\game\SteamData\datasc.ksd")
raw = ksd_path.read_bytes()
zpos = raw.find(b"\x78\x9c")
header = raw[:zpos]
decomp = zlib.decompress(raw[zpos:])
text = decomp.decode("utf-16le", errors="ignore")

titles_path = Path(r"D:\Software\Antigravity\Project\Cocoro\COCORO_Translate\config\scene_titles.json")
with open(titles_path, "r", encoding="utf-8") as f:
    titles = json.load(f)

new_text = text
for scn, t in titles.items():
    en = t["en"]
    vi = t["vi"]
    target = f'"{en}"'
    if target in new_text:
        print(f"Replacing {en} -> {vi}")
        new_text = new_text.replace(target, f'"{vi}"')

if new_text != text:
    print("Updating datasc.ksd...")
    new_decomp = new_text.encode("utf-16le")
    new_compressed = zlib.compress(new_decomp)
    new_header = bytearray(header)
    struct.pack_into("<Q", new_header, 5, len(new_decomp))
    struct.pack_into("<Q", new_header, 13, len(new_compressed))
    ksd_path.write_bytes(bytes(new_header) + new_compressed)
    print("datasc.ksd updated successfully!")
else:
    print("No matching English titles found in datasc.ksd!")
