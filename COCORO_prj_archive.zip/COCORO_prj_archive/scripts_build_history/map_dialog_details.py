import json

d = json.load(open(r"D:\Software\Antigravity\Project\Cocoro\temp_pbd_dumps\entry_01998_57cd.json", encoding="utf-8"))
packlist = d["packlist"]
result = d["result"]

slice_map = {}
for k, v in result.items():
    if isinstance(v, dict):
        for sk, sv in v.get("uistates", {}).items():
            if isinstance(sv, dict) and sv.get("cx") is not None:
                cx, cy, cw, ch = sv["cx"], sv["cy"], sv["cw"], sv["ch"]
                for s_idx, s in enumerate(packlist):
                    if s[0] == cx and s[1] == cy and s[2] == cw and s[3] == ch:
                        slice_map[s_idx] = (k, sk, cx, cy, cw, ch, sv.get("ox"), sv.get("oy"))

print("=== DIALOG SLICE TO STATE MAPPING ===")
for s_idx in range(len(packlist)):
    node, state, cx, cy, cw, ch, ox, oy = slice_map[s_idx]
    print(f"Slice {s_idx:2d} -> {node:10s} {state:15s} (cx={cx:3d}, cy={cy:3d}, cw={cw:3d}, ch={ch:3d}, ox={ox:2d}, oy={oy:2d})")
