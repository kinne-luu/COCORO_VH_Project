# -*- coding: utf-8 -*-
"""
COCORO - Build Voice Setting (Config Page 4) Guide System (Font Size 50 - Match English Screenshot)
Target Folder: D:\Workspace\Creative\2D\Projects\Photoshop\COCORO Prj\wireframe_guide
"""

import sys
import os
import json
import subprocess
from pathlib import Path
import numpy as np
from PIL import Image, ImageDraw, ImageFont
import pytoshop
from pytoshop.user import nested_layers

# Paths
ROOT_DIR = Path(r"D:\Software\Antigravity\Project\Cocoro")
OUTPUT_DIR = Path(r"D:\Workspace\Creative\2D\Projects\Photoshop\COCORO Prj\wireframe_guide")

RAW_EN_TLG = ROOT_DIR / "extracted_data" / "data" / "entry_01986_57c1.bin"
PBD_JP_JSON = ROOT_DIR / "temp_pbd_dumps" / "entry_01989_57c4.json"
PBD_JP_BIN = ROOT_DIR / "extracted_data" / "data" / "entry_01989_57c4.bin"

PBD_EN_JSON = ROOT_DIR / "temp_pbd_dumps" / "entry_01987_57c2.json"
PBD_EN_BIN = ROOT_DIR / "extracted_data" / "data" / "entry_01987_57c2.bin"

MSG_TOOL = ROOT_DIR / "tools" / "msg-tool" / "msg_tool.exe"
REPACK_SCRIPT = ROOT_DIR / "repack_viet_hoa_full.py"
USER_PYTHON = Path(r"C:\Users\ADMIN\AppData\Local\Python\bin\python.exe")

OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

CANVAS_W = 680
CANVAS_H = 600

# Export clean EN atlas
clean_en_png = Path("temp_clean_en_atlas.png")
subprocess.run([str(MSG_TOOL), "export", "-t", "kirikiri-tlg", str(RAW_EN_TLG), str(clean_en_png)], capture_output=True)
raw_en_img = Image.open(clean_en_png).convert("RGBA")

LAYOUT_DEFS = {
    # Buttons (Column 1: x=30, w=282, h=66)
    3:  {"name": "on_off",   "x": 30, "y": 30,  "w": 282, "h": 66, "type": "btn", "orig_y": 198, "label": "BẬT (OFF)"},
    4:  {"name": "on_on",    "x": 30, "y": 110, "w": 282, "h": 66, "type": "btn", "orig_y": 264, "label": "BẬT (ON)"},
    5:  {"name": "on_over",  "x": 30, "y": 190, "w": 282, "h": 66, "type": "btn", "orig_y": 330, "label": "BẬT (HOVER)"},
    0:  {"name": "off_off",  "x": 30, "y": 290, "w": 282, "h": 66, "type": "btn", "orig_y": 0,   "label": "TẮT (OFF)"},
    1:  {"name": "off_on",   "x": 30, "y": 370, "w": 282, "h": 66, "type": "btn", "orig_y": 66,  "label": "TẮT (ON)"},
    2:  {"name": "off_over", "x": 30, "y": 450, "w": 282, "h": 66, "type": "btn", "orig_y": 132, "label": "TẮT (HOVER)"},
    
    # Character Names (Column 2: x=360, w=280, h=50) - Kích thước to chuẩn bản gốc
    6:  {"name": "chv0", "x": 360, "y": 30,  "w": 280, "h": 50, "type": "name", "char": "Cocoro",  "label": "Nhân vật 0 - Cocoro"},
    7:  {"name": "chv1", "x": 360, "y": 90,  "w": 280, "h": 50, "type": "name", "char": "Kazane",  "label": "Nhân vật 1 - Kazane"},
    8:  {"name": "chv2", "x": 360, "y": 150, "w": 280, "h": 50, "type": "name", "char": "Kosame",  "label": "Nhân vật 2 - Kosame"},
    9:  {"name": "chv3", "x": 360, "y": 210, "w": 280, "h": 50, "type": "name", "char": "Kirika",  "label": "Nhân vật 3 - Kirika"},
    10: {"name": "chv4", "x": 360, "y": 270, "w": 280, "h": 50, "type": "name", "char": "Daichi",  "label": "Nhân vật 4 - Daichi"},
    11: {"name": "chv5", "x": 360, "y": 330, "w": 280, "h": 50, "type": "name", "char": "Kotaro",  "label": "Nhân vật 5 - Kotaro"},
    12: {"name": "chv6", "x": 360, "y": 390, "w": 280, "h": 50, "type": "name", "char": "Raita",   "label": "Nhân vật 6 - Raita"},
    13: {"name": "chv7", "x": 360, "y": 450, "w": 280, "h": 50, "type": "name", "char": "Khác",   "label": "Nhân vật 7 - Khác"},
    14: {"name": "chv8", "x": 360, "y": 510, "w": 280, "h": 50, "type": "name", "char": "Phụ",    "label": "Nhân vật 8 - Phụ"},
}

print("[1] Khởi tạo Canvas...")
atlas_base = Image.new("RGBA", (CANVAS_W, CANVAS_H), (0, 0, 0, 0))
atlas_guide = Image.new("RGBA", (CANVAS_W, CANVAS_H), (0, 0, 0, 0))
guide_draw = ImageDraw.Draw(atlas_guide)

font_path = Path(r"C:\Windows\Fonts\timesbd.ttf")
if not font_path.exists():
    font_path = Path(r"C:\Windows\Fonts\arialbd.ttf")
small_font = ImageFont.truetype(str(font_path), 11)
name_font = ImageFont.truetype(str(font_path), 48)

guide_draw.text((30, 10), "=== CỘT 1: NÚT BẬT / TẮT (ON / OFF TOGGLE) ===", font=small_font, fill=(100, 255, 255, 255))
guide_draw.text((360, 10), "=== CỘT 2: 9 TÊN NHÂN VẬT (CHARACTER NAMES) ===", font=small_font, fill=(255, 180, 255, 255))

manifest = {"canvas_size": [CANVAS_W, CANVAS_H], "slices": {}}

print("[2] Bố trí nút ON/OFF gốc sạch và render chữ tên nhân vật size 48...")
for s_idx, d in LAYOUT_DEFS.items():
    nx, ny, nw, nh = d["x"], d["y"], d["w"], d["h"]
    sname = d["name"]
    stype = d["type"]
    label = d["label"]
    
    if stype == "btn":
        orig_y = d["orig_y"]
        btn_patch = raw_en_img.crop((0, orig_y, 282, orig_y + 66))
        atlas_base.paste(btn_patch, (nx, ny), btn_patch)
        
        guide_draw.rectangle([nx, ny, nx + nw - 1, ny + nh - 1], outline=(255, 40, 40, 255), width=1)
        guide_draw.rectangle([nx + 4, ny + 4, nx + nw - 5, ny + nh - 5], outline=(0, 230, 80, 200), width=1)
        guide_draw.text((nx, ny - 14), f"[{s_idx:02d}:{sname}] {label} ({nw}x{nh})", font=small_font, fill=(255, 230, 0, 255))
        
        ref_arr = np.array(btn_patch)
        ref_arr[:, :, 3] = (ref_arr[:, :, 3] * 0.35).astype(np.uint8)
        ref_dim = Image.fromarray(ref_arr)
        atlas_guide.paste(ref_dim, (nx, ny), ref_dim)
    else:
        char_name = d["char"]
        name_img = Image.new("RGBA", (nw, nh), (0, 0, 0, 0))
        ndraw = ImageDraw.Draw(name_img)
        bbox = ndraw.textbbox((0, 0), char_name, font=name_font)
        tw = bbox[2] - bbox[0]
        th = bbox[3] - bbox[1]
        tx = 0
        ty = (nh - th) // 2 - bbox[1]
        ndraw.text((tx, ty), char_name, font=name_font, fill=(45, 50, 55, 255))
        atlas_base.paste(name_img, (nx, ny), name_img)
        
        guide_draw.rectangle([nx, ny, nx + nw - 1, ny + nh - 1], outline=(255, 40, 40, 255), width=1)
        guide_draw.rectangle([nx + 4, ny + 4, nx + nw - 5, ny + nh - 5], outline=(0, 230, 80, 200), width=1)
        guide_draw.text((nx, ny - 14), f"[{s_idx:02d}:{sname}] {label} ({nw}x{nh})", font=small_font, fill=(255, 230, 0, 255))
        
    manifest["slices"][s_idx] = {
        "uiname": sname,
        "type": stype,
        "label": label,
        "cx": nx, "cy": ny, "cw": nw, "ch": nh
    }

guide_path = OUTPUT_DIR / "config_p4_atlas_guide.png"
base_path = OUTPUT_DIR / "config_p4_atlas_base.png"
manifest_path = OUTPUT_DIR / "config_p4_manifest.json"

atlas_guide.save(guide_path)
atlas_base.save(base_path)
with open(manifest_path, "w", encoding="utf-8") as f:
    json.dump(manifest, f, indent=2, ensure_ascii=False)

print(f"[+] Đã lưu {guide_path.name}")
print(f"[+] Đã lưu {base_path.name}")
print(f"[+] Đã lưu {manifest_path.name}")

def pil_to_pytoshop_layer(pil_img, name, left, top):
    arr = np.array(pil_img)
    h, w = arr.shape[:2]
    return nested_layers.Image(
        name=name,
        top=top,
        left=left,
        bottom=top + h,
        right=left + w,
        channels={
            0: arr[:, :, 0],
            1: arr[:, :, 1],
            2: arr[:, :, 2],
            -1: arr[:, :, 3]
        }
    )

print("[3] Tạo file PSD nhiều layer chuyên nghiệp...")
wire_img_layer = pil_to_pytoshop_layer(atlas_guide, "Khung_Wireframe_Va_Nhan (TẮT MẮT KHI XUẤT PNG)", 0, 0)
group_guide = nested_layers.Group(
    name="[HUONG_DAN_WIREFRAME] (TẮT MẮT KHI XUẤT PNG)",
    layers=[wire_img_layer],
    closed=False
)

btn_sublayers = []
for s_idx in [3, 4, 5, 0, 1, 2]:
    d = LAYOUT_DEFS[s_idx]
    nx, ny, nw, nh = d["x"], d["y"], d["w"], d["h"]
    crop = atlas_base.crop((nx, ny, nx + nw, ny + nh))
    btn_sublayers.append(pil_to_pytoshop_layer(crop, f"Slice_{s_idx:02d}_{d['name']}", nx, ny))

group_buttons = nested_layers.Group(
    name="[ON_OFF_BUTTONS] (Nút Bật Tắt Voice)",
    layers=btn_sublayers,
    closed=True
)

name_sublayers = []
for s_idx in range(6, 15):
    d = LAYOUT_DEFS[s_idx]
    nx, ny, nw, nh = d["x"], d["y"], d["w"], d["h"]
    crop = atlas_base.crop((nx, ny, nx + nw, ny + nh))
    name_sublayers.append(pil_to_pytoshop_layer(crop, f"Slice_{s_idx:02d}_{d['char']}", nx, ny))

group_names = nested_layers.Group(
    name="[CHARACTER_NAMES] (9 Tên Nhân Vật)",
    layers=name_sublayers,
    closed=False
)

psd = nested_layers.nested_layers_to_psd(
    [group_guide, group_buttons, group_names],
    color_mode=3,
    size=(CANVAS_W, CANVAS_H),
    compression=0
)

psd_output_path = OUTPUT_DIR / "config_p4_template_guide.psd"
with open(psd_output_path, "wb") as f:
    psd.write(f)
print(f"[+] Đã tạo file PSD: {psd_output_path}")

print("[4] Đồng bộ tọa độ PBD (JP 1989 và EN 1987)...")
def sync_pbd(json_path, bin_path, out_bin_path):
    with open(json_path, "r", encoding="utf-8") as f:
        pbd = json.load(f)
    
    packlist = pbd.get("packlist", [])
    
    for s_idx, d in LAYOUT_DEFS.items():
        if s_idx < len(packlist):
            p = packlist[s_idx]
            p[0] = d["x"]
            p[1] = d["y"]
            p[2] = d["w"]
            p[3] = d["h"]
            if len(p) > 7:
                p[7] = None
    
    def update_node(node):
        if isinstance(node, dict):
            uiname = node.get("uiname", "")
            if "uistates" in node:
                states = node["uistates"]
                if "_off" in uiname:
                    if "off" in states:
                        states["off"].update({"cx": LAYOUT_DEFS[0]["x"], "cy": LAYOUT_DEFS[0]["y"], "cw": LAYOUT_DEFS[0]["w"], "ch": LAYOUT_DEFS[0]["h"], "w": 282, "h": 66, "cr": None})
                    if "on" in states:
                        states["on"].update({"cx": LAYOUT_DEFS[1]["x"], "cy": LAYOUT_DEFS[1]["y"], "cw": LAYOUT_DEFS[1]["w"], "ch": LAYOUT_DEFS[1]["h"], "w": 282, "h": 66, "cr": None})
                    if "over" in states:
                        states["over"].update({"cx": LAYOUT_DEFS[2]["x"], "cy": LAYOUT_DEFS[2]["y"], "cw": LAYOUT_DEFS[2]["w"], "ch": LAYOUT_DEFS[2]["h"], "w": 282, "h": 66, "cr": None})
                elif "_on" in uiname:
                    if "off" in states:
                        states["off"].update({"cx": LAYOUT_DEFS[3]["x"], "cy": LAYOUT_DEFS[3]["y"], "cw": LAYOUT_DEFS[3]["w"], "ch": LAYOUT_DEFS[3]["h"], "w": 282, "h": 66, "cr": None})
                    if "on" in states:
                        states["on"].update({"cx": LAYOUT_DEFS[4]["x"], "cy": LAYOUT_DEFS[4]["y"], "cw": LAYOUT_DEFS[4]["w"], "ch": LAYOUT_DEFS[4]["h"], "w": 282, "h": 66, "cr": None})
                    if "over" in states:
                        states["over"].update({"cx": LAYOUT_DEFS[5]["x"], "cy": LAYOUT_DEFS[5]["y"], "cw": LAYOUT_DEFS[5]["w"], "ch": LAYOUT_DEFS[5]["h"], "w": 282, "h": 66, "cr": None})
                elif "head_chv" in uiname:
                    for i in range(9):
                        chv_key = f"chv{i}"
                        if chv_key in states:
                            st = states[chv_key]
                            layout = LAYOUT_DEFS[6 + i]
                            st.update({
                                "cx": layout["x"],
                                "cy": layout["y"],
                                "cw": layout["w"],
                                "ch": layout["h"],
                                "w": layout["w"],
                                "h": layout["h"],
                                "cr": None
                            })
            for k, v in node.items():
                if k != "uistates":
                    update_node(v)
        elif isinstance(node, list):
            for item in node:
                update_node(item)
                
    update_node(pbd.get("result", {}))
    
    synced_json_path = json_path.parent / (json_path.stem + "_synced.json")
    with open(synced_json_path, "w", encoding="utf-8") as f:
        json.dump(pbd, f, indent=2, ensure_ascii=False)
        
    out_bin_path.parent.mkdir(parents=True, exist_ok=True)
    cmd = [str(MSG_TOOL), "import", "-t", "kirikiri-tjs-ns0", str(bin_path), str(synced_json_path), str(out_bin_path)]
    res = subprocess.run(cmd, capture_output=True, text=True)
    assert res.returncode == 0, f"Lỗi biên dịch PBD {json_path.name}: {res.stderr}"
    print(f"[+] Biên dịch PBD thành công -> {out_bin_path.name} ({out_bin_path.stat().st_size:,} bytes)")

pbd_jp_out = ROOT_DIR / "COCORO_Patch_VietHoa" / "patch_data" / "pbd" / "entry_01989.bin"
sync_pbd(PBD_JP_JSON, PBD_JP_BIN, pbd_jp_out)

pbd_en_out = ROOT_DIR / "COCORO_Patch_VietHoa" / "patch_data" / "pbd" / "entry_01987.bin"
sync_pbd(PBD_EN_JSON, PBD_EN_BIN, pbd_en_out)

print("[5] Chuyển đổi atlas base PNG sang TLG5...")
tlg_output_dir = ROOT_DIR / "tlg_msgtool"
patch_ui_dir = ROOT_DIR / "COCORO_Patch_VietHoa" / "patch_data" / "ui"
tlg_output_dir.mkdir(parents=True, exist_ok=True)
patch_ui_dir.mkdir(parents=True, exist_ok=True)

# 1988 (JP)
tlg_output_file = tlg_output_dir / "entry_01988_57c3.tlg"
cmd = [str(MSG_TOOL), "import", "-t", "kirikiri-tlg", str(ROOT_DIR / "extracted_data" / "data" / "entry_01988_57c3.bin"), str(base_path), str(tlg_output_file)]
res = subprocess.run(cmd, capture_output=True, text=True)
assert res.returncode == 0, f"Lỗi chuyển TLG 1988: {res.stderr}"
(patch_ui_dir / "entry_01988.bin").write_bytes(tlg_output_file.read_bytes())
print(f"[+] Đã tạo TLG 1988: {tlg_output_file.stat().st_size:,} bytes")

# 1986 (EN)
tlg_en_output_file = tlg_output_dir / "entry_01986_57c1.tlg"
cmd_en = [str(MSG_TOOL), "import", "-t", "kirikiri-tlg", str(RAW_EN_TLG), str(base_path), str(tlg_en_output_file)]
res_en = subprocess.run(cmd_en, capture_output=True, text=True)
assert res_en.returncode == 0, f"Lỗi chuyển TLG 1986: {res_en.stderr}"
(patch_ui_dir / "entry_01986.bin").write_bytes(tlg_en_output_file.read_bytes())
print(f"[+] Đã tạo TLG 1986: {tlg_en_output_file.stat().st_size:,} bytes")

print("[6] Đóng gói vào data.xp3 của game...")
repack_cmd = [str(USER_PYTHON), str(REPACK_SCRIPT)]
res = subprocess.run(repack_cmd, capture_output=True, text=True)
print(res.stdout)
if res.returncode != 0:
    print("[-] Lỗi repack:", res.stderr)
else:
    print("[+] Hoàn tất đóng gói toàn diện Title + Voice Setting vào game!")
