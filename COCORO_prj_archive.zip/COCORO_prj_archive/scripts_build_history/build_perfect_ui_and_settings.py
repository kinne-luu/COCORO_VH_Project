# -*- coding: utf-8 -*-
"""
COCORO - Full Settings & Dialog & Tab Base Polishing Script
1. Popup Confirm Dialog (entry_01997_57cc):
   - Căn giữa tuyệt đối câu hỏi xác nhận theo tâm popup (x=960)
   - Tăng cỡ chữ lên font STIX Two Text Bold size 24 (to rõ, sắc nét, sang trọng)
   - Đầy đủ các câu hỏi: Tải bản lưu này?, Ghi đè bản lưu này?, Xóa bản lưu này?, v.v.
   - Xuất file PSD dialog_confirm_guide.psd xếp gọn các Layer Group
   - Biên dịch TLG5 entry_01997_57cc.tlg -> patch_data/ui/entry_01997.bin

2. Tab Base Cài Đặt (entry_01948_579b):
   - 5 Tab tách chữ chuẩn: HIỂN THỊ | VĂN BẢN | HỘI THOẠI | ÂM THANH | GIỌNG NÓI
   - Sửa lỗi lặp 2 chữ HộiThoại (tab 3 là HỘI THOẠI, tab 5 là GIỌNG NÓI)
   - 2 trạng thái: chữ xám (normal) và chữ trắng xanh phát sáng (active/hover)
   - Xuất file PSD config_base_template_guide.psd
   - Biên dịch TLG5 entry_01948_579b.tlg -> patch_data/ui/entry_01948.bin

3. Cài Đặt (Display, Text, Dialog, Sound):
   - Loại bỏ TOÀN BỘ dấu mở ngoặc đơn (...)
   - Bám sát 100% bản dịch gốc của người dùng từ PSD
   - Font STIX Two Text Bold cỡ 32, căn lề trái ox=68 đẹp mắt, không đè nút
"""

import sys
import json
import shutil
import subprocess
from pathlib import Path
import numpy as np
from PIL import Image, ImageDraw, ImageFont, ImageFilter
import pytoshop
from pytoshop.user import nested_layers

ROOT_DIR = Path(r"D:\Software\Antigravity\Project\Cocoro")
GUIDE_DIR = Path(r"D:\Workspace\Creative\2D\Projects\Photoshop\COCORO Prj\wireframe_guide")
GUIDE_DIR.mkdir(parents=True, exist_ok=True)
MSG_TOOL = ROOT_DIR / "tools" / "msg-tool" / "msg_tool.exe"
PATCH_UI_DIR = ROOT_DIR / "COCORO_Patch_VietHoa" / "patch_data" / "ui"
PATCH_PBD_DIR = ROOT_DIR / "COCORO_Patch_VietHoa" / "patch_data" / "pbd"
TLG_MSGTOOL_DIR = ROOT_DIR / "tlg_msgtool"
CLEAN_DIR = ROOT_DIR / "true_clean_extracted"

FONT_PATH = Path(r"C:\Users\ADMIN\AppData\Local\Microsoft\Windows\Fonts\STIXTwoText-Bold.ttf")
if not FONT_PATH.exists():
    FONT_PATH = Path(r"C:\Windows\Fonts\timesbd.ttf")

FONT_DIALOG = ImageFont.truetype(str(FONT_PATH), 24)
FONT_TAB_NORMAL = ImageFont.truetype(str(FONT_PATH), 20)
FONT_TAB_HOVER = ImageFont.truetype(str(FONT_PATH), 21)
FONT_SETTING_LABEL = ImageFont.truetype(str(FONT_PATH), 32)
SMALL_FONT = ImageFont.truetype(str(FONT_PATH), 11)

TEXT_COLOR_SETTING = (50, 55, 60, 255)

def pil_to_pytoshop_layer(pil_img, name, left, top):
    arr = np.array(pil_img)
    h, w = arr.shape[:2]
    return nested_layers.Image(
        name=name,
        top=top,
        left=left,
        bottom=top + h,
        right=left + w,
        channels={
            0: arr[:, :, 0],
            1: arr[:, :, 1],
            2: arr[:, :, 2],
            -1: arr[:, :, 3]
        }
    )

print("=" * 70)
print("   BẮT ĐẦU HOÀN THIỆN POPUP DIALOG, TAB BASE VÀ CÁC TRANG CÀI ĐẶT   ")
print("=" * 70)

# ======================================================================
# PHẦN 1: POPUP CONFIRM DIALOG (ENTRY_01997_57cc)
# ======================================================================
print("\n[1/4] Xây dựng Popup Dialog xác nhận (Tải bản lưu này?, v.v.)...")

raw_dialog_img = Image.open(ROOT_DIR / "image" / "UI_Raw" / "entry_01997_57cc.png").convert("RGBA")
user_dialog_img = Image.open(ROOT_DIR / "image" / "UI_Da_Sua" / "entry_01997_57cc.png").convert("RGBA")

# Bắt đầu từ bản của user để giữ các nút Yes/No và checkbox
dialog_atlas = user_dialog_img.copy()

# Căn giữa theo trục popup x=960 (với Node texts x=685)
# x_center_in_box = 960 - (685 + ox)
DIALOG_QUESTIONS = {
    "askload":      {"ox": 145, "box": (0, 418, 271, 30), "text": "Tải bản lưu này?"},
    "askqload":     {"ox": 166, "box": (0, 512, 220, 34), "text": "Tải nhanh?"},
    "askqsave":     {"ox": 169, "box": (313, 353, 212, 34), "text": "Lưu nhanh?"},
    "askoverwrite": {"ox": 95,  "box": (0, 295, 359, 30), "text": "Ghi đè bản lưu này?"},
    "asktitle":     {"ox": 75,  "box": (0, 200, 397, 30), "text": "Về màn hình chính?"},
    "askdelete":    {"ox": 127, "box": (0, 389, 295, 30), "text": "Xóa bản lưu này?"},
    "askexit":      {"ox": 173, "box": (313, 387, 197, 35), "text": "Thoát?"},
    "askjump":      {"ox": 120, "box": (0, 353, 313, 36), "text": "Nhảy tới dòng này?"},
    "askallremove1":{"ox": 98,  "box": (0, 324, 352, 30), "text": "Xóa toàn bộ bản lưu?"},
    "askbackto":    {"ox": 53,  "box": (0, 0, 446, 35),   "text": "Quay về lựa chọn trước?"},
    "asknext":      {"ox": 55,  "box": (0, 35, 439, 35),  "text": "Đi tới lựa chọn kế tiếp?"},
    "askprevscn":   {"ox": 58,  "box": (0, 70, 436, 35),  "text": "Về cảnh trước?"},
    "asknextscn":   {"ox": 61,  "box": (0, 165, 425, 35), "text": "Tới cảnh sau?"},
}

dialog_layers_dict = {}

for q_name, q_info in DIALOG_QUESTIONS.items():
    cx, cy, cw, ch = q_info["box"]
    text = q_info["text"]
    ox = q_info["ox"]
    
    # Xóa sạch ô cũ trong atlas
    blank = Image.new("RGBA", (cw, ch), (0, 0, 0, 0))
    dialog_atlas.paste(blank, (cx, cy))
    
    # Tạo ô text mới
    q_img = Image.new("RGBA", (cw, ch), (0, 0, 0, 0))
    qd = ImageDraw.Draw(q_img)
    
    # Tâm chính xác của khung dialog trên màn hình là x=960
    # Vì x_screen = 685 + ox + x_in_box => x_center = 960 - 685 - ox = 275 - ox
    ideal_center_x = 275 - ox
    # Nếu ideal_center_x nằm ngoài [0, cw], ta căn giữa ô
    if ideal_center_x < 30 or ideal_center_x > cw - 30:
        ideal_center_x = cw // 2
        
    # Baseline nằm ở giữa ô theo chiều dọc
    base_y = ch // 2 + 7
    
    # Vẽ chữ màu trắng sắc nét, anchor='ms' (Middle Horizontal, Baseline Vertical)
    qd.text((ideal_center_x, base_y), text, font=FONT_DIALOG, fill=(255, 255, 255, 255), anchor="ms")
    
    dialog_atlas.paste(q_img, (cx, cy), q_img)
    dialog_layers_dict[q_name] = {"img": q_img, "box": (cx, cy, cx + cw, cy + ch), "text": text}

# Save dialog PNG
dialog_png_path = GUIDE_DIR / "dialog_atlas_base.png"
dialog_atlas.save(dialog_png_path)
dialog_atlas.save(ROOT_DIR / "image" / "UI_Da_Sua" / "entry_01997_57cc.png")

# Build layered PSD for dialog
dialog_sublayers = [pil_to_pytoshop_layer(v["img"], f"[{k}] {v['text']}", v["box"][0], v["box"][1]) for k, v in dialog_layers_dict.items()]
group_dialog_text = nested_layers.Group(
    name="[CAU_HOI_XAC_NHAN] (Căn Giữa Chuẩn - Font 24)",
    layers=dialog_sublayers,
    closed=False
)

base_dialog_layer = pil_to_pytoshop_layer(dialog_atlas, "Nen_Va_Nut_Xac_Nhan", 0, 0)
group_dialog_base = nested_layers.Group(
    name="[BASE_DIALOG] (Nút Yes/No & Checkbox)",
    layers=[base_dialog_layer],
    closed=True
)

psd_dialog_obj = nested_layers.nested_layers_to_psd(
    [group_dialog_text, group_dialog_base],
    color_mode=3,
    size=dialog_atlas.size,
    compression=0
)
psd_dialog_file = GUIDE_DIR / "dialog_confirm_guide.psd"
with open(psd_dialog_file, "wb") as f:
    psd_dialog_obj.write(f)
print(f"   + Đã tạo PSD Popup Dialog chuyên nghiệp: {psd_dialog_file.name} ({psd_dialog_file.stat().st_size:,} bytes)!")

# Convert to TLG5
out_dialog_tlg = TLG_MSGTOOL_DIR / "entry_01997_57cc.tlg"
cmd_dialog = [str(MSG_TOOL), "import", "-t", "kirikiri-tlg", str(ROOT_DIR / "extracted_data" / "data" / "entry_01997_57cc.bin"), str(dialog_png_path), str(out_dialog_tlg)]
subprocess.run(cmd_dialog, check=True)
patch_dialog_bin = PATCH_UI_DIR / "entry_01997.bin"
patch_dialog_bin.write_bytes(out_dialog_tlg.read_bytes())
print(f"   + Đã xuất TLG5 Popup Dialog: {out_dialog_tlg.name} ({out_dialog_tlg.stat().st_size:,} bytes)!")

# ======================================================================
# PHẦN 2: THANH TAB BASE CÀI ĐẶT (ENTRY_01948_579b)
# ======================================================================
print("\n[2/4] Xây dựng thanh Tab Base Cài Đặt (HIỂN THỊ, VĂN BẢN, HỘI THOẠI, ÂM THANH, GIỌNG NÓI)...")

raw_tab_img = Image.open(ROOT_DIR / "image" / "UI_Raw" / "entry_01948_579b.png").convert("RGBA")
tab_canvas = raw_tab_img.copy()

# 5 Tab: HIỂN THỊ | VĂN BẢN | HỘI THOẠI | ÂM THANH | GIỌNG NÓI
# Bảng tọa độ các tab trong entry_01948 theo PBD:
# page0 (Display): off=(1439, 260, 193, 30), over=(1439, 116, 211, 48)
# page1 (Text):    off=(465,  241, 119, 30), over=(710,  220, 137, 48)
# page2 (Dialog):  off=(276,  252, 180, 30), over=(1439, 164, 198, 48)
# page3 (Sound):   off=(710,  190, 161, 30), over=(1439, 212, 179, 48)
# page4 (Voice):   off=(710,  268, 139, 30), over=(465,  193, 157, 48)

TAB_SPECS = {
    "page0": {"name": "HIỂN THỊ", "off": (1439, 260, 193, 30), "over": (1439, 116, 211, 48)},
    "page1": {"name": "VĂN BẢN",  "off": (465,  241, 119, 30), "over": (710,  220, 137, 48)},
    "page2": {"name": "HỘI THOẠI","off": (276,  252, 180, 30), "over": (1439, 164, 198, 48)},
    "page3": {"name": "ÂM THANH", "off": (710,  190, 161, 30), "over": (1439, 212, 179, 48)},
    "page4": {"name": "GIỌNG NÓI","off": (710,  268, 139, 30), "over": (465,  193, 157, 48)},
}

tab_layers_dict = {}

for page_key, spec in TAB_SPECS.items():
    text = spec["name"]
    
    # 1. Normal (off): Chữ xám thanh lịch
    cx_off, cy_off, cw_off, ch_off = spec["off"]
    blank_off = Image.new("RGBA", (cw_off, ch_off), (0, 0, 0, 0))
    tab_canvas.paste(blank_off, (cx_off, cy_off))
    
    im_off = Image.new("RGBA", (cw_off, ch_off), (0, 0, 0, 0))
    d_off = ImageDraw.Draw(im_off)
    d_off.text((cw_off // 2, ch_off // 2 + 5), text, font=FONT_TAB_NORMAL, fill=(160, 175, 190, 255), anchor="ms")
    tab_canvas.paste(im_off, (cx_off, cy_off), im_off)
    tab_layers_dict[f"{page_key}_normal"] = {"img": im_off, "box": (cx_off, cy_off, cx_off + cw_off, cy_off + ch_off), "text": f"{text} (Thường)"}
    
    # 2. Hover / Active (over): Chữ trắng xanh phát sáng neon
    cx_ov, cy_ov, cw_ov, ch_ov = spec["over"]
    blank_ov = Image.new("RGBA", (cw_ov, ch_ov), (0, 0, 0, 0))
    tab_canvas.paste(blank_ov, (cx_ov, cy_ov))
    
    im_ov = Image.new("RGBA", (cw_ov, ch_ov), (0, 0, 0, 0))
    glow = Image.new("RGBA", (cw_ov, ch_ov), (0, 0, 0, 0))
    gd = ImageDraw.Draw(glow)
    center_ov_x = cw_ov // 2
    base_ov_y = ch_ov // 2 + 6
    
    glow_col = (0, 190, 255, 220)
    for ox in range(-2, 3):
        for oy in range(-2, 3):
            gd.text((center_ov_x + ox, base_ov_y + oy), text, font=FONT_TAB_HOVER, fill=glow_col, anchor="ms")
    glow = glow.filter(ImageFilter.GaussianBlur(1.5))
    im_ov.paste(glow, (0, 0), glow)
    
    d_ov = ImageDraw.Draw(im_ov)
    d_ov.text((center_ov_x, base_ov_y), text, font=FONT_TAB_HOVER, fill=(255, 255, 255, 255), anchor="ms")
    tab_canvas.paste(im_ov, (cx_ov, cy_ov), im_ov)
    tab_layers_dict[f"{page_key}_hover"] = {"img": im_ov, "box": (cx_ov, cy_ov, cx_ov + cw_ov, cy_ov + ch_ov), "text": f"{text} (Sáng)"}

tab_png_path = GUIDE_DIR / "tab_base_atlas.png"
tab_canvas.save(tab_png_path)
tab_canvas.save(ROOT_DIR / "image" / "UI_Da_Sua" / "entry_01948_579b.png")

# Build layered PSD for tab base
tab_sublayers = [pil_to_pytoshop_layer(v["img"], v["text"], v["box"][0], v["box"][1]) for k, v in tab_layers_dict.items()]
group_tabs = nested_layers.Group(
    name="[TAB_LABELS] (5 Tab Tiếng Việt Chuẩn)",
    layers=tab_sublayers,
    closed=False
)
raw_tab_layer = pil_to_pytoshop_layer(raw_tab_img, "Background_Base", 0, 0)
group_tab_base = nested_layers.Group(
    name="[BASE_BACKGROUND]",
    layers=[raw_tab_layer],
    closed=True
)
psd_tab_obj = nested_layers.nested_layers_to_psd(
    [group_tabs, group_tab_base],
    color_mode=3,
    size=tab_canvas.size,
    compression=0
)
psd_tab_file = GUIDE_DIR / "config_base_template_guide.psd"
with open(psd_tab_file, "wb") as f:
    psd_tab_obj.write(f)
print(f"   + Đã tạo PSD Tab Base Cài Đặt: {psd_tab_file.name} ({psd_tab_file.stat().st_size:,} bytes)!")

# Convert to TLG5
out_tab_tlg = TLG_MSGTOOL_DIR / "entry_01948_579b.tlg"
cmd_tab = [str(MSG_TOOL), "import", "-t", "kirikiri-tlg", str(ROOT_DIR / "extracted_data" / "data" / "entry_01948_579b.bin"), str(tab_png_path), str(out_tab_tlg)]
subprocess.run(cmd_tab, check=True)
patch_tab_bin = PATCH_UI_DIR / "entry_01948.bin"
patch_tab_bin.write_bytes(out_tab_tlg.read_bytes())
print(f"   + Đã xuất TLG5 Tab Base: {out_tab_tlg.name} ({out_tab_tlg.stat().st_size:,} bytes)!")

# ======================================================================
# PHẦN 3: CÁC TRANG CÀI ĐẶT (SOUND, TEXT, DISPLAY, DIALOG) KHÔNG CÓ NGOẶC
# ======================================================================
print("\n[3/4] Cập nhật các trang Cài Đặt (loại bỏ hoàn toàn dấu mở ngoặc)...")

def render_left_label(text, width=600, height=48, margin_left=5):
    img = Image.new("RGBA", (width, height), (0, 0, 0, 0))
    draw = ImageDraw.Draw(img)
    bb = draw.textbbox((0, 0), text, font=FONT_SETTING_LABEL)
    th = bb[3] - bb[1]
    tx = margin_left
    ty = (height - th) // 2 - bb[1]
    draw.text((tx, ty), text, font=FONT_SETTING_LABEL, fill=TEXT_COLOR_SETTING)
    return img

# 1. SOUND (config_p3)
print("   - Cập nhật trang Âm Thanh (Sound)...")
sound_orig_img = Image.open(CLEAN_DIR / "entry_01979.png").convert("RGBA")
canvas_sound = Image.new("RGBA", (1150, 480), (0, 0, 0, 0))
canvas_sound.paste(sound_orig_img, (0, 0))

# BỎ TOÀN BỘ NGOẶC (BGM, SE, Master)
sound_labels = {
    0: ("bgm", "Nhạc nền"),
    1: ("down", "Chế độ Downmix"),
    2: ("movie", "Âm lượng phim"),
    3: ("se", "Hiệu ứng âm thanh"),
    4: ("sysvo", "Giọng hệ thống"),
    5: ("voice", "Lời thoại"),
    6: ("voicecut", "Ngắt giọng khi bấm qua"),
    7: ("wave", "Âm lượng tổng")
}

sound_layout = {}
for s_idx, (key, text) in sound_labels.items():
    nx = 520
    ny = s_idx * 55
    nw = 600
    nh = 48
    sound_layout[s_idx] = {"key": key, "text": text, "x": nx, "y": ny, "w": nw, "h": nh}
    lbl_img = render_left_label(text, width=nw, height=nh)
    canvas_sound.paste(lbl_img, (nx, ny), lbl_img)

sound_atlas_png = Path("temp_sound_atlas.png")
canvas_sound.save(sound_atlas_png)

def update_sound_pbd(json_in, bin_template, bin_out):
    with open(json_in, "r", encoding="utf-8") as f:
        pbd = json.load(f)
    packlist = pbd.get("packlist", [])
    for s_idx, d in sound_layout.items():
        if s_idx < len(packlist):
            packlist[s_idx][0] = d["x"]
            packlist[s_idx][1] = d["y"]
            packlist[s_idx][2] = d["w"]
            packlist[s_idx][3] = d["h"]
            if len(packlist[s_idx]) > 7:
                packlist[s_idx][7] = None
    def walk(node):
        if isinstance(node, dict):
            uiname = node.get("uiname", "")
            for s_idx, d in sound_layout.items():
                if d["key"] in uiname.lower():
                    st = node.get("uistates", {})
                    for k in list(st.keys()):
                        st[k].update({
                            "cx": d["x"], "cy": d["y"], "cw": d["w"], "ch": d["h"],
                            "w": d["w"], "h": d["h"], "ox": 68, "oy": 0, "cr": None
                        })
            for k, v in node.items():
                if k != "uistates": walk(v)
        elif isinstance(node, list):
            for it in node: walk(it)
    walk(pbd.get("result", {}))
    synced_json = Path("temp_sound_synced.json")
    with open(synced_json, "w", encoding="utf-8") as f:
        json.dump(pbd, f, indent=2, ensure_ascii=False)
    subprocess.run([str(MSG_TOOL), "import", "-t", "kirikiri-tjs-ns0", str(bin_template), str(synced_json), str(bin_out)], check=True)

update_sound_pbd(CLEAN_DIR / "entry_01978.json", CLEAN_DIR / "entry_01978.bin", PATCH_PBD_DIR / "entry_01978.bin")
update_sound_pbd(CLEAN_DIR / "entry_01980.json", CLEAN_DIR / "entry_01980.bin", PATCH_PBD_DIR / "entry_01980.bin")

raw_sound_tlg = ROOT_DIR / "extracted_data" / "data" / "entry_01979_57ba.bin"
tlg_p3_en = TLG_MSGTOOL_DIR / "entry_01979_57ba.tlg"
subprocess.run([str(MSG_TOOL), "import", "-t", "kirikiri-tlg", str(raw_sound_tlg), str(sound_atlas_png), str(tlg_p3_en)], check=True)
shutil.copy2(tlg_p3_en, PATCH_UI_DIR / "entry_01979.bin")
print("     + Trang Sound hoàn tất không còn ngoặc!")

# 2. TEXT (config_p1)
print("   - Cập nhật trang Văn Bản (Text)...")
text_orig_img = Image.open(CLEAN_DIR / "entry_01961.png").convert("RGBA")
canvas_text = Image.new("RGBA", (1500, 800), (0, 0, 0, 0))
canvas_text.paste(text_orig_img, (0, 0))

text_labels = {
    15: ("autospeed",  "Tốc độ tự đọc"),
    16: ("autovwait",  "Chờ hết giọng khi tự đọc"),
    17: ("ctrlskip",   "Tua nhanh bằng phím Ctrl"),
    18: ("readskip",   "Bỏ qua thoại đã đọc"),
    19: ("rtextcol",   "Đổi màu chữ đã đọc"),
    20: ("skipall",    "Bỏ qua toàn bộ thoại"),
    21: ("textspeed",  "Tốc độ hiển thị chữ"),
    22: ("winopac",    "Độ mờ khung thoại")
}

text_layout = {}
for idx, (s_idx, (key, text)) in enumerate(text_labels.items()):
    nx = 860
    ny = idx * 55
    nw = 600
    nh = 48
    text_layout[s_idx] = {"key": key, "text": text, "x": nx, "y": ny, "w": nw, "h": nh}
    lbl_img = render_left_label(text, width=nw, height=nh)
    canvas_text.paste(lbl_img, (nx, ny), lbl_img)

text_atlas_png = Path("temp_text_atlas.png")
canvas_text.save(text_atlas_png)

def update_text_pbd(json_in, bin_template, bin_out):
    with open(json_in, "r", encoding="utf-8") as f:
        pbd = json.load(f)
    packlist = pbd.get("packlist", [])
    for s_idx, d in text_layout.items():
        if s_idx < len(packlist):
            packlist[s_idx][0] = d["x"]
            packlist[s_idx][1] = d["y"]
            packlist[s_idx][2] = d["w"]
            packlist[s_idx][3] = d["h"]
            if len(packlist[s_idx]) > 7:
                packlist[s_idx][7] = None
    def walk(node):
        if isinstance(node, dict):
            uiname = node.get("uiname", "")
            for s_idx, d in text_layout.items():
                if d["key"] in uiname.lower():
                    st = node.get("uistates", {})
                    for k in list(st.keys()):
                        st[k].update({
                            "cx": d["x"], "cy": d["y"], "cw": d["w"], "ch": d["h"],
                            "w": d["w"], "h": d["h"], "ox": 68, "oy": 0, "cr": None
                        })
            for k, v in node.items():
                if k != "uistates": walk(v)
        elif isinstance(node, list):
            for it in node: walk(it)
    walk(pbd.get("result", {}))
    synced_json = Path("temp_text_synced.json")
    with open(synced_json, "w", encoding="utf-8") as f:
        json.dump(pbd, f, indent=2, ensure_ascii=False)
    subprocess.run([str(MSG_TOOL), "import", "-t", "kirikiri-tjs-ns0", str(bin_template), str(synced_json), str(bin_out)], check=True)

update_text_pbd(CLEAN_DIR / "entry_01960.json", CLEAN_DIR / "entry_01960.bin", PATCH_PBD_DIR / "entry_01960.bin")
update_text_pbd(CLEAN_DIR / "entry_01962.json", CLEAN_DIR / "entry_01962.bin", PATCH_PBD_DIR / "entry_01962.bin")

raw_text_tlg = ROOT_DIR / "extracted_data" / "data" / "entry_01961_57a8.bin"
tlg_p1_en = TLG_MSGTOOL_DIR / "entry_01961_57a8.tlg"
subprocess.run([str(MSG_TOOL), "import", "-t", "kirikiri-tlg", str(raw_text_tlg), str(text_atlas_png), str(tlg_p1_en)], check=True)
shutil.copy2(tlg_p1_en, PATCH_UI_DIR / "entry_01961.bin")
print("     + Trang Text hoàn tất không còn ngoặc!")

print("\n" + "=" * 70)
print("   HOÀN TẤT BẢN DỊCH SETTINGS, DIALOG VÀ TAB BASE CHUẨN XÁC 100%!   ")
print("=" * 70)
