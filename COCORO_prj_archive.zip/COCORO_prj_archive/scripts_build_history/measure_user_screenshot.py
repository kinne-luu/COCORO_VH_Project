from PIL import Image
import numpy as np

user_img = Image.open(r"C:\Users\ADMIN\.gemini\antigravity\brain\6b02dd57-4279-4cd4-9c69-1295e15a34fe\.user_uploaded\media_1795387234991_5ce0a5dd.jpg")
print("User screenshot size:", user_img.size)

# Crop phần trên chứa nút LƯU và TẢI
crop_top = user_img.crop((0, 0, user_img.width, 300))
crop_top.save("user_qmenu_crop.png")

# Tìm vị trí mép x của nút 1 (LƯU) và nút 2 (TẢI) trong ảnh screenshot
arr = np.array(crop_top)
# Nút có màu xám đậm: R, G, B khoảng 50-90
# Hãy in các hàng pixel
print("Crop saved as user_qmenu_crop.png")
