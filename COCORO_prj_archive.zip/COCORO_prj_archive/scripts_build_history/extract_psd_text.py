from psd_tools import PSDImage
from pathlib import Path

psd_dir = Path(r"D:\Workspace\Creative\2D\Projects\Photoshop\COCORO Prj")

for psd_name in ['entry_01948_579b.psd', 'entry_01952_579f.psd', 'entry_01961_57a8.psd', 'entry_01970_57b1.psd', 'entry_01979_57ba.psd', 'entry_01988_57c3.psd', 'entry_01997_57cc.psd']:
    p = psd_dir / psd_name
    if not p.exists(): continue
    psd = PSDImage.open(p)
    print(f"\n==================== {psd_name} ====================")
    for layer in psd.descendants():
        if layer.kind == 'type' or (hasattr(layer, 'text') and layer.text):
            print(f"  [Text Layer] '{layer.name}': '{layer.text.strip()}' (box={layer.bbox})")
        else:
            print(f"  [Layer] '{layer.name}' (kind={layer.kind}, box={layer.bbox})")
