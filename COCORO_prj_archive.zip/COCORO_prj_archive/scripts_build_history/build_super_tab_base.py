# -*- coding: utf-8 -*-
"""
Nâng cấp thanh Tab Base Cài Đặt:
1. Kích thước chữ to gấp đôi (Font STIX Two Text Bold size 28 cho Normal, size 30 cho Hover phát sáng)
2. Mở rộng kích thước ô tab lên 220x48, căn giữa hoàn hảo giữa các vạch phân cách | trên thanh menu
3. Cập nhật cả 2 file PBD entry_01941 (EN) và entry_01943 (JP)
4. Xuất layered PSD chuẩn vào wireframe_guide/config_base_template_guide.psd
5. Biên dịch TLG5 entry_01948_579b.tlg
"""

import sys
import json
import shutil
import subprocess
from pathlib import Path
import numpy as np
from PIL import Image, ImageDraw, ImageFont, ImageFilter
import pytoshop
from pytoshop.user import nested_layers

ROOT_DIR = Path(r"D:\Software\Antigravity\Project\Cocoro")
GUIDE_DIR = Path(r"D:\Workspace\Creative\2D\Projects\Photoshop\COCORO Prj\wireframe_guide")
MSG_TOOL = ROOT_DIR / "tools" / "msg-tool" / "msg_tool.exe"
PATCH_UI_DIR = ROOT_DIR / "COCORO_Patch_VietHoa" / "patch_data" / "ui"
PATCH_PBD_DIR = ROOT_DIR / "COCORO_Patch_VietHoa" / "patch_data" / "pbd"
TLG_MSGTOOL_DIR = ROOT_DIR / "tlg_msgtool"

FONT_PATH = Path(r"C:\Users\ADMIN\AppData\Local\Microsoft\Windows\Fonts\STIXTwoText-Bold.ttf")
if not FONT_PATH.exists():
    FONT_PATH = Path(r"C:\Windows\Fonts\timesbd.ttf")

FONT_TAB_NORMAL = ImageFont.truetype(str(FONT_PATH), 28)
FONT_TAB_HOVER = ImageFont.truetype(str(FONT_PATH), 30)
SMALL_FONT = ImageFont.truetype(str(FONT_PATH), 11)

print("=" * 70)
print("   BẮT ĐẦU NÂNG CẤP THANH TAB BASE CÀI ĐẶT CỠ CHỮ TO GẤP ĐÔI   ")
print("=" * 70)

RAW_TAB_PATH = ROOT_DIR / "image" / "UI_Raw" / "entry_01948_579b.png"
raw_tab_img = Image.open(RAW_TAB_PATH).convert("RGBA")

# Mở rộng canvas từ (1652, 298) lên (1652, 520) để chứa các ô tab 220x48 rộng rãi
CANVAS_W = 1652
CANVAS_H = 520
atlas_canvas = Image.new("RGBA", (CANVAS_W, CANVAS_H), (0, 0, 0, 0))
atlas_canvas.paste(raw_tab_img, (0, 0))

atlas_guide = Image.new("RGBA", (CANVAS_W, CANVAS_H), (0, 0, 0, 0))
guide_draw = ImageDraw.Draw(atlas_guide)

TAB_WIDTH = 220
TAB_HEIGHT = 48

TABS_INFO = [
    ("page0", "HIỂN THỊ", 565),
    ("page1", "VĂN BẢN",  835),
    ("page2", "HỘI THOẠI",1080),
    ("page3", "ÂM THANH", 1340),
    ("page4", "GIỌNG NÓI",1600),
]

# Tọa độ vùng mới trong atlas
# Hàng off: cy = 320
# Hàng over: cy = 390
ROW_OFF_Y = 320
ROW_OVER_Y = 390
STEP_X = 230

normal_tab_layers = {}
hover_tab_layers = {}
new_tab_coords = {}

for idx, (page_key, text, target_screen_x) in enumerate(TABS_INFO):
    cx = 10 + idx * STEP_X
    
    # 1. Normal Image (off)
    im_off = Image.new("RGBA", (TAB_WIDTH, TAB_HEIGHT), (0, 0, 0, 0))
    d_off = ImageDraw.Draw(im_off)
    d_off.text((TAB_WIDTH // 2, TAB_HEIGHT // 2 + 6), text, font=FONT_TAB_NORMAL, fill=(160, 180, 195, 255), anchor="ms")
    atlas_canvas.paste(im_off, (cx, ROW_OFF_Y), im_off)
    normal_tab_layers[f"{page_key}_normal"] = {"img": im_off, "box": (cx, ROW_OFF_Y, cx + TAB_WIDTH, ROW_OFF_Y + TAB_HEIGHT), "text": f"{text} (Thường)"}
    
    guide_draw.rectangle([cx, ROW_OFF_Y, cx + TAB_WIDTH - 1, ROW_OFF_Y + TAB_HEIGHT - 1], outline=(100, 255, 100, 255), width=1)
    guide_draw.text((cx, ROW_OFF_Y - 14), f"[{page_key}] {text} Normal ({TAB_WIDTH}x{TAB_HEIGHT})", font=SMALL_FONT, fill=(100, 255, 100, 255))
    
    # 2. Hover Image (over - phát sáng xanh neon)
    im_ov = Image.new("RGBA", (TAB_WIDTH, TAB_HEIGHT), (0, 0, 0, 0))
    glow = Image.new("RGBA", (TAB_WIDTH, TAB_HEIGHT), (0, 0, 0, 0))
    gd = ImageDraw.Draw(glow)
    center_ov_x = TAB_WIDTH // 2
    base_ov_y = TAB_HEIGHT // 2 + 7
    
    glow_col = (0, 200, 255, 240)
    for ox in range(-2, 3):
        for oy in range(-2, 3):
            gd.text((center_ov_x + ox, base_ov_y + oy), text, font=FONT_TAB_HOVER, fill=glow_col, anchor="ms")
    glow = glow.filter(ImageFilter.GaussianBlur(1.8))
    im_ov.paste(glow, (0, 0), glow)
    
    d_ov = ImageDraw.Draw(im_ov)
    d_ov.text((center_ov_x, base_ov_y), text, font=FONT_TAB_HOVER, fill=(255, 255, 255, 255), anchor="ms")
    atlas_canvas.paste(im_ov, (cx, ROW_OVER_Y), im_ov)
    hover_tab_layers[f"{page_key}_hover"] = {"img": im_ov, "box": (cx, ROW_OVER_Y, cx + TAB_WIDTH, ROW_OVER_Y + TAB_HEIGHT), "text": f"{text} (Sáng)"}
    
    guide_draw.rectangle([cx, ROW_OVER_Y, cx + TAB_WIDTH - 1, ROW_OVER_Y + TAB_HEIGHT - 1], outline=(0, 200, 255, 255), width=1)
    guide_draw.text((cx, ROW_OVER_Y - 14), f"[{page_key}] {text} Hover ({TAB_WIDTH}x{TAB_HEIGHT})", font=SMALL_FONT, fill=(0, 200, 255, 255))
    
    new_tab_coords[page_key] = {
        "text": text,
        "x": target_screen_x,
        "y": 24,
        "off":  (cx, ROW_OFF_Y,  TAB_WIDTH, TAB_HEIGHT),
        "over": (cx, ROW_OVER_Y, TAB_WIDTH, TAB_HEIGHT)
    }

# Đồng thời vẽ chữ kích cỡ tối đa vào cả các vị trí cũ để tương thích 100%
OLD_SPECS = {
    "page0": {"name": "HIỂN THỊ", "off": (1439, 260, 193, 30), "over": (1439, 116, 211, 48)},
    "page1": {"name": "VĂN BẢN",  "off": (465,  241, 119, 30), "over": (710,  220, 137, 48)},
    "page2": {"name": "HỘI THOẠI","off": (276,  252, 180, 30), "over": (1439, 164, 198, 48)},
    "page3": {"name": "ÂM THANH", "off": (710,  190, 161, 30), "over": (1439, 212, 179, 48)},
    "page4": {"name": "GIỌNG NÓI","off": (710,  268, 139, 30), "over": (465,  193, 157, 48)},
}
for pk, spec in OLD_SPECS.items():
    t = spec["name"]
    # off
    cx_o, cy_o, cw_o, ch_o = spec["off"]
    blank_o = Image.new("RGBA", (cw_o, ch_o), (0, 0, 0, 0))
    atlas_canvas.paste(blank_o, (cx_o, cy_o))
    im_o = Image.new("RGBA", (cw_o, ch_o), (0, 0, 0, 0))
    ImageDraw.Draw(im_o).text((cw_o // 2, ch_o // 2 + 5), t, font=ImageFont.truetype(str(FONT_PATH), 24), fill=(160, 180, 195, 255), anchor="ms")
    atlas_canvas.paste(im_o, (cx_o, cy_o), im_o)
    # over
    cx_v, cy_v, cw_v, ch_v = spec["over"]
    blank_v = Image.new("RGBA", (cw_v, ch_v), (0, 0, 0, 0))
    atlas_canvas.paste(blank_v, (cx_v, cy_v))
    im_v = Image.new("RGBA", (cw_v, ch_v), (0, 0, 0, 0))
    glow_v = Image.new("RGBA", (cw_v, ch_v), (0, 0, 0, 0))
    gdv = ImageDraw.Draw(glow_v)
    for ox in range(-2, 3):
        for oy in range(-2, 3):
            gdv.text((cw_v // 2 + ox, ch_v // 2 + 6 + oy), t, font=ImageFont.truetype(str(FONT_PATH), 28), fill=(0, 200, 255, 240), anchor="ms")
    glow_v = glow_v.filter(ImageFilter.GaussianBlur(1.5))
    im_v.paste(glow_v, (0, 0), glow_v)
    ImageDraw.Draw(im_v).text((cw_v // 2, ch_v // 2 + 6), t, font=ImageFont.truetype(str(FONT_PATH), 28), fill=(255, 255, 255, 255), anchor="ms")
    atlas_canvas.paste(im_v, (cx_v, cy_v), im_v)

tab_png_path = GUIDE_DIR / "config_base_atlas.png"
atlas_canvas.save(tab_png_path)
atlas_canvas.save(ROOT_DIR / "image" / "UI_Da_Sua" / "entry_01948_579b.png")

# Build layered PSD
def pil_to_pytoshop_layer(pil_img, name, left, top):
    arr = np.array(pil_img)
    h, w = arr.shape[:2]
    return nested_layers.Image(
        name=name,
        top=top,
        left=left,
        bottom=top + h,
        right=left + w,
        channels={
            0: arr[:, :, 0],
            1: arr[:, :, 1],
            2: arr[:, :, 2],
            -1: arr[:, :, 3]
        }
    )

wire_layer = pil_to_pytoshop_layer(atlas_guide, "Huong_Dan_Wireframe (TAT MAT KHI XUAT PNG)", 0, 0)
group_guide = nested_layers.Group(
    name="[HUONG_DAN_WIREFRAME]",
    layers=[wire_layer],
    closed=False
)

hover_sublayers = [pil_to_pytoshop_layer(v["img"], v["text"], v["box"][0], v["box"][1]) for k, v in hover_tab_layers.items()]
group_hover = nested_layers.Group(
    name="[TAB_HOVER_ACTIVE] (Font 30 - Phat Sang Neon)",
    layers=hover_sublayers,
    closed=True
)

norm_sublayers = [pil_to_pytoshop_layer(v["img"], v["text"], v["box"][0], v["box"][1]) for k, v in normal_tab_layers.items()]
group_norm = nested_layers.Group(
    name="[TAB_NORMAL] (Font 28 - Chu Xam Thanh Lich)",
    layers=norm_sublayers,
    closed=True
)

raw_bg_layer = pil_to_pytoshop_layer(raw_tab_img, "Background_Base", 0, 0)
group_base = nested_layers.Group(
    name="[BACKGROUND_BASE]",
    layers=[raw_bg_layer],
    closed=True
)

psd_tab_obj = nested_layers.nested_layers_to_psd(
    [group_guide, group_hover, group_norm, group_base],
    color_mode=3,
    size=(CANVAS_W, CANVAS_H),
    compression=0
)
psd_file_path = GUIDE_DIR / "config_base_template_guide.psd"
with open(psd_file_path, "wb") as f:
    psd_tab_obj.write(f)
print(f"   + Đã tạo file PSD Tab Base chuẩn: {psd_file_path.name} ({psd_file_path.stat().st_size:,} bytes)!")

# Update PBD entry_01941 (EN) and entry_01943 (JP)
def update_tab_pbd(json_stem, entry_idx):
    pbd_json_path = ROOT_DIR / "temp_pbd_dumps" / f"{json_stem}.json"
    pbd_bin_orig = ROOT_DIR / "extracted_data" / "data" / f"{json_stem}.bin"
    pbd_bin_out = PATCH_PBD_DIR / f"entry_{entry_idx:05d}.bin"
    
    with open(pbd_json_path, "r", encoding="utf-8") as f:
        data = json.load(f)
        
    res = data.get("result", {})
    for pk, coords in new_tab_coords.items():
        if pk in res:
            node = res[pk]
            node["x"] = coords["x"]
            node["y"] = coords["y"]
            node["width"] = TAB_WIDTH
            node["height"] = TAB_HEIGHT
            
            st = node.get("uistates", {})
            if "off" in st:
                cx, cy, cw, ch = coords["off"]
                st["off"].update({
                    "cx": cx, "cy": cy, "cw": cw, "ch": ch,
                    "w": cw, "h": ch, "ox": 0, "oy": 0, "cr": None
                })
            if "over" in st:
                cx, cy, cw, ch = coords["over"]
                st["over"].update({
                    "cx": cx, "cy": cy, "cw": cw, "ch": ch,
                    "w": cw, "h": ch, "ox": 0, "oy": 0, "cr": None
                })
                
    synced_json = Path(f"temp_{json_stem}_synced.json")
    with open(synced_json, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, ensure_ascii=False)
        
    cmd = [str(MSG_TOOL), "import", "-t", "kirikiri-tjs-ns0", str(pbd_bin_orig), str(synced_json), str(pbd_bin_out)]
    subprocess.run(cmd, check=True)
    print(f"   + Đã biên dịch PBD Tab Base {pbd_bin_out.name} ({pbd_bin_out.stat().st_size:,} bytes)!")

update_tab_pbd("entry_01941_5794", 1941)
update_tab_pbd("entry_01943_5796", 1943)

# Xuất TLG5 entry_01948_579b.tlg
out_tab_tlg = TLG_MSGTOOL_DIR / "entry_01948_579b.tlg"
cmd_tlg = [str(MSG_TOOL), "import", "-t", "kirikiri-tlg", str(ROOT_DIR / "extracted_data" / "data" / "entry_01948_579b.bin"), str(tab_png_path), str(out_tab_tlg)]
subprocess.run(cmd_tlg, check=True)
patch_tab_bin = PATCH_UI_DIR / "entry_01948.bin"
patch_tab_bin.write_bytes(out_tab_tlg.read_bytes())
print(f"   + Đã xuất TLG5 Tab Base: {out_tab_tlg.name} ({out_tab_tlg.stat().st_size:,} bytes)!")
