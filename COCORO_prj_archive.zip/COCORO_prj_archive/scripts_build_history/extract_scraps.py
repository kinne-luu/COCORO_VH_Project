from PIL import Image
import numpy as np

# Load user crop
user_img = Image.open(r"C:\Users\ADMIN\.gemini\antigravity\brain\6b02dd57-4279-4cd4-9c69-1295e15a34fe\.user_uploaded\media_1795402114054_6050186b.jpg").convert("RGB")
arr_user = np.array(user_img)

# Crop 4 mẩu rác
# Row 2 (BGM): y 195..240, x 100..128
r2_crop = arr_user[195:240, 100:128]
Image.fromarray(r2_crop).save("user_scrap_r2_bgm.png")

# Row 3 (Downmix): y 345..395, x 100..128
r3_crop = arr_user[345:395, 100:128]
Image.fromarray(r3_crop).save("user_scrap_r3_down.png")

# Row 4 (SE): y 500..545, x 100..128
r4_crop = arr_user[500:545, 100:128]
Image.fromarray(r4_crop).save("user_scrap_r4_se.png")

# Row 5 (Movie): y 650..700, x 100..128
r5_crop = arr_user[650:700, 100:128]
Image.fromarray(r5_crop).save("user_scrap_r5_movie.png")

print("Saved all 4 scrap crops from user screenshot!")
