# -*- coding: utf-8 -*-
"""
COCORO - Sync PBD Layout Coordinates from Repack Manifest
- Đọc repack_manifest.json (xuất từ repack_psd.jsx)
- Khớp tọa độ spatial matching với các slice trong .pbd (packlist & result)
- Cập nhật cx, cy, cw, ch, w, h và baseline offset
- Biên dịch lại file nhị phân .pbd bằng msg-tool
- Tự động convert atlas PNG mới thành TLG và đóng gói vào data.xp3
"""
import sys
import json
import subprocess
from pathlib import Path

ROOT_DIR = Path(r"D:\Software\Antigravity\Project\Cocoro")
MSG_TOOL = ROOT_DIR / "tools" / "msg-tool" / "msg_tool.exe"
PBD_DUMP_DIR = ROOT_DIR / "temp_pbd_dumps"
PATCH_DATA_PBD_DIR = ROOT_DIR / "COCORO_Patch_VietHoa" / "patch_data" / "pbd"
TLG_MSGTOOL_DIR = ROOT_DIR / "tlg_msgtool"

# Mapping giữa tên manifest và entry PBD / TLG
MAPPING = {
    "entry_02165_5874": {
        "pbd_entry": 2161,
        "pbd_file": "entry_02161_5870.bin",
        "tlg_entry": 2165,
        "tlg_file": "entry_02165_5874.tlg",
        "orig_bin": "entry_02165_5874.bin"
    }
}

def sync_manifest_to_pbd(manifest_path: Path):
    assert manifest_path.exists(), f"Không tìm thấy manifest: {manifest_path}"
    with open(manifest_path, "r", encoding="utf-8") as f:
        manifest = json.load(f)

    doc_name = manifest.get("doc_name")
    if doc_name not in MAPPING:
        print(f"[-] Chưa cấu hình mapping cho {doc_name}!")
        return False

    cfg = MAPPING[doc_name]
    pbd_orig = ROOT_DIR / "extracted_data" / "data" / cfg["pbd_file"]
    pbd_json = PBD_DUMP_DIR / f"{pbd_orig.stem}.json"

    # Export PBD sang JSON
    print(f"[*] Xuất JSON từ {pbd_orig.name}...")
    res = subprocess.run([str(MSG_TOOL), "export", "-t", "kirikiri-tjs-ns0", str(pbd_orig), str(pbd_json)], capture_output=True, text=True)
    assert res.returncode == 0, f"Lỗi xuất JSON từ PBD: {res.stderr}"

    with open(pbd_json, "r", encoding="utf-8") as f:
        pbd_data = json.load(f)

    packlist = pbd_data.get("packlist", [])
    layers = manifest.get("layers", [])

    print(f"[*] Tiến hành spatial matching {len(layers)} layer với {len(packlist)} slice trong PBD...")
    matched_count = 0
    slice_replacements = {} # slice_idx -> (new_cx, new_cy, new_cw, new_ch, pad_top, pad_left)

    for lyr in layers:
        x1, y1, x2, y2 = lyr["orig_bounds"]
        nx1, ny1, nx2, ny2 = lyr["new_bounds"]
        pad_top = lyr.get("pad_top", 0)
        pad_left = lyr.get("pad_left", 0)
        new_cw = nx2 - nx1
        new_ch = ny2 - ny1

        best_slice = None
        best_overlap = 0

        for s_idx, s in enumerate(packlist):
            cx, cy, cw, ch = s[0], s[1], s[2], s[3]
            ox1 = max(x1, cx)
            oy1 = max(y1, cy)
            ox2 = min(x2, cx + cw)
            oy2 = min(y2, cy + ch)
            if ox2 > ox1 and oy2 > oy1:
                overlap = (ox2 - ox1) * (oy2 - oy1)
                area = (x2 - x1) * (y2 - y1)
                score = overlap / area if area > 0 else 0
                if score > best_overlap:
                    best_overlap = score
                    best_slice = s_idx

        if best_slice is not None and best_overlap > 0.4:
            slice_replacements[best_slice] = {
                "old": (packlist[best_slice][0], packlist[best_slice][1], packlist[best_slice][2], packlist[best_slice][3]),
                "new": (nx1, ny1, new_cw, new_ch),
                "pad_top": pad_top,
                "pad_left": pad_left,
                "name": lyr["name"]
            }
            matched_count += 1
            print(f"   + Khớp: {lyr['name']} -> Slice {best_slice} (Score: {best_overlap:.1%})")

    # 1. Cập nhật packlist
    for s_idx, rep in slice_replacements.items():
        s = packlist[s_idx]
        nx, ny, ncw, nch = rep["new"]
        s[0] = nx
        s[1] = ny
        s[2] = ncw
        s[3] = nch
        s[4] = 0 # Xóa rotation cr=1

    # 2. Cập nhật result hierarchy
    result = pbd_data.get("result", {})
    for elem_name, elem in result.items():
        if not isinstance(elem, dict): continue
        states = elem.get("uistates", {})
        if not isinstance(states, dict): continue

        for st_name, st in states.items():
            if not isinstance(st, dict): continue
            scx = st.get("cx")
            scy = st.get("cy")
            if scx is None or scy is None: continue

            # Tìm xem có trùng với slice nào vừa được đổi không
            for s_idx, rep in slice_replacements.items():
                ocx, ocy, ocw, och = rep["old"]
                if scx == ocx and scy == ocy:
                    ncx, ncy, ncw, nch = rep["new"]
                    st["cx"] = ncx
                    st["cy"] = ncy
                    st["cw"] = ncw
                    st["ch"] = nch
                    st["w"] = ncw
                    st["h"] = nch
                    if "cr" in st: del st["cr"]

                    # Cập nhật khung cha
                    if "width" in elem and elem["width"] is not None:
                        if ncw > elem["width"]:
                            elem["width"] = ncw
                    if "height" in elem and elem["height"] is not None:
                        if nch > elem["height"]:
                            elem["height"] = nch
                    if "y" in elem and elem["y"] is not None and rep["pad_top"] > 0:
                        elem["y"] -= rep["pad_top"]
                    print(f"   * Cập nhật trạng thái '{st_name}' của nút '{elem_name}': cx={ncx}, cy={ncy}, cw={ncw}, ch={nch}")

    # Ghi lại file JSON đã sửa
    synced_json = PBD_DUMP_DIR / f"{pbd_orig.stem}_synced.json"
    with open(synced_json, "w", encoding="utf-8") as f:
        json.dump(pbd_data, f, indent=2, ensure_ascii=False)

    # Biên dịch lại sang PBD nhị phân
    synced_pbd = PATCH_DATA_PBD_DIR / f"entry_{cfg['pbd_entry']:05d}.bin"
    PATCH_DATA_PBD_DIR.mkdir(parents=True, exist_ok=True)
    print(f"[*] Biên dịch lại {synced_pbd.name} qua msg-tool...")
    res = subprocess.run([str(MSG_TOOL), "import", "-t", "kirikiri-tjs-ns0", str(pbd_orig), str(synced_json), str(synced_pbd)], capture_output=True, text=True)
    assert res.returncode == 0, f"Lỗi biên dịch PBD: {res.stderr}"
    print(f"[+] Biên dịch PBD thành công ({synced_pbd.stat().st_size:,} bytes)!")

    # 3. Convert atlas PNG mới sang TLG nếu có
    atlas_png = manifest_path.parent / f"{doc_name}_atlas.png"
    if atlas_png.exists():
        orig_bin = ROOT_DIR / "extracted_data" / "data" / cfg["orig_bin"]
        out_tlg = TLG_MSGTOOL_DIR / cfg["tlg_file"]
        print(f"[*] Chuyển đổi atlas mới {atlas_png.name} sang TLG...")
        res = subprocess.run([str(MSG_TOOL), "import", "-t", "kirikiri-tlg", str(orig_bin), str(atlas_png), str(out_tlg)], capture_output=True, text=True)
        assert res.returncode == 0, f"Lỗi chuyển TLG: {res.stderr}"
        print(f"[+] Chuyển đổi TLG thành công ({out_tlg.stat().st_size:,} bytes)!")

    print(f"=======================================================")
    print(f"   ĐỒNG BỘ HOÀN TẤT CHO {doc_name}!")
    print(f"=======================================================")
    return True

if __name__ == "__main__":
    test_manifest = Path(r"D:\Workspace\Creative\2D\Projects\Photoshop\COCORO Prj\edited\entry_02165_5874_manifest.json")
    if len(sys.argv) > 1:
        test_manifest = Path(sys.argv[1])
    sync_manifest_to_pbd(test_manifest)
