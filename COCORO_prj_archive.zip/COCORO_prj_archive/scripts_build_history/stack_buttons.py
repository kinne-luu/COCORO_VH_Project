import json
from PIL import Image

pbd = json.load(open("temp_pbd_dumps/entry_02053_5804.json", encoding="utf-8"))
im = Image.open("image/UI_Da_Sua/entry_02055_5806.png").convert("RGBA")

res = pbd["result"]
nodes_order = ['save', 'load', 'qsave', 'qload', 'xprev', 'next', 'auto', 'skip', 'log', 'option', 'manual', 'title']

canvas = Image.new("RGBA", (343, 59 * len(nodes_order)), (0, 0, 0, 0))

for idx, name in enumerate(nodes_order):
    norm = res[name]['uistates']['normal']
    cx, cy, cw, ch = norm['cx'], norm['cy'], norm['cw'], norm['ch']
    cr = norm.get('cr', 0)
    crop = im.crop((cx, cy, cx+cw, cy+ch))
    if cr == 1:
        crop = crop.transpose(Image.Transpose.ROTATE_270)
    canvas.paste(crop, (0, idx * 59), crop)

canvas.save("stacked_user_buttons.png")
print("Saved stacked_user_buttons.png!")
