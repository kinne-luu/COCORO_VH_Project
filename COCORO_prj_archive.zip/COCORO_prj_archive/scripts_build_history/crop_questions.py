import json
from PIL import Image

im = Image.open("image/UI_Da_Sua/entry_01997_57cc.png")
pbd = json.load(open("temp_pbd_dumps/entry_01996_57cb.json", encoding="utf-8"))
texts = pbd["result"]["texts"]["uistates"]

# Crop askload, askqload, askdelete, askoverwrite, asktitle
for k in ['askload', 'askqload', 'askdelete', 'askoverwrite', 'asktitle']:
    v = texts[k]
    cx, cy, cw, ch = v['cx'], v['cy'], v['cw'], v['ch']
    crop = im.crop((cx, cy, cx+cw, cy+ch))
    crop.save(f"crop_{k}.png")
    print(f"{k}: box=({cx}, {cy}, {cw}, {ch}), bbox={crop.getbbox()}")
