# -*- coding: utf-8 -*-
"""
Đồng bộ toàn diện Subpages Cài đặt (Display, Text, Dialog, Sound) cho CẢ Title Menu và In-Game:
1. Đảm bảo file gốc sạch 100% cho từng ngôn ngữ:
   - Display EN (entry_01950) mở rộng từ orig_fresh/entry_01950.png (595x620)
   - Display JP (entry_01952) mở rộng từ orig_fresh/entry_01952.png (637x626)
   - Text (entry_01961) mở rộng từ orig_fresh/entry_01961.png (846x783)
   - Dialog EN (entry_01968) mở rộng từ orig_fresh/entry_01968.png (850x896)
   - Dialog JP (entry_01970) mở rộng từ orig_fresh/entry_01970.png (889x872)
   - Sound EN (entry_01977) mở rộng từ orig_fresh/entry_01977.png (467x441)
   - Sound JP (entry_01979) mở rộng từ orig_fresh/entry_01979.png (506x440)
2. Bảo toàn 100% vùng gốc (buttons, sliders, toggles), không bao giờ đè nhầm file ngôn ngữ khác
3. Nhãn tiếng Việt vẽ ở vùng mở rộng, font STIX Two Text Bold size 32
4. Patch PBD cho CẢ Title Menu (2072, 2073, 2075; 2078, 2080, 2082; 2086, 2088, 2090; 2095, 2096, 2098)
   VÀ In-game (1949, 1951, 1953; 1958, 1960, 1962; 1967, 1969, 1971; 1976, 1978, 1980)
"""

import sys
import json
import shutil
import subprocess
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont

ROOT_DIR = Path(r"D:\Software\Antigravity\Project\Cocoro")
MSG_TOOL = ROOT_DIR / "tools" / "msg-tool" / "msg_tool.exe"
FRESH_DIR = ROOT_DIR / "orig_fresh"
EXT_DATA_DIR = ROOT_DIR / "extracted_data" / "data"
DUMP_DIR = ROOT_DIR / "temp_pbd_dumps"
PATCH_UI_DIR = ROOT_DIR / "COCORO_Patch_VietHoa" / "patch_data" / "ui"
PATCH_PBD_DIR = ROOT_DIR / "COCORO_Patch_VietHoa" / "patch_data" / "pbd"
TLG_MSGTOOL_DIR = ROOT_DIR / "tlg_msgtool"

FONT_PATH = Path(r"C:\Users\ADMIN\AppData\Local\Microsoft\Windows\Fonts\STIXTwoText-Bold.ttf")
if not FONT_PATH.exists():
    FONT_PATH = Path(r"C:\Windows\Fonts\timesbd.ttf")

LABEL_FONT = ImageFont.truetype(str(FONT_PATH), 32)
TEXT_COLOR = (50, 55, 60, 255)

def render_left_label(text, width=600, height=48, margin_left=5):
    img = Image.new("RGBA", (width, height), (0, 0, 0, 0))
    draw = ImageDraw.Draw(img)
    bb = draw.textbbox((0, 0), text, font=LABEL_FONT)
    th = bb[3] - bb[1]
    tx = margin_left
    ty = (height - th) // 2 - bb[1]
    draw.text((tx, ty), text, font=LABEL_FONT, fill=TEXT_COLOR)
    return img

print("=" * 70)
print("   BẮT ĐẦU XÂY DỰNG TOÀN DIỆN SUBPAGES CÀI ĐẶT (TITLE & IN-GAME)   ")
print("=" * 70)

# ======================================================================
# 1. TRANG SOUND (CONFIG_P3)
# ======================================================================
print("\n[1/4] Xây dựng trang Âm Thanh (Sound)...")
sound_labels = [
    ("bgm",      "Nhạc nền"),
    ("down",     "Chế độ Downmix"),
    ("movie",    "Âm lượng phim"),
    ("se",       "Hiệu ứng âm thanh"),
    ("sysvo",    "Giọng hệ thống"),
    ("voice",    "Lời thoại"),
    ("voicecut", "Ngắt giọng khi bấm qua"),
    ("wave",     "Âm lượng tổng")
]

# 1.1 Sound EN
im_s_en_orig = Image.open(FRESH_DIR / "entry_01977.png").convert("RGBA")
canvas_s_en = Image.new("RGBA", (1100, 450), (0, 0, 0, 0))
canvas_s_en.paste(im_s_en_orig, (0, 0))
layout_s_en = {}
for idx, (k, text) in enumerate(sound_labels):
    nx, ny, nw, nh = 480, idx * 55, 600, 48
    lbl = render_left_label(text, width=nw, height=nh)
    canvas_s_en.paste(lbl, (nx, ny), lbl)
    layout_s_en[k] = {"x": nx, "y": ny, "w": nw, "h": nh}
png_s_en = Path("temp_sound_en.png")
canvas_s_en.save(png_s_en)
tlg_s_en = TLG_MSGTOOL_DIR / "entry_01977.tlg"
subprocess.run([str(MSG_TOOL), "import", "-t", "kirikiri-tlg", str(FRESH_DIR / "entry_01977.bin"), str(png_s_en), str(tlg_s_en)], check=True)
shutil.copy2(tlg_s_en, PATCH_UI_DIR / "entry_01977.bin")

# 1.2 Sound JP
im_s_jp_orig = Image.open(FRESH_DIR / "entry_01979.png").convert("RGBA")
canvas_s_jp = Image.new("RGBA", (1150, 450), (0, 0, 0, 0))
canvas_s_jp.paste(im_s_jp_orig, (0, 0))
layout_s_jp = {}
for idx, (k, text) in enumerate(sound_labels):
    nx, ny, nw, nh = 520, idx * 55, 600, 48
    lbl = render_left_label(text, width=nw, height=nh)
    canvas_s_jp.paste(lbl, (nx, ny), lbl)
    layout_s_jp[k] = {"x": nx, "y": ny, "w": nw, "h": nh}
png_s_jp = Path("temp_sound_jp.png")
canvas_s_jp.save(png_s_jp)
tlg_s_jp = TLG_MSGTOOL_DIR / "entry_01979.tlg"
subprocess.run([str(MSG_TOOL), "import", "-t", "kirikiri-tlg", str(FRESH_DIR / "entry_01979.bin"), str(png_s_jp), str(tlg_s_jp)], check=True)
shutil.copy2(tlg_s_jp, PATCH_UI_DIR / "entry_01979.bin")

def patch_sound_pbd(json_in, bin_orig, bin_out, layout_dict, stg_name):
    with open(json_in, "r", encoding="utf-8") as f:
        pbd = json.load(f)
    def walk(node):
        if isinstance(node, dict):
            uiname = node.get("uiname", "")
            if uiname.startswith("head_") and "uistates" in node:
                st = node["uistates"]
                for k, d in layout_dict.items():
                    if k in st:
                        st[k].update({
                            "storage": stg_name,
                            "cx": d["x"], "cy": d["y"], "cw": d["w"], "ch": d["h"],
                            "w": d["w"], "h": d["h"], "ox": 68, "oy": 3, "cr": None
                        })
            for k, v in node.items():
                if k != "uistates": walk(v)
        elif isinstance(node, list):
            for it in node: walk(it)
    walk(pbd.get("result", {}))
    tmp_json = Path(f"temp_sync_{bin_out.name}.json")
    with open(tmp_json, "w", encoding="utf-8") as f:
        json.dump(pbd, f, indent=2, ensure_ascii=False)
    subprocess.run([str(MSG_TOOL), "import", "-t", "kirikiri-tjs-ns0", str(bin_orig), str(tmp_json), str(bin_out)], check=True)

# In-game Sound
patch_sound_pbd(FRESH_DIR / "entry_01978.json", FRESH_DIR / "entry_01978.bin", PATCH_PBD_DIR / "entry_01978.bin", layout_s_en, "config_page3_en__pack")
patch_sound_pbd(FRESH_DIR / "entry_01980.json", FRESH_DIR / "entry_01980.bin", PATCH_PBD_DIR / "entry_01980.bin", layout_s_jp, "config_page3_jp__pack")
# Title Sound
title_s_en_json = list(DUMP_DIR.glob("entry_02096*.json"))[0]
title_s_en_bin  = list(EXT_DATA_DIR.glob("entry_02096*.bin"))[0]
patch_sound_pbd(title_s_en_json, title_s_en_bin, PATCH_PBD_DIR / "entry_02096.bin", layout_s_en, "config_page3_en__pack")

title_s_jp_json = list(DUMP_DIR.glob("entry_02098*.json"))[0]
title_s_jp_bin  = list(EXT_DATA_DIR.glob("entry_02098*.bin"))[0]
patch_sound_pbd(title_s_jp_json, title_s_jp_bin, PATCH_PBD_DIR / "entry_02098.bin", layout_s_jp, "config_page3_jp__pack")

# CN Sound Title + In-game (trỏ vào EN)
cn_s_ig_json = list(DUMP_DIR.glob("entry_01976*.json"))[0]
cn_s_ig_bin  = list(EXT_DATA_DIR.glob("entry_01976*.bin"))[0]
patch_sound_pbd(cn_s_ig_json, cn_s_ig_bin, PATCH_PBD_DIR / "entry_01976.bin", layout_s_en, "config_page3_en__pack")

cn_s_tt_json = list(DUMP_DIR.glob("entry_02095*.json"))[0]
cn_s_tt_bin  = list(EXT_DATA_DIR.glob("entry_02095*.bin"))[0]
patch_sound_pbd(cn_s_tt_json, cn_s_tt_bin, PATCH_PBD_DIR / "entry_02095.bin", layout_s_en, "config_page3_en__pack")
print("   + Hoàn tất Sound (PBD 1976, 1978, 1980, 2095, 2096, 2098; TLG 1977, 1979)!")

# ======================================================================
# 2. TRANG TEXT (CONFIG_P1)
# ======================================================================
print("\n[2/4] Xây dựng trang Văn Bản (Text)...")
text_labels = [
    ("autospeed",  "Tốc độ tự đọc"),
    ("autovwait",  "Chờ hết giọng khi tự đọc"),
    ("ctrlskip",   "Tua nhanh bằng phím Ctrl"),
    ("readskip",   "Bỏ qua thoại đã đọc"),
    ("rtextcol",   "Đổi màu chữ đã đọc"),
    ("skipall",    "Bỏ qua toàn bộ thoại"),
    ("textspeed",  "Tốc độ hiển thị chữ"),
    ("winopac",    "Độ mờ khung thoại")
]

im_t_orig = Image.open(FRESH_DIR / "entry_01961.png").convert("RGBA")
canvas_t = Image.new("RGBA", (1500, 800), (0, 0, 0, 0))
canvas_t.paste(im_t_orig, (0, 0))
layout_t = {}
for idx, (k, text) in enumerate(text_labels):
    nx, ny, nw, nh = 860, idx * 55, 600, 48
    lbl = render_left_label(text, width=nw, height=nh)
    canvas_t.paste(lbl, (nx, ny), lbl)
    layout_t[k] = {"x": nx, "y": ny, "w": nw, "h": nh}
png_t = Path("temp_text.png")
canvas_t.save(png_t)
tlg_t = TLG_MSGTOOL_DIR / "entry_01961.tlg"
subprocess.run([str(MSG_TOOL), "import", "-t", "kirikiri-tlg", str(FRESH_DIR / "entry_01961.bin"), str(png_t), str(tlg_t)], check=True)
shutil.copy2(tlg_t, PATCH_UI_DIR / "entry_01961.bin")

def patch_text_pbd(json_in, bin_orig, bin_out, layout_dict, stg_name):
    with open(json_in, "r", encoding="utf-8") as f:
        pbd = json.load(f)
    def walk(node):
        if isinstance(node, dict):
            uiname = node.get("uiname", "")
            if uiname.startswith("head_") and "uistates" in node:
                st = node["uistates"]
                for k, d in layout_dict.items():
                    if k in st:
                        st[k].update({
                            "storage": stg_name,
                            "cx": d["x"], "cy": d["y"], "cw": d["w"], "ch": d["h"],
                            "w": d["w"], "h": d["h"], "ox": 68, "oy": 3, "cr": None
                        })
            for k, v in node.items():
                if k != "uistates": walk(v)
        elif isinstance(node, list):
            for it in node: walk(it)
    walk(pbd.get("result", {}))
    tmp_json = Path(f"temp_sync_{bin_out.name}.json")
    with open(tmp_json, "w", encoding="utf-8") as f:
        json.dump(pbd, f, indent=2, ensure_ascii=False)
    subprocess.run([str(MSG_TOOL), "import", "-t", "kirikiri-tjs-ns0", str(bin_orig), str(tmp_json), str(bin_out)], check=True)

# In-game Text
patch_text_pbd(FRESH_DIR / "entry_01960.json", FRESH_DIR / "entry_01960.bin", PATCH_PBD_DIR / "entry_01960.bin", layout_t, "config_page1_en__pack")
patch_text_pbd(FRESH_DIR / "entry_01962.json", FRESH_DIR / "entry_01962.bin", PATCH_PBD_DIR / "entry_01962.bin", layout_t, "config_page1_jp__pack")
# Title Text
title_t_en_json = list(DUMP_DIR.glob("entry_02080*.json"))[0]
title_t_en_bin  = list(EXT_DATA_DIR.glob("entry_02080*.bin"))[0]
patch_text_pbd(title_t_en_json, title_t_en_bin, PATCH_PBD_DIR / "entry_02080.bin", layout_t, "config_page1_en__pack")

title_t_jp_json = list(DUMP_DIR.glob("entry_02082*.json"))[0]
title_t_jp_bin  = list(EXT_DATA_DIR.glob("entry_02082*.bin"))[0]
patch_text_pbd(title_t_jp_json, title_t_jp_bin, PATCH_PBD_DIR / "entry_02082.bin", layout_t, "config_page1_jp__pack")

# CN Text
cn_t_ig_json = list(DUMP_DIR.glob("entry_01958*.json"))[0]
cn_t_ig_bin  = list(EXT_DATA_DIR.glob("entry_01958*.bin"))[0]
patch_text_pbd(cn_t_ig_json, cn_t_ig_bin, PATCH_PBD_DIR / "entry_01958.bin", layout_t, "config_page1_en__pack")

cn_t_tt_json = list(DUMP_DIR.glob("entry_02078*.json"))[0]
cn_t_tt_bin  = list(EXT_DATA_DIR.glob("entry_02078*.bin"))[0]
patch_text_pbd(cn_t_tt_json, cn_t_tt_bin, PATCH_PBD_DIR / "entry_02078.bin", layout_t, "config_page1_en__pack")
print("   + Hoàn tất Text (PBD 1958, 1960, 1962, 2078, 2080, 2082; TLG 1961)!")

# ======================================================================
# 3. TRANG DIALOG (CONFIG_P2)
# ======================================================================
print("\n[3/4] Xây dựng trang Hội Thoại / Xác Nhận (Dialog)...")
dialog_labels = [
    ("cf_allremove1", "Xác nhận xóa toàn bộ dữ liệu"),
    ("cf_allremove2", "Xác nhận xóa toàn bộ thiết lập"),
    ("cf_backto",     "Xác nhận trở về trước đó"),
    ("cf_delete",     "Xác nhận xóa file lưu"),
    ("cf_exit",       "Xác nhận thoát trò chơi"),
    ("cf_init",       "Xác nhận khôi phục mặc định"),
    ("cf_jump",       "Xác nhận nhảy đến cảnh"),
    ("cf_load",       "Xác nhận tải file lưu"),
    ("cf_next",       "Xác nhận chuyển cảnh tiếp"),
    ("cf_overwrite",  "Xác nhận ghi đè file lưu"),
    ("cf_qload",      "Xác nhận tải nhanh"),
    ("cf_qsave",      "Xác nhận lưu nhanh"),
    ("cf_title",      "Xác nhận về màn hình chính")
]

# 3.1 Dialog EN
im_d_en_orig = Image.open(FRESH_DIR / "entry_01968.png").convert("RGBA")
canvas_d_en = Image.new("RGBA", (1500, 900), (0, 0, 0, 0))
canvas_d_en.paste(im_d_en_orig, (0, 0))
layout_d_en = {}
for idx, (k, text) in enumerate(dialog_labels):
    nx, ny, nw, nh = 870, idx * 55, 600, 48
    lbl = render_left_label(text, width=nw, height=nh)
    canvas_d_en.paste(lbl, (nx, ny), lbl)
    layout_d_en[k] = {"x": nx, "y": ny, "w": nw, "h": nh}
png_d_en = Path("temp_dialog_en.png")
canvas_d_en.save(png_d_en)
tlg_d_en = TLG_MSGTOOL_DIR / "entry_01968.tlg"
subprocess.run([str(MSG_TOOL), "import", "-t", "kirikiri-tlg", str(FRESH_DIR / "entry_01968.bin"), str(png_d_en), str(tlg_d_en)], check=True)
shutil.copy2(tlg_d_en, PATCH_UI_DIR / "entry_01968.bin")

# 3.2 Dialog JP
im_d_jp_orig = Image.open(FRESH_DIR / "entry_01970.png").convert("RGBA")
canvas_d_jp = Image.new("RGBA", (1550, 890), (0, 0, 0, 0))
canvas_d_jp.paste(im_d_jp_orig, (0, 0))
layout_d_jp = {}
for idx, (k, text) in enumerate(dialog_labels):
    nx, ny, nw, nh = 900, idx * 55, 600, 48
    lbl = render_left_label(text, width=nw, height=nh)
    canvas_d_jp.paste(lbl, (nx, ny), lbl)
    layout_d_jp[k] = {"x": nx, "y": ny, "w": nw, "h": nh}
png_d_jp = Path("temp_dialog_jp.png")
canvas_d_jp.save(png_d_jp)
tlg_d_jp = TLG_MSGTOOL_DIR / "entry_01970.tlg"
subprocess.run([str(MSG_TOOL), "import", "-t", "kirikiri-tlg", str(FRESH_DIR / "entry_01970.bin"), str(png_d_jp), str(tlg_d_jp)], check=True)
shutil.copy2(tlg_d_jp, PATCH_UI_DIR / "entry_01970.bin")

def patch_dialog_pbd(json_in, bin_orig, bin_out, layout_dict, stg_name):
    with open(json_in, "r", encoding="utf-8") as f:
        pbd = json.load(f)
    def walk(node):
        if isinstance(node, dict):
            uiname = node.get("uiname", "")
            if uiname.startswith("head_") and "uistates" in node:
                st = node["uistates"]
                for k, d in layout_dict.items():
                    if k in st:
                        st[k].update({
                            "storage": stg_name,
                            "cx": d["x"], "cy": d["y"], "cw": d["w"], "ch": d["h"],
                            "w": d["w"], "h": d["h"], "ox": 68, "oy": 3, "cr": None
                        })
            for k, v in node.items():
                if k != "uistates": walk(v)
        elif isinstance(node, list):
            for it in node: walk(it)
    walk(pbd.get("result", {}))
    tmp_json = Path(f"temp_sync_{bin_out.name}.json")
    with open(tmp_json, "w", encoding="utf-8") as f:
        json.dump(pbd, f, indent=2, ensure_ascii=False)
    subprocess.run([str(MSG_TOOL), "import", "-t", "kirikiri-tjs-ns0", str(bin_orig), str(tmp_json), str(bin_out)], check=True)

# In-game Dialog
patch_dialog_pbd(FRESH_DIR / "entry_01969.json", FRESH_DIR / "entry_01969.bin", PATCH_PBD_DIR / "entry_01969.bin", layout_d_en, "config_page2_en__pack")
patch_dialog_pbd(FRESH_DIR / "entry_01971.json", FRESH_DIR / "entry_01971.bin", PATCH_PBD_DIR / "entry_01971.bin", layout_d_jp, "config_page2_jp__pack")
# Title Dialog
title_d_en_json = list(DUMP_DIR.glob("entry_02088*.json"))[0]
title_d_en_bin  = list(EXT_DATA_DIR.glob("entry_02088*.bin"))[0]
patch_dialog_pbd(title_d_en_json, title_d_en_bin, PATCH_PBD_DIR / "entry_02088.bin", layout_d_en, "config_page2_en__pack")

title_d_jp_json = list(DUMP_DIR.glob("entry_02090*.json"))[0]
title_d_jp_bin  = list(EXT_DATA_DIR.glob("entry_02090*.bin"))[0]
patch_dialog_pbd(title_d_jp_json, title_d_jp_bin, PATCH_PBD_DIR / "entry_02090.bin", layout_d_jp, "config_page2_jp__pack")

# CN Dialog
cn_d_ig_json = list(DUMP_DIR.glob("entry_01967*.json"))[0]
cn_d_ig_bin  = list(EXT_DATA_DIR.glob("entry_01967*.bin"))[0]
patch_dialog_pbd(cn_d_ig_json, cn_d_ig_bin, PATCH_PBD_DIR / "entry_01967.bin", layout_d_en, "config_page2_en__pack")

cn_d_tt_json = list(DUMP_DIR.glob("entry_02086*.json"))[0]
cn_d_tt_bin  = list(EXT_DATA_DIR.glob("entry_02086*.bin"))[0]
patch_dialog_pbd(cn_d_tt_json, cn_d_tt_bin, PATCH_PBD_DIR / "entry_02086.bin", layout_d_en, "config_page2_en__pack")
print("   + Hoàn tất Dialog (PBD 1967, 1969, 1971, 2086, 2088, 2090; TLG 1968, 1970)!")

# ======================================================================
# 4. TRANG DISPLAY (CONFIG_P0)
# ======================================================================
print("\n[4/4] Xây dựng trang Hiển Thị (Display)...")
display_labels = [
    ("drawspeed",   "Tốc độ vẽ"),
    ("fullscreen",  "Chế độ hiển thị"),
    ("savequit",    "Quay lại game sau khi lưu"),
    ("sublang",     "Phụ đề ngôn ngữ phụ"),
    ("textlang",    "Ngôn ngữ văn bản chính"),
    ("touchmode",   "Chế độ cảm ứng"),
    ("uilang",      "Ngôn ngữ giao diện"),
    ("voicespeed",  "Tốc độ giọng nói"),
    ("vspeedsync",  "Đồng bộ tốc độ thoại")
]

# 4.1 Display EN (bảo vệ 100% nguyên bản 595x620)
im_dp_en_orig = Image.open(FRESH_DIR / "entry_01950.png").convert("RGBA")
canvas_dp_en = Image.new("RGBA", (1250, 650), (0, 0, 0, 0))
canvas_dp_en.paste(im_dp_en_orig, (0, 0))
layout_dp_en = {}
for idx, (k, text) in enumerate(display_labels):
    nx, ny, nw, nh = 620, idx * 55, 600, 48
    lbl = render_left_label(text, width=nw, height=nh)
    canvas_dp_en.paste(lbl, (nx, ny), lbl)
    layout_dp_en[k] = {"x": nx, "y": ny, "w": nw, "h": nh}
png_dp_en = Path("temp_display_en.png")
canvas_dp_en.save(png_dp_en)
tlg_dp_en = TLG_MSGTOOL_DIR / "entry_01950.tlg"
subprocess.run([str(MSG_TOOL), "import", "-t", "kirikiri-tlg", str(FRESH_DIR / "entry_01950.bin"), str(png_dp_en), str(tlg_dp_en)], check=True)
shutil.copy2(tlg_dp_en, PATCH_UI_DIR / "entry_01950.bin")

# 4.2 Display JP (bảo vệ 100% nguyên bản 637x626)
im_dp_jp_orig = Image.open(FRESH_DIR / "entry_01952.png").convert("RGBA")
canvas_dp_jp = Image.new("RGBA", (1300, 650), (0, 0, 0, 0))
canvas_dp_jp.paste(im_dp_jp_orig, (0, 0))
layout_dp_jp = {}
for idx, (k, text) in enumerate(display_labels):
    nx, ny, nw, nh = 650, idx * 55, 600, 48
    lbl = render_left_label(text, width=nw, height=nh)
    canvas_dp_jp.paste(lbl, (nx, ny), lbl)
    layout_dp_jp[k] = {"x": nx, "y": ny, "w": nw, "h": nh}
png_dp_jp = Path("temp_display_jp.png")
canvas_dp_jp.save(png_dp_jp)
tlg_dp_jp = TLG_MSGTOOL_DIR / "entry_01952.tlg"
subprocess.run([str(MSG_TOOL), "import", "-t", "kirikiri-tlg", str(FRESH_DIR / "entry_01952.bin"), str(png_dp_jp), str(tlg_dp_jp)], check=True)
shutil.copy2(tlg_dp_jp, PATCH_UI_DIR / "entry_01952.bin")

def patch_display_pbd(json_in, bin_orig, bin_out, layout_dict, stg_name):
    with open(json_in, "r", encoding="utf-8") as f:
        pbd = json.load(f)
    def walk(node):
        if isinstance(node, dict):
            uiname = node.get("uiname", "")
            if uiname.startswith("head_") and "uistates" in node:
                st = node["uistates"]
                for k, d in layout_dict.items():
                    if k in st:
                        st[k].update({
                            "storage": stg_name,
                            "cx": d["x"], "cy": d["y"], "cw": d["w"], "ch": d["h"],
                            "w": d["w"], "h": d["h"], "ox": 68, "oy": 3, "cr": None
                        })
            for k, v in node.items():
                if k != "uistates": walk(v)
        elif isinstance(node, list):
            for it in node: walk(it)
    walk(pbd.get("result", {}))
    tmp_json = Path(f"temp_sync_{bin_out.name}.json")
    with open(tmp_json, "w", encoding="utf-8") as f:
        json.dump(pbd, f, indent=2, ensure_ascii=False)
    subprocess.run([str(MSG_TOOL), "import", "-t", "kirikiri-tjs-ns0", str(bin_orig), str(tmp_json), str(bin_out)], check=True)

# In-game Display
patch_display_pbd(FRESH_DIR / "entry_01951.json", FRESH_DIR / "entry_01951.bin", PATCH_PBD_DIR / "entry_01951.bin", layout_dp_en, "config_page0_en__pack")
patch_display_pbd(FRESH_DIR / "entry_01953.json", FRESH_DIR / "entry_01953.bin", PATCH_PBD_DIR / "entry_01953.bin", layout_dp_jp, "config_page0_jp__pack")
# Title Display
title_dp_en_json = list(DUMP_DIR.glob("entry_02073*.json"))[0]
title_dp_en_bin  = list(EXT_DATA_DIR.glob("entry_02073*.bin"))[0]
patch_display_pbd(title_dp_en_json, title_dp_en_bin, PATCH_PBD_DIR / "entry_02073.bin", layout_dp_en, "config_page0_en__pack")

title_dp_jp_json = list(DUMP_DIR.glob("entry_02075*.json"))[0]
title_dp_jp_bin  = list(EXT_DATA_DIR.glob("entry_02075*.bin"))[0]
patch_display_pbd(title_dp_jp_json, title_dp_jp_bin, PATCH_PBD_DIR / "entry_02075.bin", layout_dp_jp, "config_page0_jp__pack")

# CN Display
cn_dp_ig_json = list(DUMP_DIR.glob("entry_01949*.json"))[0]
cn_dp_ig_bin  = list(EXT_DATA_DIR.glob("entry_01949*.bin"))[0]
patch_display_pbd(cn_dp_ig_json, cn_dp_ig_bin, PATCH_PBD_DIR / "entry_01949.bin", layout_dp_en, "config_page0_en__pack")

cn_dp_tt_json = list(DUMP_DIR.glob("entry_02072*.json"))[0]
cn_dp_tt_bin  = list(EXT_DATA_DIR.glob("entry_02072*.bin"))[0]
patch_display_pbd(cn_dp_tt_json, cn_dp_tt_bin, PATCH_PBD_DIR / "entry_02072.bin", layout_dp_en, "config_page0_en__pack")
print("   + Hoàn tất Display (PBD 1949, 1951, 1953, 2072, 2073, 2075; TLG 1950, 1952)!")

print("\n" + "=" * 70)
print("   HOÀN TẤT ĐỒNG BỘ TOÀN BỘ SUBPAGES CÀI ĐẶT 100% TIẾNG VIỆT CHUẨN!   ")
print("=" * 70)
