from PIL import Image
import numpy as np

im = Image.open("user_qmenu_crop.png").convert("RGBA")
arr = np.array(im)

# Quét từ y=0 đến 250, tìm các điểm chuyển giao màu nền (sang màu viên thuốc xám)
# Màu nền là hình căn phòng giường nệm sáng màu (R>150, G>150, B>150)
# Màu viên thuốc là xám đậm (R<100, G<100, B<100)
for y in range(50, 220, 5):
    row = arr[y, :, :3]
    # Tìm pixel đầu tiên có R < 100, G < 100, B < 100
    dark_xs = np.where((row[:, 0] < 100) & (row[:, 1] < 100) & (row[:, 2] < 100))[0]
    if len(dark_xs) > 0:
        print(f"y={y:3d}: first dark x = {dark_xs[0]}")
