import sys
sys.path.insert(0, r"E:\Extract Tools\cxdec-hxv4\src\common")
from xp3_inspect import DripProgram, read_archive, load_index, parse_hxv4_table, FilterRuntimeState
from pathlib import Path
import subprocess
from PIL import Image
import numpy as np

game_xp3 = Path(r"E:\Games\COCORO.FIXED\game\data.xp3")
drip_path = Path(r"E:\Extract Tools\cxdec-hxv4\data\static_recover\drip_program_COCORO.exe.unpacked.json")
drip = DripProgram.load(drip_path)
msg_tool = Path("tools/msg-tool/msg_tool.exe")

info, entries, blob = read_archive(game_xp3)
_, _, _, index = load_index(blob)
descriptor, records = parse_hxv4_table(blob, index, entries, drip)
open_flag = descriptor.flags & 1
record_map = {r.xp3_entry_index: r for r in records}

pts = [(97, 49), (19, 160), (97, 177), (0, 220)]
temp_dir = Path("temp_live_scan")
temp_dir.mkdir(exist_ok=True)

print("Scanning all live TLGs in data.xp3 for matching scrap points...")
with open(game_xp3, "rb") as f:
    for idx in range(1930, 2170):
        if idx >= len(entries): continue
        e = entries[idx]
        seg = e.segments[0]
        f.seek(seg.offset)
        raw_data = f.read(min(32, seg.archived_size))
        r = record_map.get(idx)
        cipher_data = bytearray(raw_data)
        if r is not None:
            seed = drip.build_filter_state(r.key, open_flag)
            state = FilterRuntimeState(seed)
            state.apply(cipher_data, 0)
        
        if cipher_data.startswith(b"TLG"):
            # read full
            f.seek(seg.offset)
            full_raw = f.read(seg.archived_size)
            full_cipher = bytearray(full_raw)
            if r is not None:
                seed = drip.build_filter_state(r.key, open_flag)
                state = FilterRuntimeState(seed)
                state.apply(full_cipher, 0)
            
            bin_p = temp_dir / f"live_{idx:05d}.bin"
            bin_p.write_bytes(full_cipher)
            png_p = temp_dir / f"live_{idx:05d}.png"
            res = subprocess.run([str(msg_tool), "export", "-t", "kirikiri-tlg", str(bin_p), str(png_p)], capture_output=True)
            if res.returncode == 0:
                im = Image.open(png_p).convert("RGBA")
                arr = np.array(im)
                # check if points match
                # check pt (97, 49) == [138, 149, 153] or similar grey
                if 49 < arr.shape[0] and 97 < arr.shape[1]:
                    pix = arr[49, 97]
                    if pix[3] > 100 and 120 <= pix[0] <= 155:
                        print(f"FOUND! Entry {idx:05d} has scrap at (97, 49)! RGBA={pix}, Image size={im.size}")
