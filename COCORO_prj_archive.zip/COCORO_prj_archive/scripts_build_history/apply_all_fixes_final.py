# -*- coding: utf-8 -*-
"""
Script áp dụng toàn bộ cập nhật giao diện và khắc phục lỗi theo yêu cầu người dùng:
1. Đổi màu chữ của tất cả các nhãn trong Subpages cài đặt sang màu #4a4a4a (74, 74, 74), giữ nguyên vị trí chuẩn.
2. Khắc phục triệt để lỗi dính miếng màu tím / mẩu icon trước chữ ở mục Hiển thị và Âm thanh.
3. Nhập 6 file Atlas mới từ thư mục 02_Xuat_Anh_Atlas_PNG_Vao_Day (lọc sạch magenta thành trong suốt).
4. Đồng bộ đầy đủ PBD (In-game và Title) và đóng gói vào data.xp3.
"""

import sys
import json
import shutil
import subprocess
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont
import numpy as np

ROOT_DIR = Path(r"D:\Software\Antigravity\Project\Cocoro")
MSG_TOOL = ROOT_DIR / "tools" / "msg-tool" / "msg_tool.exe"
FRESH_DIR = ROOT_DIR / "orig_fresh"
EXT_DATA_DIR = ROOT_DIR / "extracted_data" / "data"
DUMP_DIR = ROOT_DIR / "temp_pbd_dumps"
PATCH_UI_DIR = ROOT_DIR / "COCORO_Patch_VietHoa" / "patch_data" / "ui"
PATCH_PBD_DIR = ROOT_DIR / "COCORO_Patch_VietHoa" / "patch_data" / "pbd"
TLG_MSGTOOL_DIR = ROOT_DIR / "tlg_msgtool"
EXPORT_DIR = Path(r"D:\Workspace\Creative\2D\Projects\Photoshop\COCORO Prj\wireframe_guide\02_Xuat_Anh_Atlas_PNG_Vao_Day")

FONT_PATH = Path(r"C:\Users\ADMIN\AppData\Local\Microsoft\Windows\Fonts\STIXTwoText-Bold.ttf")
if not FONT_PATH.exists():
    FONT_PATH = Path(r"C:\Windows\Fonts\timesbd.ttf")

LABEL_FONT = ImageFont.truetype(str(FONT_PATH), 32)
# Mã màu yêu cầu: #4a4a4a -> RGB (74, 74, 74)
TEXT_COLOR = (74, 74, 74, 255)

def clean_magenta(im):
    arr = np.array(im)
    if len(arr.shape) >= 3 and arr.shape[2] >= 3:
        # Magenta: R > 180, G < 50, B > 180
        mask = (arr[:, :, 0] > 180) & (arr[:, :, 1] < 50) & (arr[:, :, 2] > 180)
        arr[mask] = [0, 0, 0, 0]
    return Image.fromarray(arr)

def render_left_label(text, width=600, height=48, margin_left=5):
    img = Image.new("RGBA", (width, height), (0, 0, 0, 0))
    draw = ImageDraw.Draw(img)
    bb = draw.textbbox((0, 0), text, font=LABEL_FONT)
    th = bb[3] - bb[1]
    tx = margin_left
    ty = (height - th) // 2 - bb[1]
    draw.text((tx, ty), text, font=LABEL_FONT, fill=TEXT_COLOR)
    return img

print("=" * 75)
print("   BẮT ĐẦU ÁP DỤNG BẢN SỬA LỖI & CẬP NHẬT GIAO DIỆN TOÀN DIỆN   ")
print("=" * 75)

# ======================================================================
# PHẦN 1: CẬP NHẬT 6 FILE ATLAS MỚI TỪ 02_Xuat_Anh_Atlas_PNG_Vao_Day
# ======================================================================
print("\n[1/4] Xử lý 6 file Atlas mới từ người dùng...")

# 1.1 Title Template Guide -> entry_02165.bin
title_png = EXPORT_DIR / "title_template_guide.png"
if title_png.exists():
    im_title = clean_magenta(Image.open(title_png).convert("RGBA"))
    tmp_title_png = Path("temp_title_clean.png")
    im_title.save(tmp_title_png)
    tlg_title = TLG_MSGTOOL_DIR / "entry_02165.tlg"
    subprocess.run([str(MSG_TOOL), "import", "-t", "kirikiri-tlg", str(FRESH_DIR / "entry_02165.bin"), str(tmp_title_png), str(tlg_title)], check=True)
    shutil.copy2(tlg_title, PATCH_UI_DIR / "entry_02165.bin")
    print("   + Đã nhập: title_template_guide.png -> entry_02165.bin (Title Atlas)")

# 1.2 Config Base Template Guide -> entry_01948.bin (Lọc sạch magenta)
cfg_base_png = EXPORT_DIR / "config_base_template_guide.png"
if cfg_base_png.exists():
    im_cfg_base = clean_magenta(Image.open(cfg_base_png).convert("RGBA"))
    tmp_cfg_base_png = Path("temp_cfg_base_clean.png")
    im_cfg_base.save(tmp_cfg_base_png)
    tlg_cfg_base = TLG_MSGTOOL_DIR / "entry_01948.tlg"
    subprocess.run([str(MSG_TOOL), "import", "-t", "kirikiri-tlg", str(FRESH_DIR / "entry_01948.bin"), str(tmp_cfg_base_png), str(tlg_cfg_base)], check=True)
    shutil.copy2(tlg_cfg_base, PATCH_UI_DIR / "entry_01948.bin")
    print("   + Đã nhập: config_base_template_guide.png -> entry_01948.bin (Config Tab Bar)")

# 1.3 Dialog Confirm Guide -> entry_01997.bin (Lọc sạch magenta)
dlg_conf_png = EXPORT_DIR / "dialog_confirm_guide.png"
if dlg_conf_png.exists():
    im_dlg = clean_magenta(Image.open(dlg_conf_png).convert("RGBA"))
    tmp_dlg_png = Path("temp_dlg_conf_clean.png")
    im_dlg.save(tmp_dlg_png)
    tlg_dlg = TLG_MSGTOOL_DIR / "entry_01997.tlg"
    subprocess.run([str(MSG_TOOL), "import", "-t", "kirikiri-tlg", str(EXT_DATA_DIR / "entry_01997_57cc.bin"), str(tmp_dlg_png), str(tlg_dlg)], check=True)
    shutil.copy2(tlg_dlg, PATCH_UI_DIR / "entry_01997.bin")
    print("   + Đã nhập: dialog_confirm_guide.png -> entry_01997.bin (Confirm Dialog)")

# 1.4 File Load Template Guide -> entry_02026.bin
file_load_png = EXPORT_DIR / "file_load_template_guide.png"
if file_load_png.exists():
    im_load = clean_magenta(Image.open(file_load_png).convert("RGBA"))
    tmp_load_png = Path("temp_file_load_clean.png")
    im_load.save(tmp_load_png)
    tlg_load = TLG_MSGTOOL_DIR / "entry_02026.tlg"
    subprocess.run([str(MSG_TOOL), "import", "-t", "kirikiri-tlg", str(EXT_DATA_DIR / "entry_02026_57e9.bin"), str(tmp_load_png), str(tlg_load)], check=True)
    shutil.copy2(tlg_load, PATCH_UI_DIR / "entry_02026.bin")
    # PBDs for file load
    if (DUMP_DIR / "entry_02025_57e8_synced.json").exists():
        subprocess.run([str(MSG_TOOL), "import", "-t", "kirikiri-tjs-ns0", str(EXT_DATA_DIR / "entry_02025_57e8.bin"), str(DUMP_DIR / "entry_02025_57e8_synced.json"), str(PATCH_PBD_DIR / "entry_02025.bin")], check=True)
    if (DUMP_DIR / "entry_02131_5852.json").exists():
        subprocess.run([str(MSG_TOOL), "import", "-t", "kirikiri-tjs-ns0", str(EXT_DATA_DIR / "entry_02131_5852.bin"), str(DUMP_DIR / "entry_02025_57e8_synced.json"), str(PATCH_PBD_DIR / "entry_02131.bin")], check=True)
    print("   + Đã nhập: file_load_template_guide.png -> entry_02026.bin (File Load)")

# 1.5 File Save Template Guide -> entry_02037.bin
file_save_png = EXPORT_DIR / "file_save_template_guide.png"
if file_save_png.exists():
    im_save = clean_magenta(Image.open(file_save_png).convert("RGBA"))
    tmp_save_png = Path("temp_file_save_clean.png")
    im_save.save(tmp_save_png)
    tlg_save = TLG_MSGTOOL_DIR / "entry_02037.tlg"
    subprocess.run([str(MSG_TOOL), "import", "-t", "kirikiri-tlg", str(EXT_DATA_DIR / "entry_02037_57f4.bin"), str(tmp_save_png), str(tlg_save)], check=True)
    shutil.copy2(tlg_save, PATCH_UI_DIR / "entry_02037.bin")
    # PBDs for file save
    if (DUMP_DIR / "entry_02036_57f3_synced.json").exists():
        subprocess.run([str(MSG_TOOL), "import", "-t", "kirikiri-tjs-ns0", str(EXT_DATA_DIR / "entry_02036_57f3.bin"), str(DUMP_DIR / "entry_02036_57f3_synced.json"), str(PATCH_PBD_DIR / "entry_02036.bin")], check=True)
    if (DUMP_DIR / "entry_02136_5857.json").exists():
        subprocess.run([str(MSG_TOOL), "import", "-t", "kirikiri-tjs-ns0", str(EXT_DATA_DIR / "entry_02136_5857.bin"), str(DUMP_DIR / "entry_02036_57f3_synced.json"), str(PATCH_PBD_DIR / "entry_02136.bin")], check=True)
    print("   + Đã nhập: file_save_template_guide.png -> entry_02037.bin (File Save)")

# 1.6 Gallery Template Guide -> entry_02081.bin
gallery_png = EXPORT_DIR / "gallery_template_guide.png"
if gallery_png.exists():
    im_gal = clean_magenta(Image.open(gallery_png).convert("RGBA"))
    tmp_gal_png = Path("temp_gallery_clean.png")
    im_gal.save(tmp_gal_png)
    tlg_gal = TLG_MSGTOOL_DIR / "entry_02081.tlg"
    subprocess.run([str(MSG_TOOL), "import", "-t", "kirikiri-tlg", str(EXT_DATA_DIR / "entry_02081_5820.bin"), str(tmp_gal_png), str(tlg_gal)], check=True)
    shutil.copy2(tlg_gal, PATCH_UI_DIR / "entry_02081.bin")
    # PBDs for gallery
    if (DUMP_DIR / "entry_02005_57d4_synced.json").exists():
        subprocess.run([str(MSG_TOOL), "import", "-t", "kirikiri-tjs-ns0", str(EXT_DATA_DIR / "entry_02005_57d4.bin"), str(DUMP_DIR / "entry_02005_57d4_synced.json"), str(PATCH_PBD_DIR / "entry_02005.bin")], check=True)
    if (DUMP_DIR / "entry_02116_5843.json").exists():
        subprocess.run([str(MSG_TOOL), "import", "-t", "kirikiri-tjs-ns0", str(EXT_DATA_DIR / "entry_02116_5843.bin"), str(DUMP_DIR / "entry_02005_57d4_synced.json"), str(PATCH_PBD_DIR / "entry_02116.bin")], check=True)
    print("   + Đã nhập: gallery_template_guide.png -> entry_02081.bin (Gallery)")

# ======================================================================
# PHẦN 2: XÂY DỰNG SUBPAGES CÀI ĐẶT (MÀU #4a4a4a & XÓA SẠCH VẾT TÍM/ICON)
# ======================================================================
print("\n[2/4] Xây dựng các Subpages Cài đặt với màu #4a4a4a và làm sạch tuyệt đối...")

# 2.1 TRANG SOUND (CONFIG_P3)
print("   - Đang xử lý Sound (Âm thanh)...")
sound_labels = [
    ("bgm",      "Nhạc nền"),
    ("down",     "Chế độ Downmix"),
    ("movie",    "Âm lượng phim"),
    ("se",       "Hiệu ứng âm thanh"),
    ("sysvo",    "Giọng hệ thống"),
    ("voice",    "Lời thoại"),
    ("voicecut", "Ngắt giọng khi bấm qua"),
    ("wave",     "Âm lượng tổng")
]

# Sound EN: Lấy ảnh gốc, lọc sạch magenta và xóa sạch vùng chữ tiếng Anh cũ (x < 467)
im_s_en_orig = clean_magenta(Image.open(FRESH_DIR / "entry_01977.png").convert("RGBA"))
# Xóa các vùng chữ tiếng Anh cũ để không bao giờ bị vẽ mẩu icon đè lên
draw_s_en = ImageDraw.Draw(im_s_en_orig)
# wave (45, 0, 38, 313), bgm (158, 282, 38, 108), down (0, 0, 45, 440), se (121, 0, 37, 283), movie (355, 377, 121, 38)
draw_s_en.rectangle([0, 0, 157, 440], fill=(0, 0, 0, 0))
draw_s_en.rectangle([158, 280, 200, 400], fill=(0, 0, 0, 0))
draw_s_en.rectangle([350, 370, 467, 440], fill=(0, 0, 0, 0))

canvas_s_en = Image.new("RGBA", (1100, 450), (0, 0, 0, 0))
canvas_s_en.paste(im_s_en_orig, (0, 0))
layout_s_en = {}
for idx, (k, text) in enumerate(sound_labels):
    nx, ny, nw, nh = 480, idx * 55, 600, 48
    lbl = render_left_label(text, width=nw, height=nh)
    canvas_s_en.paste(lbl, (nx, ny), lbl)
    layout_s_en[k] = {"x": nx, "y": ny, "w": nw, "h": nh}

png_s_en = Path("temp_sound_en.png")
canvas_s_en.save(png_s_en)
tlg_s_en = TLG_MSGTOOL_DIR / "entry_01977.tlg"
subprocess.run([str(MSG_TOOL), "import", "-t", "kirikiri-tlg", str(FRESH_DIR / "entry_01977.bin"), str(png_s_en), str(tlg_s_en)], check=True)
shutil.copy2(tlg_s_en, PATCH_UI_DIR / "entry_01977.bin")

# Sound JP
im_s_jp_orig = clean_magenta(Image.open(FRESH_DIR / "entry_01979.png").convert("RGBA"))
draw_s_jp = ImageDraw.Draw(im_s_jp_orig)
draw_s_jp.rectangle([0, 0, 160, 440], fill=(0, 0, 0, 0))
draw_s_jp.rectangle([160, 280, 200, 400], fill=(0, 0, 0, 0))
draw_s_jp.rectangle([350, 370, 506, 440], fill=(0, 0, 0, 0))

canvas_s_jp = Image.new("RGBA", (1150, 450), (0, 0, 0, 0))
canvas_s_jp.paste(im_s_jp_orig, (0, 0))
layout_s_jp = {}
for idx, (k, text) in enumerate(sound_labels):
    nx, ny, nw, nh = 520, idx * 55, 600, 48
    lbl = render_left_label(text, width=nw, height=nh)
    canvas_s_jp.paste(lbl, (nx, ny), lbl)
    layout_s_jp[k] = {"x": nx, "y": ny, "w": nw, "h": nh}

png_s_jp = Path("temp_sound_jp.png")
canvas_s_jp.save(png_s_jp)
tlg_s_jp = TLG_MSGTOOL_DIR / "entry_01979.tlg"
subprocess.run([str(MSG_TOOL), "import", "-t", "kirikiri-tlg", str(FRESH_DIR / "entry_01979.bin"), str(png_s_jp), str(tlg_s_jp)], check=True)
shutil.copy2(tlg_s_jp, PATCH_UI_DIR / "entry_01979.bin")

def patch_sound_pbd(json_in, bin_orig, bin_out, layout_dict, stg_name):
    with open(json_in, "r", encoding="utf-8") as f:
        pbd = json.load(f)
    def walk(node):
        if isinstance(node, dict):
            uiname = node.get("uiname", "")
            if uiname.startswith("head_"):
                if "uistates" not in node or not node["uistates"]:
                    node["uistates"] = {}
                st = node["uistates"]
                for k, d in layout_dict.items():
                    st[k] = {
                        "storage": stg_name,
                        "cx": d["x"], "cy": d["y"], "cw": d["w"], "ch": d["h"],
                        "w": d["w"], "h": d["h"], "ox": 68, "oy": 3, "cr": None
                    }
                if "line" not in st:
                    st["line"] = {
                        "storage": "config_page3__pack",
                        "cx": 0, "cy": 0, "cw": 70, "ch": 1622,
                        "w": 1622, "h": 70, "ox": 2, "oy": 0, "cr": 1
                    }
            for k, v in node.items():
                if k != "uistates": walk(v)
        elif isinstance(node, list):
            for it in node: walk(it)
    walk(pbd.get("result", {}))
    tmp_json = Path(f"temp_sync_{bin_out.name}.json")
    with open(tmp_json, "w", encoding="utf-8") as f:
        json.dump(pbd, f, indent=2, ensure_ascii=False)
    subprocess.run([str(MSG_TOOL), "import", "-t", "kirikiri-tjs-ns0", str(bin_orig), str(tmp_json), str(bin_out)], check=True)

# Patch Sound PBDs
patch_sound_pbd(FRESH_DIR / "entry_01978.json", FRESH_DIR / "entry_01978.bin", PATCH_PBD_DIR / "entry_01978.bin", layout_s_en, "config_page3_en__pack")
patch_sound_pbd(FRESH_DIR / "entry_01980.json", FRESH_DIR / "entry_01980.bin", PATCH_PBD_DIR / "entry_01980.bin", layout_s_jp, "config_page3_jp__pack")
title_s_en_json = list(DUMP_DIR.glob("entry_02096*.json"))[0]
title_s_en_bin  = list(EXT_DATA_DIR.glob("entry_02096*.bin"))[0]
patch_sound_pbd(title_s_en_json, title_s_en_bin, PATCH_PBD_DIR / "entry_02096.bin", layout_s_en, "config_page3_en__pack")
title_s_jp_json = list(DUMP_DIR.glob("entry_02098*.json"))[0]
title_s_jp_bin  = list(EXT_DATA_DIR.glob("entry_02098*.bin"))[0]
patch_sound_pbd(title_s_jp_json, title_s_jp_bin, PATCH_PBD_DIR / "entry_02098.bin", layout_s_jp, "config_page3_jp__pack")
cn_s_ig_json = list(DUMP_DIR.glob("entry_01976*.json"))[0]
cn_s_ig_bin  = list(EXT_DATA_DIR.glob("entry_01976*.bin"))[0]
patch_sound_pbd(cn_s_ig_json, cn_s_ig_bin, PATCH_PBD_DIR / "entry_01976.bin", layout_s_en, "config_page3_en__pack")
cn_s_tt_json = list(DUMP_DIR.glob("entry_02095*.json"))[0]
cn_s_tt_bin  = list(EXT_DATA_DIR.glob("entry_02095*.bin"))[0]
patch_sound_pbd(cn_s_tt_json, cn_s_tt_bin, PATCH_PBD_DIR / "entry_02095.bin", layout_s_en, "config_page3_en__pack")

# 2.2 TRANG DISPLAY (CONFIG_P0)
print("   - Đang xử lý Display (Hiển thị)...")
display_labels = [
    ("drawspeed",   "Tốc độ vẽ"),
    ("fullscreen",  "Chế độ hiển thị"),
    ("savequit",    "Quay lại game sau khi lưu"),
    ("sublang",     "Phụ đề ngôn ngữ phụ"),
    ("textlang",    "Ngôn ngữ văn bản chính"),
    ("touchmode",   "Chế độ cảm ứng"),
    ("uilang",      "Ngôn ngữ giao diện"),
    ("voicespeed",  "Tốc độ giọng nói"),
    ("vspeedsync",  "Đồng bộ tốc độ thoại")
]

# Display EN: Lọc sạch magenta, xóa sạch các vùng chữ tiếng Anh cũ để không bao giờ bị dính mẩu tím/chữ
im_dp_en_orig = clean_magenta(Image.open(FRESH_DIR / "entry_01950.png").convert("RGBA"))
draw_dp_en = ImageDraw.Draw(im_dp_en_orig)
# Xóa các vùng chữ tiếng Anh cũ (fullscreen: 0..314, 174..220; savequit: 0..549, 0..46; textlang/sublang: 282..595, 550..620; voicespeed/vspeedsync: 0..458, 46..137)
draw_dp_en.rectangle([0, 0, 595, 220], fill=(0, 0, 0, 0))
draw_dp_en.rectangle([282, 450, 595, 620], fill=(0, 0, 0, 0))

canvas_dp_en = Image.new("RGBA", (1250, 650), (0, 0, 0, 0))
canvas_dp_en.paste(im_dp_en_orig, (0, 0))
layout_dp_en = {}
for idx, (k, text) in enumerate(display_labels):
    nx, ny, nw, nh = 620, idx * 55, 600, 48
    lbl = render_left_label(text, width=nw, height=nh)
    canvas_dp_en.paste(lbl, (nx, ny), lbl)
    layout_dp_en[k] = {"x": nx, "y": ny, "w": nw, "h": nh}

png_dp_en = Path("temp_display_en.png")
canvas_dp_en.save(png_dp_en)
tlg_dp_en = TLG_MSGTOOL_DIR / "entry_01950.tlg"
subprocess.run([str(MSG_TOOL), "import", "-t", "kirikiri-tlg", str(FRESH_DIR / "entry_01950.bin"), str(png_dp_en), str(tlg_dp_en)], check=True)
shutil.copy2(tlg_dp_en, PATCH_UI_DIR / "entry_01950.bin")

# Display JP
im_dp_jp_orig = clean_magenta(Image.open(FRESH_DIR / "entry_01952.png").convert("RGBA"))
draw_dp_jp = ImageDraw.Draw(im_dp_jp_orig)
draw_dp_jp.rectangle([0, 0, 637, 220], fill=(0, 0, 0, 0))
draw_dp_jp.rectangle([282, 450, 637, 626], fill=(0, 0, 0, 0))

canvas_dp_jp = Image.new("RGBA", (1300, 650), (0, 0, 0, 0))
canvas_dp_jp.paste(im_dp_jp_orig, (0, 0))
layout_dp_jp = {}
for idx, (k, text) in enumerate(display_labels):
    nx, ny, nw, nh = 650, idx * 55, 600, 48
    lbl = render_left_label(text, width=nw, height=nh)
    canvas_dp_jp.paste(lbl, (nx, ny), lbl)
    layout_dp_jp[k] = {"x": nx, "y": ny, "w": nw, "h": nh}

png_dp_jp = Path("temp_display_jp.png")
canvas_dp_jp.save(png_dp_jp)
tlg_dp_jp = TLG_MSGTOOL_DIR / "entry_01952.tlg"
subprocess.run([str(MSG_TOOL), "import", "-t", "kirikiri-tlg", str(FRESH_DIR / "entry_01952.bin"), str(png_dp_jp), str(tlg_dp_jp)], check=True)
shutil.copy2(tlg_dp_jp, PATCH_UI_DIR / "entry_01952.bin")

def patch_display_pbd(json_in, bin_orig, bin_out, layout_dict, stg_name):
    with open(json_in, "r", encoding="utf-8") as f:
        pbd = json.load(f)
    def walk(node):
        if isinstance(node, dict):
            uiname = node.get("uiname", "")
            if uiname.startswith("head_"):
                # Đảm bảo node luôn có uistates đầy đủ, khắc phục triệt để lỗi uistates: {} ở Title Menu
                if "uistates" not in node or not node["uistates"]:
                    node["uistates"] = {}
                st = node["uistates"]
                for k, d in layout_dict.items():
                    st[k] = {
                        "storage": stg_name,
                        "cx": d["x"], "cy": d["y"], "cw": d["w"], "ch": d["h"],
                        "w": d["w"], "h": d["h"], "ox": 68, "oy": 3, "cr": None
                    }
                if "line" not in st:
                    st["line"] = {
                        "storage": "config_page0__pack",
                        "cx": 0, "cy": 0, "cw": 1622, "ch": 70,
                        "w": 1622, "h": 70, "ox": 2, "oy": 0, "cr": None
                    }
            for k, v in node.items():
                if k != "uistates": walk(v)
        elif isinstance(node, list):
            for it in node: walk(it)
    walk(pbd.get("result", {}))
    tmp_json = Path(f"temp_sync_{bin_out.name}.json")
    with open(tmp_json, "w", encoding="utf-8") as f:
        json.dump(pbd, f, indent=2, ensure_ascii=False)
    subprocess.run([str(MSG_TOOL), "import", "-t", "kirikiri-tjs-ns0", str(bin_orig), str(tmp_json), str(bin_out)], check=True)

# Patch Display PBDs
patch_display_pbd(FRESH_DIR / "entry_01951.json", FRESH_DIR / "entry_01951.bin", PATCH_PBD_DIR / "entry_01951.bin", layout_dp_en, "config_page0_en__pack")
patch_display_pbd(FRESH_DIR / "entry_01953.json", FRESH_DIR / "entry_01953.bin", PATCH_PBD_DIR / "entry_01953.bin", layout_dp_jp, "config_page0_jp__pack")
title_dp_en_json = list(DUMP_DIR.glob("entry_02073*.json"))[0]
title_dp_en_bin  = list(EXT_DATA_DIR.glob("entry_02073*.bin"))[0]
patch_display_pbd(title_dp_en_json, title_dp_en_bin, PATCH_PBD_DIR / "entry_02073.bin", layout_dp_en, "config_page0_en__pack")
title_dp_jp_json = list(DUMP_DIR.glob("entry_02075*.json"))[0]
title_dp_jp_bin  = list(EXT_DATA_DIR.glob("entry_02075*.bin"))[0]
patch_display_pbd(title_dp_jp_json, title_dp_jp_bin, PATCH_PBD_DIR / "entry_02075.bin", layout_dp_jp, "config_page0_jp__pack")
cn_dp_ig_json = list(DUMP_DIR.glob("entry_01949*.json"))[0]
cn_dp_ig_bin  = list(EXT_DATA_DIR.glob("entry_01949*.bin"))[0]
patch_display_pbd(cn_dp_ig_json, cn_dp_ig_bin, PATCH_PBD_DIR / "entry_01949.bin", layout_dp_en, "config_page0_en__pack")
cn_dp_tt_json = list(DUMP_DIR.glob("entry_02072*.json"))[0]
cn_dp_tt_bin  = list(EXT_DATA_DIR.glob("entry_02072*.bin"))[0]
patch_display_pbd(cn_dp_tt_json, cn_dp_tt_bin, PATCH_PBD_DIR / "entry_02072.bin", layout_dp_en, "config_page0_en__pack")

# 2.3 TRANG TEXT (CONFIG_P1)
print("   - Đang xử lý Text (Văn bản)...")
text_labels = [
    ("autospeed",  "Tốc độ tự đọc"),
    ("autovwait",  "Chờ hết giọng khi tự đọc"),
    ("ctrlskip",   "Tua nhanh bằng phím Ctrl"),
    ("readskip",   "Bỏ qua thoại đã đọc"),
    ("rtextcol",   "Đổi màu chữ đã đọc"),
    ("skipall",    "Bỏ qua toàn bộ thoại"),
    ("textspeed",  "Tốc độ hiển thị chữ"),
    ("winopac",    "Độ mờ khung thoại")
]

im_t_orig = clean_magenta(Image.open(FRESH_DIR / "entry_01961.png").convert("RGBA"))
canvas_t = Image.new("RGBA", (1500, 800), (0, 0, 0, 0))
canvas_t.paste(im_t_orig, (0, 0))
layout_t = {}
for idx, (k, text) in enumerate(text_labels):
    nx, ny, nw, nh = 860, idx * 55, 600, 48
    lbl = render_left_label(text, width=nw, height=nh)
    canvas_t.paste(lbl, (nx, ny), lbl)
    layout_t[k] = {"x": nx, "y": ny, "w": nw, "h": nh}

png_t = Path("temp_text.png")
canvas_t.save(png_t)
tlg_t = TLG_MSGTOOL_DIR / "entry_01961.tlg"
subprocess.run([str(MSG_TOOL), "import", "-t", "kirikiri-tlg", str(FRESH_DIR / "entry_01961.bin"), str(png_t), str(tlg_t)], check=True)
shutil.copy2(tlg_t, PATCH_UI_DIR / "entry_01961.bin")

def patch_text_pbd(json_in, bin_orig, bin_out, layout_dict, stg_name):
    with open(json_in, "r", encoding="utf-8") as f:
        pbd = json.load(f)
    def walk(node):
        if isinstance(node, dict):
            uiname = node.get("uiname", "")
            if uiname.startswith("head_"):
                if "uistates" not in node or not node["uistates"]:
                    node["uistates"] = {}
                st = node["uistates"]
                for k, d in layout_dict.items():
                    st[k] = {
                        "storage": stg_name,
                        "cx": d["x"], "cy": d["y"], "cw": d["w"], "ch": d["h"],
                        "w": d["w"], "h": d["h"], "ox": 68, "oy": 3, "cr": None
                    }
                if "line" not in st:
                    st["line"] = {
                        "storage": "config_page1__pack",
                        "cx": 0, "cy": 0, "cw": 1622, "ch": 70,
                        "w": 1622, "h": 70, "ox": 2, "oy": 7, "cr": None
                    }
            for k, v in node.items():
                if k != "uistates": walk(v)
        elif isinstance(node, list):
            for it in node: walk(it)
    walk(pbd.get("result", {}))
    tmp_json = Path(f"temp_sync_{bin_out.name}.json")
    with open(tmp_json, "w", encoding="utf-8") as f:
        json.dump(pbd, f, indent=2, ensure_ascii=False)
    subprocess.run([str(MSG_TOOL), "import", "-t", "kirikiri-tjs-ns0", str(bin_orig), str(tmp_json), str(bin_out)], check=True)

patch_text_pbd(FRESH_DIR / "entry_01960.json", FRESH_DIR / "entry_01960.bin", PATCH_PBD_DIR / "entry_01960.bin", layout_t, "config_page1_en__pack")
patch_text_pbd(FRESH_DIR / "entry_01962.json", FRESH_DIR / "entry_01962.bin", PATCH_PBD_DIR / "entry_01962.bin", layout_t, "config_page1_jp__pack")
title_t_en_json = list(DUMP_DIR.glob("entry_02080*.json"))[0]
title_t_en_bin  = list(EXT_DATA_DIR.glob("entry_02080*.bin"))[0]
patch_text_pbd(title_t_en_json, title_t_en_bin, PATCH_PBD_DIR / "entry_02080.bin", layout_t, "config_page1_en__pack")
title_t_jp_json = list(DUMP_DIR.glob("entry_02082*.json"))[0]
title_t_jp_bin  = list(EXT_DATA_DIR.glob("entry_02082*.bin"))[0]
patch_text_pbd(title_t_jp_json, title_t_jp_bin, PATCH_PBD_DIR / "entry_02082.bin", layout_t, "config_page1_jp__pack")
cn_t_ig_json = list(DUMP_DIR.glob("entry_01958*.json"))[0]
cn_t_ig_bin  = list(EXT_DATA_DIR.glob("entry_01958*.bin"))[0]
patch_text_pbd(cn_t_ig_json, cn_t_ig_bin, PATCH_PBD_DIR / "entry_01958.bin", layout_t, "config_page1_en__pack")
cn_t_tt_json = list(DUMP_DIR.glob("entry_02078*.json"))[0]
cn_t_tt_bin  = list(EXT_DATA_DIR.glob("entry_02078*.bin"))[0]
patch_text_pbd(cn_t_tt_json, cn_t_tt_bin, PATCH_PBD_DIR / "entry_02078.bin", layout_t, "config_page1_en__pack")

# 2.4 TRANG DIALOG (CONFIG_P2)
print("   - Đang xử lý Dialog (Hội thoại)...")
dialog_labels = [
    ("cf_allremove1", "Xác nhận xóa toàn bộ dữ liệu"),
    ("cf_allremove2", "Xác nhận xóa toàn bộ thiết lập"),
    ("cf_backto",     "Xác nhận trở về trước đó"),
    ("cf_delete",     "Xác nhận xóa file lưu"),
    ("cf_exit",       "Xác nhận thoát trò chơi"),
    ("cf_init",       "Xác nhận khôi phục mặc định"),
    ("cf_jump",       "Xác nhận nhảy đến cảnh"),
    ("cf_load",       "Xác nhận tải file lưu"),
    ("cf_next",       "Xác nhận chuyển cảnh tiếp"),
    ("cf_overwrite",  "Xác nhận ghi đè file lưu"),
    ("cf_qload",      "Xác nhận tải nhanh"),
    ("cf_qsave",      "Xác nhận lưu nhanh"),
    ("cf_title",      "Xác nhận về màn hình chính")
]

# Dialog EN
im_d_en_orig = clean_magenta(Image.open(FRESH_DIR / "entry_01968.png").convert("RGBA"))
canvas_d_en = Image.new("RGBA", (1500, 900), (0, 0, 0, 0))
canvas_d_en.paste(im_d_en_orig, (0, 0))
layout_d_en = {}
for idx, (k, text) in enumerate(dialog_labels):
    nx, ny, nw, nh = 860, idx * 55, 600, 48
    lbl = render_left_label(text, width=nw, height=nh)
    canvas_d_en.paste(lbl, (nx, ny), lbl)
    layout_d_en[k] = {"x": nx, "y": ny, "w": nw, "h": nh}

png_d_en = Path("temp_dialog_en.png")
canvas_d_en.save(png_d_en)
tlg_d_en = TLG_MSGTOOL_DIR / "entry_01968.tlg"
subprocess.run([str(MSG_TOOL), "import", "-t", "kirikiri-tlg", str(FRESH_DIR / "entry_01968.bin"), str(png_d_en), str(tlg_d_en)], check=True)
shutil.copy2(tlg_d_en, PATCH_UI_DIR / "entry_01968.bin")

# Dialog JP
im_d_jp_orig = clean_magenta(Image.open(FRESH_DIR / "entry_01970.png").convert("RGBA"))
canvas_d_jp = Image.new("RGBA", (1550, 900), (0, 0, 0, 0))
canvas_d_jp.paste(im_d_jp_orig, (0, 0))
layout_d_jp = {}
for idx, (k, text) in enumerate(dialog_labels):
    nx, ny, nw, nh = 900, idx * 55, 600, 48
    lbl = render_left_label(text, width=nw, height=nh)
    canvas_d_jp.paste(lbl, (nx, ny), lbl)
    layout_d_jp[k] = {"x": nx, "y": ny, "w": nw, "h": nh}

png_d_jp = Path("temp_dialog_jp.png")
canvas_d_jp.save(png_d_jp)
tlg_d_jp = TLG_MSGTOOL_DIR / "entry_01970.tlg"
subprocess.run([str(MSG_TOOL), "import", "-t", "kirikiri-tlg", str(FRESH_DIR / "entry_01970.bin"), str(png_d_jp), str(tlg_d_jp)], check=True)
shutil.copy2(tlg_d_jp, PATCH_UI_DIR / "entry_01970.bin")

def patch_dialog_pbd(json_in, bin_orig, bin_out, layout_dict, stg_name):
    with open(json_in, "r", encoding="utf-8") as f:
        pbd = json.load(f)
    def walk(node):
        if isinstance(node, dict):
            uiname = node.get("uiname", "")
            if uiname.startswith("head_"):
                if "uistates" not in node or not node["uistates"]:
                    node["uistates"] = {}
                st = node["uistates"]
                for k, d in layout_dict.items():
                    st[k] = {
                        "storage": stg_name,
                        "cx": d["x"], "cy": d["y"], "cw": d["w"], "ch": d["h"],
                        "w": d["w"], "h": d["h"], "ox": 68, "oy": 3, "cr": None
                    }
                if "line" not in st:
                    st["line"] = {
                        "storage": "config_page2__pack",
                        "cx": 0, "cy": 0, "cw": 1622, "ch": 70,
                        "w": 1622, "h": 70, "ox": 2, "oy": 7, "cr": None
                    }
            for k, v in node.items():
                if k != "uistates": walk(v)
        elif isinstance(node, list):
            for it in node: walk(it)
    walk(pbd.get("result", {}))
    tmp_json = Path(f"temp_sync_{bin_out.name}.json")
    with open(tmp_json, "w", encoding="utf-8") as f:
        json.dump(pbd, f, indent=2, ensure_ascii=False)
    subprocess.run([str(MSG_TOOL), "import", "-t", "kirikiri-tjs-ns0", str(bin_orig), str(tmp_json), str(bin_out)], check=True)

patch_dialog_pbd(FRESH_DIR / "entry_01969.json", FRESH_DIR / "entry_01969.bin", PATCH_PBD_DIR / "entry_01969.bin", layout_d_en, "config_page2_en__pack")
patch_dialog_pbd(FRESH_DIR / "entry_01971.json", FRESH_DIR / "entry_01971.bin", PATCH_PBD_DIR / "entry_01971.bin", layout_d_jp, "config_page2_jp__pack")
title_d_en_json = list(DUMP_DIR.glob("entry_02088*.json"))[0]
title_d_en_bin  = list(EXT_DATA_DIR.glob("entry_02088*.bin"))[0]
patch_dialog_pbd(title_d_en_json, title_d_en_bin, PATCH_PBD_DIR / "entry_02088.bin", layout_d_en, "config_page2_en__pack")
title_d_jp_json = list(DUMP_DIR.glob("entry_02090*.json"))[0]
title_d_jp_bin  = list(EXT_DATA_DIR.glob("entry_02090*.bin"))[0]
patch_dialog_pbd(title_d_jp_json, title_d_jp_bin, PATCH_PBD_DIR / "entry_02090.bin", layout_d_jp, "config_page2_jp__pack")
cn_d_ig_json = list(DUMP_DIR.glob("entry_01967*.json"))[0]
cn_d_ig_bin  = list(EXT_DATA_DIR.glob("entry_01967*.bin"))[0]
patch_dialog_pbd(cn_d_ig_json, cn_d_ig_bin, PATCH_PBD_DIR / "entry_01967.bin", layout_d_en, "config_page2_en__pack")
cn_d_tt_json = list(DUMP_DIR.glob("entry_02086*.json"))[0]
cn_d_tt_bin  = list(EXT_DATA_DIR.glob("entry_02086*.bin"))[0]
patch_dialog_pbd(cn_d_tt_json, cn_d_tt_bin, PATCH_PBD_DIR / "entry_02086.bin", layout_d_en, "config_page2_en__pack")

print("   + Hoàn tất đồng bộ Subpages Cài đặt với màu #4a4a4a và làm sạch tuyệt đối!")

# ======================================================================
# PHẦN 3: ĐÓNG GÓI VÀO GAME DATA.XP3
# ======================================================================
print("\n[3/4] Tiến hành repack toàn bộ bản dịch và UI vào data.xp3...")
python_exe = Path(r"C:\Users\ADMIN\AppData\Local\Python\bin\python.exe")
repack_script = ROOT_DIR / "repack_viet_hoa_full.py"
res = subprocess.run([str(python_exe), str(repack_script)], capture_output=True, text=True)
print(res.stdout)
if res.returncode != 0:
    print("[-] LỖI REPACK:", res.stderr)
    sys.exit(1)

# ======================================================================
# PHẦN 4: KIỂM TRA NGHIỆM THU
# ======================================================================
print("\n[4/4] Kiểm tra nghiệm thu chất lượng bản đóng gói...")
XP3_PATH = Path(r"E:\Games\COCORO.FIXED\game\data.xp3")
print(f"   + data.xp3 đã cập nhật: {XP3_PATH.stat().st_size:,} bytes")
print("=" * 75)
print("   HOÀN TẤT TOÀN BỘ CÔNG VIỆC THÀNH CÔNG RỰC RỠ!   ")
print("=" * 75)
