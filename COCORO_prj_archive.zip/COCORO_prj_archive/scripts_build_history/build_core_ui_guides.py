# -*- coding: utf-8 -*-
"""
COCORO - Master Generator for All Core UI Guides & Engine Synchronization
Modules included:
1. System Dialog (entry_01997_57cc / PBD 1998 & 1996) - 21 slices
2. Backlog (entry_01931_578a / PBD 1932 & 1930) - 9 slices
3. File Load (entry_02026_57e9 / PBD 2027 & 2025) - 6 slices
4. File Save (entry_02037_57f4 / PBD 2038 & 2036) - 6 slices
5. Config Base (entry_01942_5795 / PBD 1943 & 1941) - 4 slices
6. Extra Gallery (entry_02006_57d5 / PBD 2007 & 2005) - 2 slices
"""

import sys
import json
import subprocess
from pathlib import Path
import numpy as np
from PIL import Image, ImageDraw, ImageFont, ImageFilter
import pytoshop
from pytoshop.user import nested_layers

ROOT_DIR = Path(r"D:\Software\Antigravity\Project\Cocoro")
OUTPUT_DIR = Path(r"D:\Workspace\Creative\2D\Projects\Photoshop\COCORO Prj\wireframe_guide")
RAW_DIR = ROOT_DIR / "image" / "UI_Raw"
DUMP_DIR = ROOT_DIR / "temp_pbd_dumps"
MSG_TOOL = ROOT_DIR / "tools" / "msg-tool" / "msg_tool.exe"
REPACK_SCRIPT = ROOT_DIR / "repack_viet_hoa_full.py"
USER_PYTHON = Path(r"C:\Users\ADMIN\AppData\Local\Python\bin\python.exe")
PATCH_PBD_DIR = ROOT_DIR / "COCORO_Patch_VietHoa" / "patch_data" / "pbd"
PATCH_UI_DIR = ROOT_DIR / "COCORO_Patch_VietHoa" / "patch_data" / "ui"
TLG_MSGTOOL_DIR = ROOT_DIR / "tlg_msgtool"

PATCH_PBD_DIR.mkdir(parents=True, exist_ok=True)
PATCH_UI_DIR.mkdir(parents=True, exist_ok=True)
TLG_MSGTOOL_DIR.mkdir(parents=True, exist_ok=True)
OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

# Fonts
font_bold = Path(r"C:\Windows\Fonts\STIXTwoText-Bold.ttf")
if not font_bold.exists():
    font_bold = Path(r"C:\Windows\Fonts\timesbd.ttf")
small_font = ImageFont.truetype(str(font_bold), 11)

def pil_to_pytoshop_layer(pil_img, name, left, top):
    arr = np.array(pil_img)
    h, w = arr.shape[:2]
    return nested_layers.Image(
        name=name,
        top=top,
        left=left,
        bottom=top + h,
        right=left + w,
        channels={
            0: arr[:, :, 0],
            1: arr[:, :, 1],
            2: arr[:, :, 2],
            -1: arr[:, :, 3]
        }
    )

def create_text_image(text, box_w, box_h, font_size, text_color, glow=False, glow_color=(0, 168, 255, 230)):
    font = ImageFont.truetype(str(font_bold), font_size)
    dummy = Image.new("RGBA", (1, 1), (0, 0, 0, 0))
    d = ImageDraw.Draw(dummy)
    bbox = d.textbbox((0, 0), text, font=font)
    tw = bbox[2] - bbox[0]
    th = bbox[3] - bbox[1]
    
    img = Image.new("RGBA", (box_w, box_h), (0, 0, 0, 0))
    tx = (box_w - tw) // 2 - bbox[0]
    ty = (box_h - th) // 2 - bbox[1] - 1
    
    if glow:
        glow_img = Image.new("RGBA", (box_w, box_h), (0, 0, 0, 0))
        gd = ImageDraw.Draw(glow_img)
        for ox in range(-2, 3):
            for oy in range(-2, 3):
                gd.text((tx + ox, ty + oy), text, font=font, fill=glow_color)
        glow_img = glow_img.filter(ImageFilter.GaussianBlur(1.8))
        img.paste(glow_img, (0, 0), glow_img)
    
    draw = ImageDraw.Draw(img)
    draw.text((tx, ty), text, font=font, fill=text_color)
    return img

def sync_pbd_file(pbd_json_path, pbd_bin_path, slice_updates, out_pbd_bin):
    """
    Cập nhật packlist và result uistates trong file PBD JSON rồi biên dịch lại nhị phân
    slice_updates: dict { slice_idx: { 'cx': cx, 'cy': cy, 'cw': cw, 'ch': ch, 'ox': ox, 'oy': oy, 'w': w, 'h': h, 'node': node, 'state': state } }
    """
    with open(pbd_json_path, "r", encoding="utf-8") as f:
        pbd = json.load(f)
    
    packlist = pbd.get("packlist", [])
    result = pbd.get("result", {})
    
    for s_idx, u in slice_updates.items():
        if s_idx < len(packlist):
            s = packlist[s_idx]
            s[0] = u["cx"]
            s[1] = u["cy"]
            s[2] = u["cw"]
            s[3] = u["ch"]
            if len(s) > 8 and isinstance(s[8], list) and len(s[8]) >= 6:
                if "ox" in u and u["ox"] is not None:
                    s[8][4] = u["ox"]
                if "oy" in u and u["oy"] is not None:
                    s[8][5] = u["oy"]
                if "w" in u and u["w"] is not None:
                    s[8][2] = u["w"]
                if "h" in u and u["h"] is not None:
                    s[8][3] = u["h"]
        
        node_name = u.get("node")
        state_name = u.get("state")
        if node_name and node_name in result and isinstance(result[node_name], dict):
            states = result[node_name].get("uistates", {})
            if state_name and state_name in states and isinstance(states[state_name], dict):
                st = states[state_name]
                st["cx"] = u["cx"]
                st["cy"] = u["cy"]
                st["cw"] = u["cw"]
                st["ch"] = u["ch"]
                if "ox" in u and u["ox"] is not None:
                    st["ox"] = u["ox"]
                if "oy" in u and u["oy"] is not None:
                    st["oy"] = u["oy"]
                if "w" in u and u["w"] is not None:
                    st["w"] = u["w"]
                if "h" in u and u["h"] is not None:
                    st["h"] = u["h"]
            # Also update on/over aliases if applicable
            if state_name == "over" and "on" in states:
                st = states["on"]
                st["cx"] = u["cx"]
                st["cy"] = u["cy"]
                st["cw"] = u["cw"]
                st["ch"] = u["ch"]
                if "ox" in u and u["ox"] is not None:
                    st["ox"] = u["ox"]
                if "oy" in u and u["oy"] is not None:
                    st["oy"] = u["oy"]
    
    # Save temp synced json
    temp_json = DUMP_DIR / f"{pbd_json_path.stem}_synced.json"
    with open(temp_json, "w", encoding="utf-8") as f:
        json.dump(pbd, f, indent=2, ensure_ascii=False)
        
    cmd = [str(MSG_TOOL), "import", "-t", "kirikiri-tjs-ns0", str(pbd_bin_path), str(temp_json), str(out_pbd_bin)]
    res = subprocess.run(cmd, capture_output=True, text=True)
    assert res.returncode == 0, f"Lỗi biên dịch PBD {out_pbd_bin.name}: {res.stderr}"

def convert_png_to_tlg(orig_bin, in_png, out_tlg):
    cmd = [str(MSG_TOOL), "import", "-t", "kirikiri-tlg", str(orig_bin), str(in_png), str(out_tlg)]
    res = subprocess.run(cmd, capture_output=True, text=True)
    assert res.returncode == 0, f"Lỗi chuyển TLG {out_tlg.name}: {res.stderr}"

print("\n[+] Đã khởi tạo các hàm lõi.")

# ======================================================================
# MODULE 1: SYSTEM DIALOG (entry_01997_57cc / PBD 1998 & 1996)
# ======================================================================
def build_dialog_module():
    print("\n------------------------------------------------------")
    print("[MODULE 1] Bắt đầu xử lý SYSTEM DIALOG (entry_01997_57cc)...")
    raw_img = Image.open(RAW_DIR / "entry_01997_57cc.png").convert("RGBA")
    
    CANVAS_W = 800
    CANVAS_H = 1320
    
    atlas_base = Image.new("RGBA", (CANVAS_W, CANVAS_H), (0, 0, 0, 0))
    atlas_guide = Image.new("RGBA", (CANVAS_W, CANVAS_H), (0, 0, 0, 0))
    draw_guide = ImageDraw.Draw(atlas_guide)
    
    dialog_defs = {
        0:  {"node": "chk", "state": "normal_off", "cx": 40, "cy": 120, "cw": 340, "ch": 44, "ox": 40, "oy": 8, "w": 421, "h": 61,
             "label": "[chk] Không hỏi lại (Chưa chọn)", "text": "Không hiển thị lại thông báo này", "fsize": 18, "orig": (0, 476, 247, 31), "color": (50, 50, 50, 255), "glow": False},
        1:  {"node": "chk", "state": "normal_on",  "cx": 420, "cy": 120, "cw": 340, "ch": 44, "ox": 40, "oy": 8, "w": 421, "h": 61,
             "label": "[chk] Không hỏi lại (Đã chọn)",   "text": "Không hiển thị lại thông báo này", "fsize": 18, "orig": (0, 507, 247, 34), "color": (255, 255, 255, 255), "glow": True},
        2:  {"node": "no",  "state": "off",        "cx": 420, "cy": 25,  "cw": 150, "ch": 60, "ox": 14, "oy": 11, "w": 178, "h": 82,
             "label": "[no] KHÔNG - Normal",           "text": "KHÔNG", "fsize": 26, "orig": (247, 476, 85, 47), "color": (50, 50, 50, 255), "glow": False},
        3:  {"node": "no",  "state": "over",       "cx": 600, "cy": 20,  "cw": 170, "ch": 75, "ox": 4,  "oy": 3,  "w": 178, "h": 82,
             "label": "[no] KHÔNG - Hover",            "text": "KHÔNG", "fsize": 28, "orig": (341, 449, 124, 77), "color": (255, 255, 255, 255), "glow": True},
        19: {"node": "yes", "state": "off",        "cx": 40,  "cy": 25,  "cw": 150, "ch": 60, "ox": 19, "oy": 11, "w": 188, "h": 82,
             "label": "[yes] CÓ - Normal",             "text": "CÓ", "fsize": 26, "orig": (341, 526, 112, 47), "color": (50, 50, 50, 255), "glow": False},
        20: {"node": "yes", "state": "over",       "cx": 220, "cy": 20,  "cw": 170, "ch": 75, "ox": 9,  "oy": 3,  "w": 188, "h": 82,
             "label": "[yes] CÓ - Hover",              "text": "CÓ", "fsize": 28, "orig": (341, 372, 157, 77), "color": (255, 255, 255, 255), "glow": True},
    }
    
    prompts = [
        (4,  "askallremove1", "Bạn có chắc muốn xóa tất cả dữ liệu lưu?", (0, 169, 417, 34)),
        (5,  "askallremove2", "Dữ liệu đã xóa sẽ không thể phục hồi.",    (0, 0, 440, 34)),
        (6,  "askbackto",      "Quay về lựa chọn trước đó?",                (0, 102, 419, 34)),
        (7,  "askdelete",      "Bạn có muốn xóa bản lưu này không?",       (0, 338, 343, 34)),
        (8,  "askexit",        "Bạn có muốn thoát khỏi trò chơi?",          (0, 372, 341, 34)),
        (9,  "askinit",        "Khôi phục cài đặt mặc định cho trang này?", (0, 237, 402, 33)),
        (10, "askjump",        "Nhảy tới phân đoạn này?",                   (0, 68, 427, 34)),
        (11, "askload",        "Tải dữ liệu từ bản lưu này?",              (0, 541, 236, 33)),
        (12, "asknext",        "Đi tới lựa chọn kế tiếp?",                  (0, 34, 431, 34)),
        (13, "asknextscn",     "Chuyển sang phân đoạn tiếp theo?",          (0, 136, 418, 33)),
        (14, "askoverwrite",   "Ghi đè lên bản lưu này?",                  (0, 406, 340, 36)),
        (15, "askprevscn",     "Quay lại phân đoạn trước đó?",             (0, 203, 406, 34)),
        (16, "askqload",       "Tải bản lưu nhanh (Quick Load)?",          (0, 305, 353, 33)),
        (17, "askqsave",       "Lưu nhanh (Quick Save)?",                  (0, 270, 355, 35)),
        (18, "asktitle",       "Quay về màn hình chính (Title)?",          (0, 442, 332, 34))
    ]
    
    start_y = 190
    step_y = 74
    for idx, (s_idx, state_name, text_vn, orig_box) in enumerate(prompts):
        cy = start_y + idx * step_y
        dialog_defs[s_idx] = {
            "node": "texts", "state": state_name, "cx": 40, "cy": cy, "cw": 540, "ch": 50, "ox": 8, "oy": 33, "w": 556, "h": 116,
            "label": f"[texts] {state_name}", "text": text_vn, "fsize": 22, "orig": orig_box, "color": (45, 45, 45, 255), "glow": False
        }
        
    slice_updates = {}
    manifest = {"canvas_size": [CANVAS_W, CANVAS_H], "slices": {}}
    
    psd_btn_normal = []
    psd_btn_hover = []
    psd_prompts = []
    
    for s_idx, d in dialog_defs.items():
        cx, cy, cw, ch = d["cx"], d["cy"], d["cw"], d["ch"]
        slice_updates[s_idx] = {
            "cx": cx, "cy": cy, "cw": cw, "ch": ch, "ox": d["ox"], "oy": d["oy"], "w": d["w"], "h": d["h"],
            "node": d["node"], "state": d["state"]
        }
        manifest["slices"][f"slice_{s_idx}_{d['state']}"] = {
            "cx": cx, "cy": cy, "cw": cw, "ch": ch, "ox": d["ox"], "oy": d["oy"], "text": d["text"]
        }
        
        # Guide borders
        draw_guide.rectangle([cx, cy, cx + cw - 1, cy + ch - 1], outline=(255, 40, 40, 255), width=1)
        draw_guide.rectangle([cx + 6, cy + 4, cx + cw - 7, cy + ch - 5], outline=(0, 230, 80, 200), width=1)
        draw_guide.text((cx, cy - 14), f"{d['label']} ({cw}x{ch})", font=small_font, fill=(255, 230, 0, 255))
        
        # Reference patch
        ox1, oy1, ow, oh = d["orig"]
        patch = raw_img.crop((ox1, oy1, ox1 + ow, oy1 + oh))
        p_arr = np.array(patch)
        p_arr[:, :, 3] = (p_arr[:, :, 3] * 0.35).astype(np.uint8)
        p_dim = Image.fromarray(p_arr)
        rx = cx + (cw - ow) // 2
        ry = cy + (ch - oh) // 2
        atlas_guide.paste(p_dim, (rx, ry), p_dim)
        
        # Render base text
        img_txt = create_text_image(d["text"], cw, ch, d["fsize"], d["color"], glow=d["glow"])
        atlas_base.paste(img_txt, (cx, cy), img_txt)
        
        # For PSD layers
        lyr_obj = pil_to_pytoshop_layer(img_txt, d["label"], cx, cy)
        if d["node"] == "texts":
            psd_prompts.append(lyr_obj)
        elif d["glow"]:
            psd_btn_hover.append(lyr_obj)
        else:
            psd_btn_normal.append(lyr_obj)

    # Save outputs
    guide_path = OUTPUT_DIR / "dialog_atlas_guide.png"
    base_path = OUTPUT_DIR / "dialog_atlas_base.png"
    manifest_path = OUTPUT_DIR / "dialog_manifest.json"
    psd_path = OUTPUT_DIR / "dialog_template_guide.psd"
    
    atlas_guide.save(guide_path)
    atlas_base.save(base_path)
    with open(manifest_path, "w", encoding="utf-8") as f:
        json.dump(manifest, f, indent=2, ensure_ascii=False)
        
    wire_layer = pil_to_pytoshop_layer(atlas_guide, "Khung_Wireframe_Va_Nhan", 0, 0)
    grp_guide = nested_layers.Group(name="[HUONG_DAN_WIREFRAME] (TẮT MẮT KHI XUẤT PNG)", layers=[wire_layer], closed=False)
    grp_hover = nested_layers.Group(name="[HOVER_EFFECT] (Nút Khi Rê Chuột)", layers=psd_btn_hover, closed=True)
    grp_normal = nested_layers.Group(name="[NORMAL_BUTTONS] (Nút Bình Thường)", layers=psd_btn_normal, closed=True)
    grp_prompts = nested_layers.Group(name="[PROMPT_TEXTS] (15 Dòng Chữ Thông Báo)", layers=psd_prompts, closed=True)
    
    psd = nested_layers.nested_layers_to_psd(
        [grp_guide, grp_hover, grp_normal, grp_prompts],
        color_mode=3,
        size=(CANVAS_W, CANVAS_H),
        compression=0
    )
    with open(psd_path, "wb") as f:
        psd.write(f)
    print(f"[+] Đã tạo {psd_path.name}")
    
    # Sync PBD files (JP: 1998, EN: 1996)
    pbd_jp_json = DUMP_DIR / "entry_01998_57cd.json"
    pbd_jp_bin = ROOT_DIR / "extracted_data" / "data" / "entry_01998_57cd.bin"
    out_jp_bin = PATCH_PBD_DIR / "entry_01998.bin"
    sync_pbd_file(pbd_jp_json, pbd_jp_bin, slice_updates, out_jp_bin)
    
    pbd_en_json = DUMP_DIR / "entry_01996_57cb.json"
    pbd_en_bin = ROOT_DIR / "extracted_data" / "data" / "entry_01996_57cb.bin"
    out_en_bin = PATCH_PBD_DIR / "entry_01996.bin"
    sync_pbd_file(pbd_en_json, pbd_en_bin, slice_updates, out_en_bin)
    print(f"[+] Đã đồng bộ PBD Entry 1998 & 1996.")
    
    # Convert TLG
    tlg_orig = ROOT_DIR / "extracted_data" / "data" / "entry_01997_57cc.bin"
    tlg_out = TLG_MSGTOOL_DIR / "entry_01997_57cc.tlg"
    convert_png_to_tlg(tlg_orig, base_path, tlg_out)
    (PATCH_UI_DIR / "entry_01997.bin").write_bytes(tlg_out.read_bytes())
    print(f"[+] Đã chuyển TLG Entry 1997.")

# ======================================================================
# MODULE 2: BACKLOG (entry_01931_578a / PBD 1932 & 1930)
# ======================================================================
def build_backlog_module():
    print("\n------------------------------------------------------")
    print("[MODULE 2] Bắt đầu xử lý BACKLOG (entry_01931_578a)...")
    raw_img = Image.open(RAW_DIR / "entry_01931_578a.png").convert("RGBA")
    
    CANVAS_W = 460
    CANVAS_H = 380
    
    atlas_base = Image.new("RGBA", (CANVAS_W, CANVAS_H), (0, 0, 0, 0))
    atlas_guide = Image.new("RGBA", (CANVAS_W, CANVAS_H), (0, 0, 0, 0))
    draw_guide = ImageDraw.Draw(atlas_guide)
    
    backlog_defs = {
        0: {"node": "back", "state": "off",        "cx": 20,  "cy": 20,  "cw": 120, "ch": 95, "ox": 0, "oy": 8, "w": 93, "h": 112,
            "label": "[back] TRỞ LẠI - Normal",    "text": "TRỞ LẠI", "fsize": 20, "orig": (0, 0, 93, 105), "color": (50, 50, 50, 255), "glow": False},
        1: {"node": "back", "state": "on",         "cx": 160, "cy": 20,  "cw": 120, "ch": 95, "ox": 0, "oy": 8, "w": 93, "h": 112,
            "label": "[back] TRỞ LẠI - Active",    "text": "TRỞ LẠI", "fsize": 20, "orig": (93, 0, 93, 105), "color": (255, 255, 255, 255), "glow": True},
        2: {"node": "back", "state": "over",       "cx": 300, "cy": 20,  "cw": 120, "ch": 95, "ox": 0, "oy": 8, "w": 93, "h": 112,
            "label": "[back] TRỞ LẠI - Hover",     "text": "TRỞ LẠI", "fsize": 20, "orig": (186, 0, 93, 105), "color": (255, 255, 255, 255), "glow": True},
        
        3: {"node": "modechg", "state": "normal_off", "cx": 20,  "cy": 135, "cw": 120, "ch": 95, "ox": 0, "oy": 8, "w": 93, "h": 112,
            "label": "[mode] CHẾ ĐỘ 1 - Normal",      "text": "CHẾ ĐỘ", "fsize": 20, "orig": (0, 105, 93, 105), "color": (50, 50, 50, 255), "glow": False},
        4: {"node": "modechg", "state": "normal_on",  "cx": 160, "cy": 135, "cw": 120, "ch": 95, "ox": 0, "oy": 8, "w": 93, "h": 112,
            "label": "[mode] CHẾ ĐỘ 1 - Active",      "text": "CHẾ ĐỘ", "fsize": 20, "orig": (0, 210, 93, 105), "color": (255, 255, 255, 255), "glow": True},
        5: {"node": "modechg", "state": "on_off",     "cx": 300, "cy": 135, "cw": 120, "ch": 95, "ox": 0, "oy": 8, "w": 93, "h": 112,
            "label": "[mode] CHẾ ĐỘ 2 - Normal",      "text": "CHẾ ĐỘ", "fsize": 20, "orig": (93, 105, 93, 105), "color": (50, 50, 50, 255), "glow": False},
        
        6: {"node": "modechg", "state": "on_on",      "cx": 20,  "cy": 250, "cw": 120, "ch": 95, "ox": 0, "oy": 8, "w": 93, "h": 112,
            "label": "[mode] CHẾ ĐỘ 2 - Active",      "text": "CHẾ ĐỘ", "fsize": 20, "orig": (186, 105, 93, 105), "color": (255, 255, 255, 255), "glow": True},
        7: {"node": "modechg", "state": "over_off",   "cx": 160, "cy": 250, "cw": 120, "ch": 95, "ox": 0, "oy": 8, "w": 93, "h": 112,
            "label": "[mode] CHẾ ĐỘ 3 - Normal",      "text": "CHẾ ĐỘ", "fsize": 20, "orig": (93, 210, 93, 105), "color": (50, 50, 50, 255), "glow": False},
        8: {"node": "modechg", "state": "over_on",    "cx": 300, "cy": 250, "cw": 120, "ch": 95, "ox": 0, "oy": 8, "w": 93, "h": 112,
            "label": "[mode] CHẾ ĐỘ 3 - Hover",       "text": "CHẾ ĐỘ", "fsize": 20, "orig": (186, 210, 93, 105), "color": (255, 255, 255, 255), "glow": True},
    }
    
    slice_updates = {}
    manifest = {"canvas_size": [CANVAS_W, CANVAS_H], "slices": {}}
    psd_normal = []
    psd_hover = []
    
    for s_idx, d in backlog_defs.items():
        cx, cy, cw, ch = d["cx"], d["cy"], d["cw"], d["ch"]
        slice_updates[s_idx] = {
            "cx": cx, "cy": cy, "cw": cw, "ch": ch, "ox": d["ox"], "oy": d["oy"], "w": d["w"], "h": d["h"],
            "node": d["node"], "state": d["state"]
        }
        manifest["slices"][f"slice_{s_idx}_{d['state']}"] = {
            "cx": cx, "cy": cy, "cw": cw, "ch": ch, "ox": d["ox"], "oy": d["oy"], "text": d["text"]
        }
        
        draw_guide.rectangle([cx, cy, cx + cw - 1, cy + ch - 1], outline=(255, 40, 40, 255), width=1)
        draw_guide.rectangle([cx + 6, cy + 4, cx + cw - 7, cy + ch - 5], outline=(0, 230, 80, 200), width=1)
        draw_guide.text((cx, cy - 14), f"{d['label']} ({cw}x{ch})", font=small_font, fill=(255, 230, 0, 255))
        
        ox1, oy1, ow, oh = d["orig"]
        patch = raw_img.crop((ox1, oy1, ox1 + ow, oy1 + oh))
        p_arr = np.array(patch)
        p_arr[:, :, 3] = (p_arr[:, :, 3] * 0.35).astype(np.uint8)
        p_dim = Image.fromarray(p_arr)
        rx = cx + (cw - ow) // 2
        ry = cy + (ch - oh) // 2
        atlas_guide.paste(p_dim, (rx, ry), p_dim)
        
        img_txt = create_text_image(d["text"], cw, ch, d["fsize"], d["color"], glow=d["glow"])
        atlas_base.paste(img_txt, (cx, cy), img_txt)
        
        lyr_obj = pil_to_pytoshop_layer(img_txt, d["label"], cx, cy)
        if d["glow"]:
            psd_hover.append(lyr_obj)
        else:
            psd_normal.append(lyr_obj)

    guide_path = OUTPUT_DIR / "backlog_atlas_guide.png"
    base_path = OUTPUT_DIR / "backlog_atlas_base.png"
    manifest_path = OUTPUT_DIR / "backlog_manifest.json"
    psd_path = OUTPUT_DIR / "backlog_template_guide.psd"
    
    atlas_guide.save(guide_path)
    atlas_base.save(base_path)
    with open(manifest_path, "w", encoding="utf-8") as f:
        json.dump(manifest, f, indent=2, ensure_ascii=False)
        
    wire_layer = pil_to_pytoshop_layer(atlas_guide, "Khung_Wireframe_Va_Nhan", 0, 0)
    grp_guide = nested_layers.Group(name="[HUONG_DAN_WIREFRAME] (TẮT MẮT KHI XUẤT PNG)", layers=[wire_layer], closed=False)
    grp_hover = nested_layers.Group(name="[HOVER_EFFECT] (Nút Khi Rê Chuột / Active)", layers=psd_hover, closed=True)
    grp_normal = nested_layers.Group(name="[NORMAL_BUTTONS] (Nút Bình Thường)", layers=psd_normal, closed=True)
    
    psd = nested_layers.nested_layers_to_psd(
        [grp_guide, grp_hover, grp_normal],
        color_mode=3,
        size=(CANVAS_W, CANVAS_H),
        compression=0
    )
    with open(psd_path, "wb") as f:
        psd.write(f)
    print(f"[+] Đã tạo {psd_path.name}")
    
    # Sync PBD files (JP: 1932, EN: 1930)
    pbd_jp_json = DUMP_DIR / "entry_01932_578b.json"
    pbd_jp_bin = ROOT_DIR / "extracted_data" / "data" / "entry_01932_578b.bin"
    out_jp_bin = PATCH_PBD_DIR / "entry_01932.bin"
    sync_pbd_file(pbd_jp_json, pbd_jp_bin, slice_updates, out_jp_bin)
    
    pbd_en_json = DUMP_DIR / "entry_01930_5789.json"
    pbd_en_bin = ROOT_DIR / "extracted_data" / "data" / "entry_01930_5789.bin"
    out_en_bin = PATCH_PBD_DIR / "entry_01930.bin"
    sync_pbd_file(pbd_en_json, pbd_en_bin, slice_updates, out_en_bin)
    print(f"[+] Đã đồng bộ PBD Entry 1932 & 1930.")
    
    # Convert TLG
    tlg_orig = ROOT_DIR / "extracted_data" / "data" / "entry_01931_578a.bin"
    tlg_out = TLG_MSGTOOL_DIR / "entry_01931_578a.tlg"
    convert_png_to_tlg(tlg_orig, base_path, tlg_out)
    (PATCH_UI_DIR / "entry_01931.bin").write_bytes(tlg_out.read_bytes())
    print(f"[+] Đã chuyển TLG Entry 1931.")

# ======================================================================
# MODULE 3 & 4: FILE LOAD & SAVE (entry_02026_57e9 & entry_02037_57f4)
# ======================================================================
def build_file_module(mod_name, raw_entry, pbd_jp_id, pbd_en_id, title_vn):
    print("\n------------------------------------------------------")
    print(f"[MODULE] Bắt đầu xử lý {title_vn} ({raw_entry})...")
    raw_img = Image.open(RAW_DIR / f"{raw_entry}.png").convert("RGBA")
    
    CANVAS_W = 420
    CANVAS_H = 320
    
    atlas_base = Image.new("RGBA", (CANVAS_W, CANVAS_H), (0, 0, 0, 0))
    atlas_guide = Image.new("RGBA", (CANVAS_W, CANVAS_H), (0, 0, 0, 0))
    draw_guide = ImageDraw.Draw(atlas_guide)
    
    file_defs = {
        0: {"node": "alldel",      "state": "off",  "cx": 30,  "cy": 220, "cw": 150, "ch": 75, "ox": 0, "oy": 5, "w": 74, "h": 90,
            "label": "[alldel] XÓA TẤT CẢ - Normal", "text": "XÓA HẾT", "fsize": 20, "orig": (0, 0, 74, 84), "color": (50, 50, 50, 255), "glow": False},
        1: {"node": "alldel",      "state": "over", "cx": 220, "cy": 220, "cw": 160, "ch": 75, "ox": 0, "oy": 5, "w": 74, "h": 90,
            "label": "[alldel] XÓA TẤT CẢ - Hover",  "text": "XÓA HẾT", "fsize": 20, "orig": (0, 84, 74, 84), "color": (255, 255, 255, 255), "glow": True},
        2: {"node": "back",        "state": "off",  "cx": 30,  "cy": 20,  "cw": 150, "ch": 75, "ox": 0, "oy": 5, "w": 74, "h": 90,
            "label": "[back] TRỞ LẠI - Normal",      "text": "TRỞ LẠI", "fsize": 20, "orig": (74, 0, 74, 84), "color": (50, 50, 50, 255), "glow": False},
        3: {"node": "back",        "state": "over", "cx": 220, "cy": 20,  "cw": 160, "ch": 75, "ox": 0, "oy": 5, "w": 74, "h": 90,
            "label": "[back] TRỞ LẠI - Hover",       "text": "TRỞ LẠI", "fsize": 20, "orig": (148, 0, 74, 84), "color": (255, 255, 255, 255), "glow": True},
        4: {"node": "edit_remove", "state": "off",  "cx": 30,  "cy": 120, "cw": 150, "ch": 75, "ox": 0, "oy": 5, "w": 74, "h": 90,
            "label": "[remove] XÓA - Normal",        "text": "XÓA", "fsize": 24, "orig": (74, 84, 74, 84), "color": (50, 50, 50, 255), "glow": False},
        5: {"node": "edit_remove", "state": "over", "cx": 220, "cy": 120, "cw": 160, "ch": 75, "ox": 0, "oy": 5, "w": 74, "h": 90,
            "label": "[remove] XÓA - Hover",         "text": "XÓA", "fsize": 24, "orig": (148, 84, 74, 84), "color": (255, 255, 255, 255), "glow": True},
    }
    
    slice_updates = {}
    manifest = {"canvas_size": [CANVAS_W, CANVAS_H], "slices": {}}
    psd_normal = []
    psd_hover = []
    
    for s_idx, d in file_defs.items():
        cx, cy, cw, ch = d["cx"], d["cy"], d["cw"], d["ch"]
        slice_updates[s_idx] = {
            "cx": cx, "cy": cy, "cw": cw, "ch": ch, "ox": d["ox"], "oy": d["oy"], "w": d["w"], "h": d["h"],
            "node": d["node"], "state": d["state"]
        }
        manifest["slices"][f"slice_{s_idx}_{d['state']}"] = {
            "cx": cx, "cy": cy, "cw": cw, "ch": ch, "ox": d["ox"], "oy": d["oy"], "text": d["text"]
        }
        
        draw_guide.rectangle([cx, cy, cx + cw - 1, cy + ch - 1], outline=(255, 40, 40, 255), width=1)
        draw_guide.rectangle([cx + 6, cy + 4, cx + cw - 7, cy + ch - 5], outline=(0, 230, 80, 200), width=1)
        draw_guide.text((cx, cy - 14), f"{d['label']} ({cw}x{ch})", font=small_font, fill=(255, 230, 0, 255))
        
        ox1, oy1, ow, oh = d["orig"]
        patch = raw_img.crop((ox1, oy1, ox1 + ow, oy1 + oh))
        p_arr = np.array(patch)
        p_arr[:, :, 3] = (p_arr[:, :, 3] * 0.35).astype(np.uint8)
        p_dim = Image.fromarray(p_arr)
        rx = cx + (cw - ow) // 2
        ry = cy + (ch - oh) // 2
        atlas_guide.paste(p_dim, (rx, ry), p_dim)
        
        img_txt = create_text_image(d["text"], cw, ch, d["fsize"], d["color"], glow=d["glow"])
        atlas_base.paste(img_txt, (cx, cy), img_txt)
        
        lyr_obj = pil_to_pytoshop_layer(img_txt, d["label"], cx, cy)
        if d["glow"]:
            psd_hover.append(lyr_obj)
        else:
            psd_normal.append(lyr_obj)

    guide_path = OUTPUT_DIR / f"{mod_name}_atlas_guide.png"
    base_path = OUTPUT_DIR / f"{mod_name}_atlas_base.png"
    manifest_path = OUTPUT_DIR / f"{mod_name}_manifest.json"
    psd_path = OUTPUT_DIR / f"{mod_name}_template_guide.psd"
    
    atlas_guide.save(guide_path)
    atlas_base.save(base_path)
    with open(manifest_path, "w", encoding="utf-8") as f:
        json.dump(manifest, f, indent=2, ensure_ascii=False)
        
    wire_layer = pil_to_pytoshop_layer(atlas_guide, "Khung_Wireframe_Va_Nhan", 0, 0)
    grp_guide = nested_layers.Group(name="[HUONG_DAN_WIREFRAME] (TẮT MẮT KHI XUẤT PNG)", layers=[wire_layer], closed=False)
    grp_hover = nested_layers.Group(name="[HOVER_EFFECT] (Nút Khi Rê Chuột)", layers=psd_hover, closed=True)
    grp_normal = nested_layers.Group(name="[NORMAL_BUTTONS] (Nút Bình Thường)", layers=psd_normal, closed=True)
    
    psd = nested_layers.nested_layers_to_psd(
        [grp_guide, grp_hover, grp_normal],
        color_mode=3,
        size=(CANVAS_W, CANVAS_H),
        compression=0
    )
    with open(psd_path, "wb") as f:
        psd.write(f)
    print(f"[+] Đã tạo {psd_path.name}")
    
    # Sync PBD files
    pbd_jp_json = list(DUMP_DIR.glob(f"entry_{pbd_jp_id:05d}_*.json"))[0]
    pbd_jp_bin = list((ROOT_DIR / "extracted_data" / "data").glob(f"entry_{pbd_jp_id:05d}_*.bin"))[0]
    out_jp_bin = PATCH_PBD_DIR / f"entry_{pbd_jp_id:05d}.bin"
    sync_pbd_file(pbd_jp_json, pbd_jp_bin, slice_updates, out_jp_bin)
    
    pbd_en_json = list(DUMP_DIR.glob(f"entry_{pbd_en_id:05d}_*.json"))[0]
    pbd_en_bin = list((ROOT_DIR / "extracted_data" / "data").glob(f"entry_{pbd_en_id:05d}_*.bin"))[0]
    out_en_bin = PATCH_PBD_DIR / f"entry_{pbd_en_id:05d}.bin"
    sync_pbd_file(pbd_en_json, pbd_en_bin, slice_updates, out_en_bin)
    print(f"[+] Đã đồng bộ PBD Entry {pbd_jp_id} & {pbd_en_id}.")
    
    # Convert TLG
    raw_idx = int(raw_entry.split("_")[1])
    tlg_orig = list((ROOT_DIR / "extracted_data" / "data").glob(f"entry_{raw_idx:05d}_*.bin"))[0]
    tlg_out = TLG_MSGTOOL_DIR / f"{raw_entry}.tlg"
    convert_png_to_tlg(tlg_orig, base_path, tlg_out)
    (PATCH_UI_DIR / f"entry_{raw_idx:05d}.bin").write_bytes(tlg_out.read_bytes())
    print(f"[+] Đã chuyển TLG Entry {raw_idx}.")

# ======================================================================
# MODULE 5: CONFIG BASE (entry_01942_5795 / PBD 1943 & 1941)
# ======================================================================
def build_config_base_module():
    print("\n------------------------------------------------------")
    print("[MODULE 5] Bắt đầu xử lý CONFIG BASE (entry_01942_5795)...")
    raw_img = Image.open(RAW_DIR / "entry_01942_5795.png").convert("RGBA")
    
    CANVAS_W = 420
    CANVAS_H = 240
    
    atlas_base = Image.new("RGBA", (CANVAS_W, CANVAS_H), (0, 0, 0, 0))
    atlas_guide = Image.new("RGBA", (CANVAS_W, CANVAS_H), (0, 0, 0, 0))
    draw_guide = ImageDraw.Draw(atlas_guide)
    
    cfg_defs = {
        0: {"node": "back",  "state": "off",  "cx": 30,  "cy": 20,  "cw": 150, "ch": 75, "ox": 0, "oy": 5, "w": 74, "h": 90,
            "label": "[back] TRỞ LẠI - Normal", "text": "TRỞ LẠI", "fsize": 20, "orig": (0, 0, 74, 84), "color": (50, 50, 50, 255), "glow": False},
        1: {"node": "back",  "state": "over", "cx": 220, "cy": 20,  "cw": 160, "ch": 75, "ox": 0, "oy": 5, "w": 74, "h": 90,
            "label": "[back] TRỞ LẠI - Hover",  "text": "TRỞ LẠI", "fsize": 20, "orig": (74, 0, 74, 84), "color": (255, 255, 255, 255), "glow": True},
        2: {"node": "reset", "state": "off",  "cx": 30,  "cy": 120, "cw": 150, "ch": 75, "ox": 0, "oy": 5, "w": 74, "h": 90,
            "label": "[reset] MẶC ĐỊNH - Normal", "text": "MẶC ĐỊNH", "fsize": 18, "orig": (0, 84, 74, 84), "color": (50, 50, 50, 255), "glow": False},
        3: {"node": "reset", "state": "over", "cx": 220, "cy": 120, "cw": 160, "ch": 75, "ox": 0, "oy": 5, "w": 74, "h": 90,
            "label": "[reset] MẶC ĐỊNH - Hover",  "text": "MẶC ĐỊNH", "fsize": 18, "orig": (74, 84, 74, 84), "color": (255, 255, 255, 255), "glow": True},
    }
    
    slice_updates = {}
    manifest = {"canvas_size": [CANVAS_W, CANVAS_H], "slices": {}}
    psd_normal = []
    psd_hover = []
    
    for s_idx, d in cfg_defs.items():
        cx, cy, cw, ch = d["cx"], d["cy"], d["cw"], d["ch"]
        slice_updates[s_idx] = {
            "cx": cx, "cy": cy, "cw": cw, "ch": ch, "ox": d["ox"], "oy": d["oy"], "w": d["w"], "h": d["h"],
            "node": d["node"], "state": d["state"]
        }
        manifest["slices"][f"slice_{s_idx}_{d['state']}"] = {
            "cx": cx, "cy": cy, "cw": cw, "ch": ch, "ox": d["ox"], "oy": d["oy"], "text": d["text"]
        }
        
        draw_guide.rectangle([cx, cy, cx + cw - 1, cy + ch - 1], outline=(255, 40, 40, 255), width=1)
        draw_guide.rectangle([cx + 6, cy + 4, cx + cw - 7, cy + ch - 5], outline=(0, 230, 80, 200), width=1)
        draw_guide.text((cx, cy - 14), f"{d['label']} ({cw}x{ch})", font=small_font, fill=(255, 230, 0, 255))
        
        ox1, oy1, ow, oh = d["orig"]
        patch = raw_img.crop((ox1, oy1, ox1 + ow, oy1 + oh))
        p_arr = np.array(patch)
        p_arr[:, :, 3] = (p_arr[:, :, 3] * 0.35).astype(np.uint8)
        p_dim = Image.fromarray(p_arr)
        rx = cx + (cw - ow) // 2
        ry = cy + (ch - oh) // 2
        atlas_guide.paste(p_dim, (rx, ry), p_dim)
        
        img_txt = create_text_image(d["text"], cw, ch, d["fsize"], d["color"], glow=d["glow"])
        atlas_base.paste(img_txt, (cx, cy), img_txt)
        
        lyr_obj = pil_to_pytoshop_layer(img_txt, d["label"], cx, cy)
        if d["glow"]:
            psd_hover.append(lyr_obj)
        else:
            psd_normal.append(lyr_obj)

    guide_path = OUTPUT_DIR / "config_base_atlas_guide.png"
    base_path = OUTPUT_DIR / "config_base_atlas_base.png"
    manifest_path = OUTPUT_DIR / "config_base_manifest.json"
    psd_path = OUTPUT_DIR / "config_base_template_guide.psd"
    
    atlas_guide.save(guide_path)
    atlas_base.save(base_path)
    with open(manifest_path, "w", encoding="utf-8") as f:
        json.dump(manifest, f, indent=2, ensure_ascii=False)
        
    wire_layer = pil_to_pytoshop_layer(atlas_guide, "Khung_Wireframe_Va_Nhan", 0, 0)
    grp_guide = nested_layers.Group(name="[HUONG_DAN_WIREFRAME] (TẮT MẮT KHI XUẤT PNG)", layers=[wire_layer], closed=False)
    grp_hover = nested_layers.Group(name="[HOVER_EFFECT] (Nút Khi Rê Chuột)", layers=psd_hover, closed=True)
    grp_normal = nested_layers.Group(name="[NORMAL_BUTTONS] (Nút Bình Thường)", layers=psd_normal, closed=True)
    
    psd = nested_layers.nested_layers_to_psd(
        [grp_guide, grp_hover, grp_normal],
        color_mode=3,
        size=(CANVAS_W, CANVAS_H),
        compression=0
    )
    with open(psd_path, "wb") as f:
        psd.write(f)
    print(f"[+] Đã tạo {psd_path.name}")
    
    pbd_jp_json = DUMP_DIR / "entry_01943_5796.json"
    pbd_jp_bin = ROOT_DIR / "extracted_data" / "data" / "entry_01943_5796.bin"
    out_jp_bin = PATCH_PBD_DIR / "entry_01943.bin"
    sync_pbd_file(pbd_jp_json, pbd_jp_bin, slice_updates, out_jp_bin)
    
    pbd_en_json = DUMP_DIR / "entry_01941_5794.json"
    pbd_en_bin = ROOT_DIR / "extracted_data" / "data" / "entry_01941_5794.bin"
    out_en_bin = PATCH_PBD_DIR / "entry_01941.bin"
    sync_pbd_file(pbd_en_json, pbd_en_bin, slice_updates, out_en_bin)
    print(f"[+] Đã đồng bộ PBD Entry 1943 & 1941.")
    
    tlg_orig = ROOT_DIR / "extracted_data" / "data" / "entry_01942_5795.bin"
    tlg_out = TLG_MSGTOOL_DIR / "entry_01942_5795.tlg"
    convert_png_to_tlg(tlg_orig, base_path, tlg_out)
    (PATCH_UI_DIR / "entry_01942.bin").write_bytes(tlg_out.read_bytes())
    print(f"[+] Đã chuyển TLG Entry 1942.")

# ======================================================================
# MODULE 6: EXTRA GALLERY (entry_02006_57d5 / PBD 2007 & 2005)
# ======================================================================
def build_gallery_module():
    print("\n------------------------------------------------------")
    print("[MODULE 6] Bắt đầu xử lý EXTRA GALLERY (entry_02006_57d5)...")
    raw_img = Image.open(RAW_DIR / "entry_02006_57d5.png").convert("RGBA")
    
    CANVAS_W = 420
    CANVAS_H = 140
    
    atlas_base = Image.new("RGBA", (CANVAS_W, CANVAS_H), (0, 0, 0, 0))
    atlas_guide = Image.new("RGBA", (CANVAS_W, CANVAS_H), (0, 0, 0, 0))
    draw_guide = ImageDraw.Draw(atlas_guide)
    
    gal_defs = {
        0: {"node": "back", "state": "off",  "cx": 30,  "cy": 25, "cw": 150, "ch": 75, "ox": 0, "oy": 5, "w": 74, "h": 90,
            "label": "[back] TRỞ LẠI - Normal", "text": "TRỞ LẠI", "fsize": 20, "orig": (0, 0, 74, 84), "color": (50, 50, 50, 255), "glow": False},
        1: {"node": "back", "state": "over", "cx": 220, "cy": 25, "cw": 160, "ch": 75, "ox": 0, "oy": 5, "w": 74, "h": 90,
            "label": "[back] TRỞ LẠI - Hover",  "text": "TRỞ LẠI", "fsize": 20, "orig": (74, 0, 74, 84), "color": (255, 255, 255, 255), "glow": True},
    }
    
    slice_updates = {}
    manifest = {"canvas_size": [CANVAS_W, CANVAS_H], "slices": {}}
    psd_normal = []
    psd_hover = []
    
    for s_idx, d in gal_defs.items():
        cx, cy, cw, ch = d["cx"], d["cy"], d["cw"], d["ch"]
        slice_updates[s_idx] = {
            "cx": cx, "cy": cy, "cw": cw, "ch": ch, "ox": d["ox"], "oy": d["oy"], "w": d["w"], "h": d["h"],
            "node": d["node"], "state": d["state"]
        }
        manifest["slices"][f"slice_{s_idx}_{d['state']}"] = {
            "cx": cx, "cy": cy, "cw": cw, "ch": ch, "ox": d["ox"], "oy": d["oy"], "text": d["text"]
        }
        
        draw_guide.rectangle([cx, cy, cx + cw - 1, cy + ch - 1], outline=(255, 40, 40, 255), width=1)
        draw_guide.rectangle([cx + 6, cy + 4, cx + cw - 7, cy + ch - 5], outline=(0, 230, 80, 200), width=1)
        draw_guide.text((cx, cy - 14), f"{d['label']} ({cw}x{ch})", font=small_font, fill=(255, 230, 0, 255))
        
        ox1, oy1, ow, oh = d["orig"]
        patch = raw_img.crop((ox1, oy1, ox1 + ow, oy1 + oh))
        p_arr = np.array(patch)
        p_arr[:, :, 3] = (p_arr[:, :, 3] * 0.35).astype(np.uint8)
        p_dim = Image.fromarray(p_arr)
        rx = cx + (cw - ow) // 2
        ry = cy + (ch - oh) // 2
        atlas_guide.paste(p_dim, (rx, ry), p_dim)
        
        img_txt = create_text_image(d["text"], cw, ch, d["fsize"], d["color"], glow=d["glow"])
        atlas_base.paste(img_txt, (cx, cy), img_txt)
        
        lyr_obj = pil_to_pytoshop_layer(img_txt, d["label"], cx, cy)
        if d["glow"]:
            psd_hover.append(lyr_obj)
        else:
            psd_normal.append(lyr_obj)

    guide_path = OUTPUT_DIR / "gallery_atlas_guide.png"
    base_path = OUTPUT_DIR / "gallery_atlas_base.png"
    manifest_path = OUTPUT_DIR / "gallery_manifest.json"
    psd_path = OUTPUT_DIR / "gallery_template_guide.psd"
    
    atlas_guide.save(guide_path)
    atlas_base.save(base_path)
    with open(manifest_path, "w", encoding="utf-8") as f:
        json.dump(manifest, f, indent=2, ensure_ascii=False)
        
    wire_layer = pil_to_pytoshop_layer(atlas_guide, "Khung_Wireframe_Va_Nhan", 0, 0)
    grp_guide = nested_layers.Group(name="[HUONG_DAN_WIREFRAME] (TẮT MẮT KHI XUẤT PNG)", layers=[wire_layer], closed=False)
    grp_hover = nested_layers.Group(name="[HOVER_EFFECT] (Nút Khi Rê Chuột)", layers=psd_hover, closed=True)
    grp_normal = nested_layers.Group(name="[NORMAL_BUTTONS] (Nút Bình Thường)", layers=psd_normal, closed=True)
    
    psd = nested_layers.nested_layers_to_psd(
        [grp_guide, grp_hover, grp_normal],
        color_mode=3,
        size=(CANVAS_W, CANVAS_H),
        compression=0
    )
    with open(psd_path, "wb") as f:
        psd.write(f)
    print(f"[+] Đã tạo {psd_path.name}")
    
    pbd_jp_json = DUMP_DIR / "entry_02007_57d6.json"
    pbd_jp_bin = ROOT_DIR / "extracted_data" / "data" / "entry_02007_57d6.bin"
    out_jp_bin = PATCH_PBD_DIR / "entry_02007.bin"
    sync_pbd_file(pbd_jp_json, pbd_jp_bin, slice_updates, out_jp_bin)
    
    pbd_en_json = DUMP_DIR / "entry_02005_57d4.json"
    pbd_en_bin = ROOT_DIR / "extracted_data" / "data" / "entry_02005_57d4.bin"
    out_en_bin = PATCH_PBD_DIR / "entry_02005.bin"
    sync_pbd_file(pbd_en_json, pbd_en_bin, slice_updates, out_en_bin)
    print(f"[+] Đã đồng bộ PBD Entry 2007 & 2005.")
    
    tlg_orig = ROOT_DIR / "extracted_data" / "data" / "entry_02006_57d5.bin"
    tlg_out = TLG_MSGTOOL_DIR / "entry_02006_57d5.tlg"
    convert_png_to_tlg(tlg_orig, base_path, tlg_out)
    (PATCH_UI_DIR / "entry_02006.bin").write_bytes(tlg_out.read_bytes())
    print(f"[+] Đã chuyển TLG Entry 2006.")

# ======================================================================
# EXECUTION PIPELINE
# ======================================================================
build_backlog_module()
build_file_module("file_load", "entry_02026_57e9", 2027, 2025, "FILE LOAD")
build_file_module("file_save", "entry_02037_57f4", 2038, 2036, "FILE SAVE")
build_config_base_module()
build_gallery_module()

print("\n------------------------------------------------------")
print("[REPACK] Đang tiến hành đóng gói toàn diện vào data.xp3...")
res = subprocess.run([str(USER_PYTHON), str(REPACK_SCRIPT)], capture_output=True, text=True)
print(res.stdout)
if res.returncode != 0:
    print("[-] Lỗi đóng gói:", res.stderr)
else:
    print("\n[+] HOÀN TẤT THÀNH CÔNG TẤT CẢ CÁC MODULE UI VÀ ĐỒNG BỘ ENGINE!")
