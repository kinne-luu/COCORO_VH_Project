import json
from pathlib import Path

# Đọc file temp_help_conf.txt
src_txt = Path("temp_help_conf.txt")
raw_text = src_txt.read_text(encoding="utf-16le")

# Bản đồ dịch thuật chính xác 100% theo tài liệu người dùng
# Cặp (danh sách key nhận diện, text tiếng Việt mới)
TRANSLATIONS = [
    # 6 mục điều chỉnh mới
    (["autospeed"], "Cài đặt tốc độ chuyển câu khi ở chế độ Tự động"),
    (["readskip_on", "readskip_off", "readskip_help"], 'Chọn "On" để chỉ tự động tua nhanh qua các câu thoại đã đọc.'),
    (["bgmvolume", "bgmvolume_mute"], "Điều chỉnh âm lượng nhạc nền"),
    (["sevolume", "sevolume_mute"], "Điều chỉnh âm lượng hiệu ứng âm thanh"),
    (["cf_qsave_help"], "Hiển thị hộp thoại xác nhận trước khi Lưu nhanh"),
    (["cf_qload_help"], "Hiển thị hộp thoại xác nhận trước khi Tải nhanh"),

    # A. Tab Văn bản
    (["textspeed"], "Cài đặt tốc độ hiển thị chữ."),
    (["autovwait_help"], "Bật để chế độ Tự động chờ đọc hết giọng lồng tiếng mới chuyển sang câu tiếp theo."),
    (["automode_n", "autovwait_0"], "Bật để chế độ Tự động chờ đọc hết giọng lồng tiếng mới chuyển sang câu tiếp theo."),
    (["automode_v", "autovwait_1"], "Bật để chế độ Tự động chờ đọc hết giọng lồng tiếng mới chuyển sang câu tiếp theo (chỉ khi câu tiếp theo có lồng tiếng)."),
    (["automode_s", "autovwait_2"], "Chế độ Tự động sẽ chuyển câu theo tốc độ cài đặt mà không cần chờ hết giọng lồng tiếng."),
    (["ctrlskip_help"], "Bật/Tắt tính năng tua nhanh văn bản bằng phím Ctrl."),
    (["skipall", "skipread", "skipall_help"], "Bật/Tắt việc tiếp tục tua nhanh sau khi xuất hiện lựa chọn."),
    (["winopac"], "Điều chỉnh độ đậm / mờ của khung thoại trong game."),
    (["rtextcol_on", "rtextcol_off", "rtextcol_help"], "Đổi màu các câu thoại đã đọc để dễ nhận biết."),
    (["skipspeed"], "Điều chỉnh tốc độ tua văn bản trong chế độ Skip."),
    (["speedsample"], "Khung hiển thị mẫu văn bản. Nhấp vào đây để đổi phông chữ."),

    # B. Tab Hiển thị & Hệ thống
    (["window", "fullscreen"], "Chuyển đổi giữa chế độ toàn màn hình và cửa sổ."),
    (["gamespeed", "drawspeed_help"], "Cài đặt tốc độ hoạt họa hình ảnh trong game."),
    (["vspeedsync"], "Đồng bộ tốc độ hiển thị chữ theo giọng nói nhân vật."),
    (["voicespeed", "voicespeed_help"], "Điều chỉnh tốc độ phát âm thanh giọng nói nhân vật."),
    (["touchmode"], "Bật/Tắt chế độ điều khiển cảm ứng cho màn hình cảm ứng."),
    (["lang_ui", "uilang_prev", "uilang_next", "uilang"], "Thay đổi ngôn ngữ hiển thị giao diện."),
    (["lang_text", "textlang_prev", "textlang_next", "textlang"], "Thay đổi ngôn ngữ văn bản trong game."),
    (["lang_sub"], "Thay đổi ngôn ngữ phụ đề hiển thị kèm theo."),

    # C. Tab Âm thanh
    (["wavevolume", "wavevolume_mute"], "Điều chỉnh âm lượng tổng thể của trò chơi."),
    (["voicevolume", "voicevolume_mute"], "Điều chỉnh âm lượng giọng nói của nhân vật."),
    (["movievolume", "movievolume_mute"], "Điều chỉnh âm lượng phim và video cắt cảnh."),
    (["sysvovolume", "sysvo_help"], "Điều chỉnh âm lượng giọng đọc hệ thống."),
    (["sysvo", "sysvosel_help"], "Chọn nhân vật lồng tiếng hướng dẫn trong menu hệ thống."),
    (["voicecut_help"], "Bật/Tắt tự động ngắt giọng nói khi chuyển sang câu tiếp theo."),
    (["voicecut_on"], "Bật/Tắt tự động ngắt giọng nói khi chuyển sang câu tiếp theo.\tGiọng lồng tiếng sẽ bị ngắt ngay khi chuyển sang câu thoại tiếp theo."),
    (["voicecut_off"], "Bật/Tắt tự động ngắt giọng nói khi chuyển sang câu tiếp theo.\tGiọng lồng tiếng sẽ phát hết trước khi chuyển sang câu thoại tiếp theo."),
    (["downvolume"], "Tự động hạ nhỏ nhạc nền khi nhân vật đang nói chuyện."),
    (["bgmdown"], "Tự động hạ nhỏ nhạc nền khi nhân vật đang nói chuyện."),
    (["bgmdown_on", "bgmdown_off"], "Tự động hạ nhỏ nhạc nền khi nhân vật đang nói chuyện."),
    (["charea", "help_chvoice"], "Điều chỉnh âm lượng giọng nói riêng cho từng nhân vật."),

    # D. Tab Hộp thoại xác nhận
    (["cf_title_help"], "Hiển thị hộp thoại xác nhận trước khi quay về màn hình chính."),
    (["cf_exit_help"], "Hiển thị hộp thoại xác nhận trước khi thoát trò chơi."),
    (["cf_load_help"], "Hiển thị hộp thoại xác nhận trước khi tải tệp lưu (Load)."),
    (["cf_overwrite_help"], "Hiển thị hộp thoại xác nhận trước khi ghi đè tệp lưu."),
    (["cf_delete_help"], "Hiển thị hộp thoại xác nhận trước khi xóa tệp lưu."),
    (["cf_jump_help"], "Hiển thị hộp thoại xác nhận trước khi chuyển đến câu trong lịch sử."),
    (["cf_next_help"], "Hiển thị hộp thoại xác nhận trước khi nhảy tới lựa chọn tiếp theo."),
    (["cf_init_help"], "Hiển thị hộp thoại xác nhận trước khi khôi phục cài đặt gốc."),
    (["cf_allremove1_help"], "Hiển thị hộp thoại xác nhận trước khi xóa toàn bộ dữ liệu lưu."),

    # E. Các nút điều khiển chung
    (["init"], "Đưa tất cả các cài đặt trên trang này về giá trị mặc định."),
    (["back"], "Đóng menu Cài đặt và quay trở lại màn hình trước."),
]

lines = raw_text.splitlines()
out_lines = []
i = 0
modified_count = 0

while i < len(lines):
    line = lines[i]
    stripped = line.strip()
    
    # Kiểm tra xem đây có phải là dòng định nghĩa key không
    if not line.startswith("\t") and stripped and not stripped.startswith("#"):
        # Tách các key trên dòng (cách nhau bởi tab)
        keys_on_line = [k.strip() for k in stripped.split("\t") if k.strip()]
        
        # Tìm xem có trong TRANSLATIONS không
        matched_trans = None
        for rule_keys, new_vn in TRANSLATIONS:
            # Kiểm tra xem có key nào khớp không
            if any(rk in keys_on_line for rk in rule_keys):
                matched_trans = new_vn
                break
        
        out_lines.append(line)
        i += 1
        
        # Nếu có text ở dòng tiếp theo (bắt đầu bằng \t)
        if i < len(lines) and lines[i].startswith("\t"):
            if matched_trans:
                # Thay thế dòng text này bằng tiếng Việt
                out_lines.append(f"\t{matched_trans}")
                print(f"[MATCH] Keys: {keys_on_line} -> {matched_trans}")
                modified_count += 1
            else:
                out_lines.append(lines[i])
            i += 1
    else:
        out_lines.append(line)
        i += 1

new_text = "\n".join(out_lines) + "\n"
out_txt = Path("help_conf_viet_hoa.txt")
out_txt.write_text(new_text, encoding="utf-16le")
print(f"\n=> Đã cập nhật thành công {modified_count} mục vào {out_txt.name}!")
