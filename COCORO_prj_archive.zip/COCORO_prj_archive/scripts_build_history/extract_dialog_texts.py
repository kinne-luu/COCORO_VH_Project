from psd_tools import PSDImage

psd = PSDImage.open(r"D:\Workspace\Creative\2D\Projects\Photoshop\COCORO Prj\entry_01997_57cc.psd")
for lyr in psd:
    if lyr.is_group():
        print(f"Group: {lyr.name}")
        for i, sub in enumerate(lyr):
            print(f"   {i:2d}: '{sub.name}' bbox={sub.bbox}")
    else:
        print(f"Layer: '{lyr.name}' bbox={lyr.bbox}")
