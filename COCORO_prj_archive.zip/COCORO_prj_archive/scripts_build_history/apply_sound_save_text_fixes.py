# -*- coding: utf-8 -*-
"""
Script fix triệt để 3 vấn đề theo yêu cầu người dùng:
1. Xử lý sạch 100% mẩu icon lạ ở tab Âm thanh (Sound) bằng cách làm sạch atlas Sound và đồng bộ PBD Sound.
2. Khắc phục lỗi cắt chữ/đè nút góc dưới bên phải giao diện Save và Load (XÓA HẾT, XÓA, TRỞ LẠI) cho tất cả các file PBD (Save in-game, Save title, Load in-game, Load title cả EN và JP).
3. Điều chỉnh khoảng cách chữ ở mục Văn bản (Text) dịch ra xa hoa anh đào thêm ~14px (ox từ 68 lên 82).
"""

import sys
import json
import shutil
import subprocess
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont
import numpy as np

ROOT_DIR = Path(r"D:\Software\Antigravity\Project\Cocoro")
MSG_TOOL = ROOT_DIR / "tools" / "msg-tool" / "msg_tool.exe"
FRESH_DIR = ROOT_DIR / "orig_fresh"
EXT_DATA_DIR = ROOT_DIR / "extracted_data" / "data"
DUMP_DIR = ROOT_DIR / "temp_pbd_dumps"
PATCH_UI_DIR = ROOT_DIR / "COCORO_Patch_VietHoa" / "patch_data" / "ui"
PATCH_PBD_DIR = ROOT_DIR / "COCORO_Patch_VietHoa" / "patch_data" / "pbd"
TLG_MSGTOOL_DIR = ROOT_DIR / "tlg_msgtool"
EXPORT_DIR = Path(r"D:\Workspace\Creative\2D\Projects\Photoshop\COCORO Prj\wireframe_guide\02_Xuat_Anh_Atlas_PNG_Vao_Day")

FONT_PATH = Path(r"C:\Users\ADMIN\AppData\Local\Microsoft\Windows\Fonts\STIXTwoText-Bold.ttf")
if not FONT_PATH.exists():
    FONT_PATH = Path(r"C:\Windows\Fonts\timesbd.ttf")

LABEL_FONT = ImageFont.truetype(str(FONT_PATH), 32)
# Màu chữ chuẩn theo yêu cầu: #4a4a4a -> RGB (74, 74, 74)
TEXT_COLOR = (74, 74, 74, 255)

def clean_magenta(im):
    arr = np.array(im)
    if len(arr.shape) >= 3 and arr.shape[2] >= 3:
        mask = (arr[:, :, 0] > 180) & (arr[:, :, 1] < 50) & (arr[:, :, 2] > 180)
        arr[mask] = [0, 0, 0, 0]
    return Image.fromarray(arr)

def render_left_label(text, width=600, height=48, margin_left=5):
    img = Image.new("RGBA", (width, height), (0, 0, 0, 0))
    draw = ImageDraw.Draw(img)
    bb = draw.textbbox((0, 0), text, font=LABEL_FONT)
    th = bb[3] - bb[1]
    tx = margin_left
    ty = (height - th) // 2 - bb[1]
    draw.text((tx, ty), text, font=LABEL_FONT, fill=TEXT_COLOR)
    return img

print("=" * 70)
print("   BẮT ĐẦU ÁP DỤNG FIX SOUND, SAVE/LOAD BUTTONS VÀ TEXT MARGIN   ")
print("=" * 70)

# ======================================================================
# 1. FIX BUG 1: XỬ LÝ TRIỆT ĐỂ MẨU ICON LẠ Ở TAB ÂM THANH (SOUND)
# ======================================================================
print("\n[1/3] Xử lý tab Âm thanh (Sound - config_p3)...")

sound_labels = [
    ("bgm",      "Nhạc nền"),
    ("down",     "Chế độ Downmix"),
    ("movie",    "Âm lượng phim"),
    ("se",       "Hiệu ứng âm thanh"),
    ("sysvo",    "Giọng hệ thống"),
    ("voice",    "Lời thoại"),
    ("voicecut", "Ngắt giọng khi bấm qua"),
    ("wave",     "Âm lượng tổng")
]

# Tạo atlas Sound EN mới:
# Trong entry_01977 gốc: chỉ giữ lại cụm nút radio voicecut (tại x: 158..506, y: 0..330)
# Xóa sạch 100% tất cả các vùng nhãn cũ để không còn bất cứ mẩu icon nào
im_s_en_orig = clean_magenta(Image.open(FRESH_DIR / "entry_01977.png").convert("RGBA"))
draw_s_en = ImageDraw.Draw(im_s_en_orig)
draw_s_en.rectangle([0, 0, 158, 441], fill=(0, 0, 0, 0))
draw_s_en.rectangle([158, 280, 467, 441], fill=(0, 0, 0, 0))

canvas_s_en = Image.new("RGBA", (1100, 450), (0, 0, 0, 0))
canvas_s_en.paste(im_s_en_orig, (0, 0))
layout_s_en = {}
for idx, (k, text) in enumerate(sound_labels):
    nx, ny, nw, nh = 480, idx * 55, 600, 48
    lbl = render_left_label(text, width=nw, height=nh, margin_left=5)
    canvas_s_en.paste(lbl, (nx, ny), lbl)
    layout_s_en[k] = {"x": nx, "y": ny, "w": nw, "h": nh}

png_s_en = Path("temp_sound_en_fixed.png")
canvas_s_en.save(png_s_en)
tlg_s_en = TLG_MSGTOOL_DIR / "entry_01977.tlg"
subprocess.run([str(MSG_TOOL), "import", "-t", "kirikiri-tlg", str(FRESH_DIR / "entry_01977.bin"), str(png_s_en), str(tlg_s_en)], check=True)
shutil.copy2(tlg_s_en, PATCH_UI_DIR / "entry_01977.bin")
print("   + Đã tạo entry_01977.bin (Sound EN atlas) sạch 100%!")

# Sound JP
im_s_jp_orig = clean_magenta(Image.open(FRESH_DIR / "entry_01979.png").convert("RGBA"))
draw_s_jp = ImageDraw.Draw(im_s_jp_orig)
draw_s_jp.rectangle([0, 0, 360, 100], fill=(0, 0, 0, 0))
draw_s_jp.rectangle([280, 275, 506, 440], fill=(0, 0, 0, 0))

canvas_s_jp = Image.new("RGBA", (1150, 450), (0, 0, 0, 0))
canvas_s_jp.paste(im_s_jp_orig, (0, 0))
layout_s_jp = {}
for idx, (k, text) in enumerate(sound_labels):
    nx, ny, nw, nh = 520, idx * 55, 600, 48
    lbl = render_left_label(text, width=nw, height=nh, margin_left=5)
    canvas_s_jp.paste(lbl, (nx, ny), lbl)
    layout_s_jp[k] = {"x": nx, "y": ny, "w": nw, "h": nh}

png_s_jp = Path("temp_sound_jp_fixed.png")
canvas_s_jp.save(png_s_jp)
tlg_s_jp = TLG_MSGTOOL_DIR / "entry_01979.tlg"
subprocess.run([str(MSG_TOOL), "import", "-t", "kirikiri-tlg", str(FRESH_DIR / "entry_01979.bin"), str(png_s_jp), str(tlg_s_jp)], check=True)
shutil.copy2(tlg_s_jp, PATCH_UI_DIR / "entry_01979.bin")
print("   + Đã tạo entry_01979.bin (Sound JP atlas) sạch 100%!")

def patch_sound_pbd(json_in, bin_orig, bin_out, layout_dict, stg_name):
    with open(json_in, "r", encoding="utf-8") as f:
        pbd = json.load(f)
    def walk(node):
        if isinstance(node, dict):
            uiname = node.get("uiname", "")
            if uiname.startswith("head_"):
                if "uistates" not in node or not node["uistates"]:
                    node["uistates"] = {}
                st = node["uistates"]
                for k, d in layout_dict.items():
                    st[k] = {
                        "storage": stg_name,
                        "cx": d["x"], "cy": d["y"], "cw": d["w"], "ch": d["h"],
                        "w": d["w"], "h": d["h"], "ox": 80, "oy": 3, "cr": None
                    }
                if "line" not in st:
                    st["line"] = {
                        "storage": "config_page3__pack",
                        "cx": 0, "cy": 0, "cw": 70, "ch": 1622,
                        "w": 1622, "h": 70, "ox": 2, "oy": 0, "cr": 1
                    }
            for k, v in node.items():
                if k != "uistates": walk(v)
        elif isinstance(node, list):
            for it in node: walk(it)
    walk(pbd.get("result", {}))
    tmp_json = Path(f"temp_sync_{bin_out.name}.json")
    with open(tmp_json, "w", encoding="utf-8") as f:
        json.dump(pbd, f, indent=2, ensure_ascii=False)
    subprocess.run([str(MSG_TOOL), "import", "-t", "kirikiri-tjs-ns0", str(bin_orig), str(tmp_json), str(bin_out)], check=True)

patch_sound_pbd(FRESH_DIR / "entry_01978.json", FRESH_DIR / "entry_01978.bin", PATCH_PBD_DIR / "entry_01978.bin", layout_s_en, "config_page3_en__pack")
patch_sound_pbd(FRESH_DIR / "entry_01980.json", FRESH_DIR / "entry_01980.bin", PATCH_PBD_DIR / "entry_01980.bin", layout_s_jp, "config_page3_jp__pack")
title_s_en_json = list(DUMP_DIR.glob("entry_02096*.json"))[0]
title_s_en_bin  = list(EXT_DATA_DIR.glob("entry_02096*.bin"))[0]
patch_sound_pbd(title_s_en_json, title_s_en_bin, PATCH_PBD_DIR / "entry_02096.bin", layout_s_en, "config_page3_en__pack")
title_s_jp_json = list(DUMP_DIR.glob("entry_02098*.json"))[0]
title_s_jp_bin  = list(EXT_DATA_DIR.glob("entry_02098*.bin"))[0]
patch_sound_pbd(title_s_jp_json, title_s_jp_bin, PATCH_PBD_DIR / "entry_02098.bin", layout_s_jp, "config_page3_jp__pack")
cn_s_ig_json = list(DUMP_DIR.glob("entry_01976*.json"))[0]
cn_s_ig_bin  = list(EXT_DATA_DIR.glob("entry_01976*.bin"))[0]
patch_sound_pbd(cn_s_ig_json, cn_s_ig_bin, PATCH_PBD_DIR / "entry_01976.bin", layout_s_en, "config_page3_en__pack")
cn_s_tt_json = list(DUMP_DIR.glob("entry_02095*.json"))[0]
cn_s_tt_bin  = list(EXT_DATA_DIR.glob("entry_02095*.bin"))[0]
patch_sound_pbd(cn_s_tt_json, cn_s_tt_bin, PATCH_PBD_DIR / "entry_02095.bin", layout_s_en, "config_page3_en__pack")
print("   + Đã đồng bộ toàn bộ Sound PBD (1976, 1978, 1980, 2095, 2096, 2098)!")

# ======================================================================
# 2. FIX BUG 2: SỬA KÍCH THƯỚC VÀ HIỂN THỊ NÚT Ở GIAO DIỆN SAVE VÀ LOAD
# ======================================================================
print("\n[2/3] Sửa hiển thị các nút điều khiển Save / Load (XÓA HẾT, XÓA, TRỞ LẠI)...")

def patch_file_buttons_pbd(json_in, bin_orig, bin_out):
    with open(json_in, "r", encoding="utf-8") as f:
        pbd = json.load(f)
    res = pbd.get("result", {})
    
    # 1. edit_remove (XÓA)
    # Text bbox trong template guide: (51, 27, 98, 47) -> width text = 47px
    if "edit_remove" in res:
        node = res["edit_remove"]
        node["x"] = 1520
        node["y"] = 1006
        node["width"] = 110
        node["height"] = 90
        if "uistates" in node:
            st = node["uistates"]
            if "off" in st:
                st["off"].update({"cx": 50, "cy": 120, "cw": 110, "ch": 75, "w": 110, "h": 75, "ox": 0, "oy": 5})
            if "over" in st:
                st["over"].update({"cx": 240, "cy": 120, "cw": 110, "ch": 75, "w": 110, "h": 75, "ox": 0, "oy": 5})
                
    # 2. alldel (XÓA HẾT)
    # Text bbox trong template guide: (25, 25, 125, 46) -> width text = 100px
    if "alldel" in res:
        node = res["alldel"]
        node["x"] = 1650
        node["y"] = 1006
        node["width"] = 130
        node["height"] = 90
        if "uistates" in node:
            st = node["uistates"]
            if "off" in st:
                st["off"].update({"cx": 40, "cy": 220, "cw": 130, "ch": 75, "w": 130, "h": 75, "ox": 0, "oy": 5})
            if "over" in st:
                st["over"].update({"cx": 230, "cy": 220, "cw": 130, "ch": 75, "w": 130, "h": 75, "ox": 0, "oy": 5})
                
    # 3. back (TRỞ LẠI)
    # Text bbox trong template guide: (31, 23, 118, 47) -> width text = 87px
    if "back" in res:
        node = res["back"]
        node["x"] = 1795
        node["y"] = 1006
        node["width"] = 115
        node["height"] = 90
        if "uistates" in node:
            st = node["uistates"]
            if "off" in st:
                st["off"].update({"cx": 45, "cy": 20, "cw": 115, "ch": 75, "w": 115, "h": 75, "ox": 0, "oy": 5})
            if "over" in st:
                st["over"].update({"cx": 235, "cy": 20, "cw": 115, "ch": 75, "w": 115, "h": 75, "ox": 0, "oy": 5})

    tmp_json = Path(f"temp_sync_{bin_out.name}.json")
    with open(tmp_json, "w", encoding="utf-8") as f:
        json.dump(pbd, f, indent=2, ensure_ascii=False)
    subprocess.run([str(MSG_TOOL), "import", "-t", "kirikiri-tjs-ns0", str(bin_orig), str(tmp_json), str(bin_out)], check=True)

# Patch Save PBDs
# Save in-game EN
save_ig_json = DUMP_DIR / "entry_02036_57f3.json"
save_ig_bin  = EXT_DATA_DIR / "entry_02036_57f3.bin"
patch_file_buttons_pbd(save_ig_json, save_ig_bin, PATCH_PBD_DIR / "entry_02036.bin")

# Save in-game JP
save_ig_jp_json = DUMP_DIR / "entry_02038_57f5.json"
save_ig_jp_bin  = EXT_DATA_DIR / "entry_02038_57f5.bin"
if save_ig_jp_json.exists() and save_ig_jp_bin.exists():
    patch_file_buttons_pbd(save_ig_jp_json, save_ig_jp_bin, PATCH_PBD_DIR / "entry_02038.bin")

# Save title EN
save_tt_json = DUMP_DIR / "entry_02136_5857.json"
save_tt_bin  = EXT_DATA_DIR / "entry_02136_5857.bin"
if not save_tt_json.exists():
    save_tt_json = save_ig_json
patch_file_buttons_pbd(save_tt_json, save_tt_bin, PATCH_PBD_DIR / "entry_02136.bin")

# Save title JP
save_tt_jp_json = DUMP_DIR / "entry_02138_5859.json"
save_tt_jp_bin  = EXT_DATA_DIR / "entry_02138_5859.bin"
if save_tt_jp_json.exists() and save_tt_jp_bin.exists():
    patch_file_buttons_pbd(save_tt_jp_json, save_tt_jp_bin, PATCH_PBD_DIR / "entry_02138.bin")
print("   + Đã đồng bộ Save PBD (02036, 02038, 02136, 02138)!")

# Patch Load PBDs
# Load in-game EN
load_ig_json = DUMP_DIR / "entry_02025_57e8.json"
load_ig_bin  = EXT_DATA_DIR / "entry_02025_57e8.bin"
patch_file_buttons_pbd(load_ig_json, load_ig_bin, PATCH_PBD_DIR / "entry_02025.bin")

# Load in-game JP
load_ig_jp_json = DUMP_DIR / "entry_02027_57ea.json"
load_ig_jp_bin  = EXT_DATA_DIR / "entry_02027_57ea.bin"
if load_ig_jp_json.exists() and load_ig_jp_bin.exists():
    patch_file_buttons_pbd(load_ig_jp_json, load_ig_jp_bin, PATCH_PBD_DIR / "entry_02027.bin")

# Load title EN (entry 02130)
load_tt_json = DUMP_DIR / "entry_02130_5851.json"
load_tt_bin  = EXT_DATA_DIR / "entry_02130_5851.bin"
if load_tt_json.exists() and load_tt_bin.exists():
    patch_file_buttons_pbd(load_tt_json, load_tt_bin, PATCH_PBD_DIR / "entry_02130.bin")

# Load title JP (entry 02132)
if (DUMP_DIR / "entry_02132_5853.json").exists() and (EXT_DATA_DIR / "entry_02132_5853.bin").exists():
    patch_file_buttons_pbd(DUMP_DIR / "entry_02132_5853.json", EXT_DATA_DIR / "entry_02132_5853.bin", PATCH_PBD_DIR / "entry_02132.bin")
print("   + Đã đồng bộ Load PBD (02025, 02027, 02130, 02132)!")

# ======================================================================
# 3. FIX BUG 3: ĐIỀU CHỈNH KHOẢNG CÁCH CHỮ Ở MỤC VĂN BẢN (TEXT)
# ======================================================================
print("\n[3/3] Điều chỉnh khoảng cách chữ ở mục Văn bản (Text - config_p1)...")

text_labels = [
    ("autospeed",  "Tốc độ tự đọc"),
    ("autovwait",  "Chờ hết giọng khi tự đọc"),
    ("ctrlskip",   "Tua nhanh bằng phím Ctrl"),
    ("readskip",   "Bỏ qua thoại đã đọc"),
    ("rtextcol",   "Đổi màu chữ đã đọc"),
    ("skipall",    "Bỏ qua toàn bộ thoại"),
    ("textspeed",  "Tốc độ hiển thị chữ"),
    ("winopac",    "Độ mờ khung thoại")
]

im_t_orig = clean_magenta(Image.open(FRESH_DIR / "entry_01961.png").convert("RGBA"))
canvas_t = Image.new("RGBA", (1500, 800), (0, 0, 0, 0))
canvas_t.paste(im_t_orig, (0, 0))
layout_t = {}
for idx, (k, text) in enumerate(text_labels):
    nx, ny, nw, nh = 860, idx * 55, 600, 48
    lbl = render_left_label(text, width=nw, height=nh, margin_left=5)
    canvas_t.paste(lbl, (nx, ny), lbl)
    layout_t[k] = {"x": nx, "y": ny, "w": nw, "h": nh}

png_t = Path("temp_text_fixed.png")
canvas_t.save(png_t)
tlg_t = TLG_MSGTOOL_DIR / "entry_01961.tlg"
subprocess.run([str(MSG_TOOL), "import", "-t", "kirikiri-tlg", str(FRESH_DIR / "entry_01961.bin"), str(png_t), str(tlg_t)], check=True)
shutil.copy2(tlg_t, PATCH_UI_DIR / "entry_01961.bin")

def patch_text_pbd(json_in, bin_orig, bin_out, layout_dict, stg_name):
    with open(json_in, "r", encoding="utf-8") as f:
        pbd = json.load(f)
    def walk(node):
        if isinstance(node, dict):
            uiname = node.get("uiname", "")
            if uiname.startswith("head_"):
                if "uistates" not in node or not node["uistates"]:
                    node["uistates"] = {}
                st = node["uistates"]
                for k, d in layout_dict.items():
                    # Tăng ox từ 68 lên 82 (dịch thêm 14px để cách đều hoa anh đào thoáng đẹp)
                    st[k] = {
                        "storage": stg_name,
                        "cx": d["x"], "cy": d["y"], "cw": d["w"], "ch": d["h"],
                        "w": d["w"], "h": d["h"], "ox": 82, "oy": 3, "cr": None
                    }
                if "line" not in st:
                    st["line"] = {
                        "storage": "config_page1__pack",
                        "cx": 0, "cy": 0, "cw": 1622, "ch": 70,
                        "w": 1622, "h": 70, "ox": 2, "oy": 7, "cr": None
                    }
            for k, v in node.items():
                if k != "uistates": walk(v)
        elif isinstance(node, list):
            for it in node: walk(it)
    walk(pbd.get("result", {}))
    tmp_json = Path(f"temp_sync_{bin_out.name}.json")
    with open(tmp_json, "w", encoding="utf-8") as f:
        json.dump(pbd, f, indent=2, ensure_ascii=False)
    subprocess.run([str(MSG_TOOL), "import", "-t", "kirikiri-tjs-ns0", str(bin_orig), str(tmp_json), str(bin_out)], check=True)

patch_text_pbd(FRESH_DIR / "entry_01960.json", FRESH_DIR / "entry_01960.bin", PATCH_PBD_DIR / "entry_01960.bin", layout_t, "config_page1_en__pack")
patch_text_pbd(FRESH_DIR / "entry_01962.json", FRESH_DIR / "entry_01962.bin", PATCH_PBD_DIR / "entry_01962.bin", layout_t, "config_page1_jp__pack")
title_t_en_json = list(DUMP_DIR.glob("entry_02080*.json"))[0]
title_t_en_bin  = list(EXT_DATA_DIR.glob("entry_02080*.bin"))[0]
patch_text_pbd(title_t_en_json, title_t_en_bin, PATCH_PBD_DIR / "entry_02080.bin", layout_t, "config_page1_en__pack")
title_t_jp_json = list(DUMP_DIR.glob("entry_02082*.json"))[0]
title_t_jp_bin  = list(EXT_DATA_DIR.glob("entry_02082*.bin"))[0]
patch_text_pbd(title_t_jp_json, title_t_jp_bin, PATCH_PBD_DIR / "entry_02082.bin", layout_t, "config_page1_jp__pack")
cn_t_ig_json = list(DUMP_DIR.glob("entry_01958*.json"))[0]
cn_t_ig_bin  = list(EXT_DATA_DIR.glob("entry_01958*.bin"))[0]
patch_text_pbd(cn_t_ig_json, cn_t_ig_bin, PATCH_PBD_DIR / "entry_01958.bin", layout_t, "config_page1_en__pack")
cn_t_tt_json = list(DUMP_DIR.glob("entry_02078*.json"))[0]
cn_t_tt_bin  = list(EXT_DATA_DIR.glob("entry_02078*.bin"))[0]
patch_text_pbd(cn_t_tt_json, cn_t_tt_bin, PATCH_PBD_DIR / "entry_02078.bin", layout_t, "config_page1_en__pack")
print("   + Đã đồng bộ toàn bộ Text PBD với khoảng cách ox=82 mới!")

print("\n" + "=" * 70)
print("   HOÀN TẤT TOÀN BỘ CÁC BƯỚC CẬP NHẬT GIAO DIỆN CHUẨN XÁC!   ")
print("=" * 70)
