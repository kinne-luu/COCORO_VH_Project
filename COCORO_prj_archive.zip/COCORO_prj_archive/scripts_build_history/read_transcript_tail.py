import json
from pathlib import Path

log_p = Path(r"C:\Users\ADMIN\.gemini\antigravity\brain\6b02dd57-4279-4cd4-9c69-1295e15a34fe\.system_generated\logs\transcript.jsonl")
if log_p.exists():
    with open(log_p, "r", encoding="utf-8") as f:
        lines = f.readlines()
    print("Total transcript lines:", len(lines))
    for l in lines[-15:]:
        obj = json.loads(l)
        print(f"step_index={obj.get('step_index')}, type={obj.get('type')}, status={obj.get('status')}")
        calls = obj.get("tool_calls", [])
        for c in calls:
            print("   call:", c.get("tool_name"), c.get("arguments", {}).get("CommandLine", "")[:60])
