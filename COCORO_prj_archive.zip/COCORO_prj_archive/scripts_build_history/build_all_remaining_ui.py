# -*- coding: utf-8 -*-
"""
COCORO - Universal Generator for All Remaining UI Modules & Engine Synchronization
Modules:
1. Config Page 0: Màn hình / Display (entry_01952_579f / PBD 1953 & 1951) - 27 slices
2. Config Page 1: Văn bản / Text (entry_01961_57a8 / PBD 1962 & 1960) - 35 slices
3. Config Page 2: Hộp thoại / Window (entry_01970_57b1 / PBD 1971 & 1969) - 31 slices
4. Config Page 3: Âm thanh / Sound (entry_01979_57ba / PBD 1980 & 1978) - 14 slices
5. Config Page 4: Giọng nói / Voice (entry_01988_57c3 / PBD 1989 & 1987) - 15 slices
6. Game Side Menu (entry_02055_5806 / PBD 2053 & 2056) - 42 slices
"""

import sys
import json
import subprocess
from pathlib import Path
import numpy as np
from PIL import Image, ImageDraw, ImageFont
import pytoshop
from pytoshop.user import nested_layers

ROOT_DIR = Path(r"D:\Software\Antigravity\Project\Cocoro")
OUTPUT_DIR = Path(r"D:\Workspace\Creative\2D\Projects\Photoshop\COCORO Prj\wireframe_guide")
RAW_DIR = ROOT_DIR / "image" / "UI_Raw"
DA_SUA_DIR = ROOT_DIR / "image" / "UI_Da_Sua"
DUMP_DIR = ROOT_DIR / "temp_pbd_dumps"
MSG_TOOL = ROOT_DIR / "tools" / "msg-tool" / "msg_tool.exe"
REPACK_SCRIPT = ROOT_DIR / "repack_viet_hoa_full.py"
USER_PYTHON = Path(r"C:\Users\ADMIN\AppData\Local\Python\bin\python.exe")
PATCH_PBD_DIR = ROOT_DIR / "COCORO_Patch_VietHoa" / "patch_data" / "pbd"
PATCH_UI_DIR = ROOT_DIR / "COCORO_Patch_VietHoa" / "patch_data" / "ui"
TLG_MSGTOOL_DIR = ROOT_DIR / "tlg_msgtool"

PATCH_PBD_DIR.mkdir(parents=True, exist_ok=True)
PATCH_UI_DIR.mkdir(parents=True, exist_ok=True)
TLG_MSGTOOL_DIR.mkdir(parents=True, exist_ok=True)
OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

# Font for wireframe labels
font_bold = Path(r"C:\Windows\Fonts\STIXTwoText-Bold.ttf")
if not font_bold.exists():
    font_bold = Path(r"C:\Windows\Fonts\timesbd.ttf")
small_font = ImageFont.truetype(str(font_bold), 11)

def pil_to_pytoshop_layer(pil_img, name, left, top):
    arr = np.array(pil_img)
    h, w = arr.shape[:2]
    return nested_layers.Image(
        name=name,
        top=top,
        left=left,
        bottom=top + h,
        right=left + w,
        channels={
            0: arr[:, :, 0],
            1: arr[:, :, 1],
            2: arr[:, :, 2],
            -1: arr[:, :, 3]
        }
    )

def sync_pbd(pbd_json_path, pbd_bin_path, updates_by_node_state, out_pbd_bin):
    with open(pbd_json_path, "r", encoding="utf-8") as f:
        pbd = json.load(f)
    
    packlist = pbd.get("packlist", [])
    result = pbd.get("result", {})
    
    for (node_name, state_name), u in updates_by_node_state.items():
        if node_name in result and isinstance(result[node_name], dict):
            nd = result[node_name]
            states = nd.get("uistates", {})
            if state_name in states and isinstance(states[state_name], dict):
                st = states[state_name]
                old_cx, old_cy = st.get("cx"), st.get("cy")
                old_cw, old_ch = st.get("cw"), st.get("ch")
                
                # Update uistates
                st["cx"] = u["cx"]
                st["cy"] = u["cy"]
                st["cw"] = u["cw"]
                st["ch"] = u["ch"]
                if "ox" in u and u["ox"] is not None:
                    st["ox"] = u["ox"]
                if "oy" in u and u["oy"] is not None:
                    st["oy"] = u["oy"]
                if "w" in u and u["w"] is not None:
                    st["w"] = u["w"]
                if "h" in u and u["h"] is not None:
                    st["h"] = u["h"]
                
                # Find in packlist by old coordinates
                if old_cx is not None:
                    for s in packlist:
                        if s and s[0] == old_cx and s[1] == old_cy and s[2] == old_cw and s[3] == old_ch:
                            s[0] = u["cx"]
                            s[1] = u["cy"]
                            s[2] = u["cw"]
                            s[3] = u["ch"]
                            if len(s) > 8 and isinstance(s[8], list) and len(s[8]) >= 6:
                                if "ox" in u and u["ox"] is not None:
                                    s[8][4] = u["ox"]
                                if "oy" in u and u["oy"] is not None:
                                    s[8][5] = u["oy"]
                                if "w" in u and u["w"] is not None:
                                    s[8][2] = u["w"]
                                if "h" in u and u["h"] is not None:
                                    s[8][3] = u["h"]
                            break
                            
            # Check alias 'on' if state is 'over'
            if state_name == "over" and "on" in states and isinstance(states["on"], dict):
                st_on = states["on"]
                if state_name in states and isinstance(states[state_name], dict):
                    if st_on.get("storage") == states[state_name].get("storage"):
                        st_on["cx"] = u["cx"]
                        st_on["cy"] = u["cy"]
                        st_on["cw"] = u["cw"]
                        st_on["ch"] = u["ch"]
                        if "ox" in u and u["ox"] is not None:
                            st_on["ox"] = u["ox"]
                        if "oy" in u and u["oy"] is not None:
                            st_on["oy"] = u["oy"]
                        
    temp_json = DUMP_DIR / f"{pbd_json_path.stem}_synced.json"
    with open(temp_json, "w", encoding="utf-8") as f:
        json.dump(pbd, f, indent=2, ensure_ascii=False)
        
    cmd = [str(MSG_TOOL), "import", "-t", "kirikiri-tjs-ns0", str(pbd_bin_path), str(temp_json), str(out_pbd_bin)]
    res = subprocess.run(cmd, capture_output=True, text=True)
    assert res.returncode == 0, f"Lỗi biên dịch PBD {out_pbd_bin.name}: {res.stderr}"

def convert_png_to_tlg(orig_bin, in_png, out_tlg):
    cmd = [str(MSG_TOOL), "import", "-t", "kirikiri-tlg", str(orig_bin), str(in_png), str(out_tlg)]
    res = subprocess.run(cmd, capture_output=True, text=True)
    assert res.returncode == 0, f"Lỗi chuyển TLG {out_tlg.name}: {res.stderr}"

def build_universal_ui_module(tag_name, raw_img_stem, jp_pbd_idx, en_pbd_idx, pad_w=40, pad_h=16):
    print("\n------------------------------------------------------")
    print(f"[*] Bắt đầu xử lý module: {tag_name.upper()} ({raw_img_stem} / PBD {jp_pbd_idx} & {en_pbd_idx})...")
    
    raw_path = RAW_DIR / f"{raw_img_stem}.png"
    da_sua_path = DA_SUA_DIR / f"{raw_img_stem}.png"
    
    raw_img = Image.open(raw_path).convert("RGBA")
    mod_img = Image.open(da_sua_path).convert("RGBA") if da_sua_path.exists() else raw_img
    
    jp_json_path = next(DUMP_DIR.glob(f"entry_{jp_pbd_idx:05d}*.json"))
    with open(jp_json_path, "r", encoding="utf-8") as f:
        jp_pbd = json.load(f)
        
    packlist = jp_pbd.get("packlist", [])
    result = jp_pbd.get("result", {})
    
    # 1. Map all slices
    mapping = {}
    for n_name, node in result.items():
        if not isinstance(node, dict): continue
        uistates = node.get("uistates", {})
        for s_name, s_val in uistates.items():
            if not isinstance(s_val, dict): continue
            cx = s_val.get("cx")
            if cx is not None:
                cy, cw, ch = s_val["cy"], s_val["cw"], s_val["ch"]
                for idx, p in enumerate(packlist):
                    if p[0] == cx and p[1] == cy and p[2] == cw and p[3] == ch:
                        mapping[idx] = {
                            "node": n_name, "state": s_name, "box": (cx, cy, cw, ch),
                            "w": node.get("width"), "h": node.get("height"),
                            "ox": s_val.get("ox"), "oy": s_val.get("oy")
                        }
                        
    print(f"   + Tìm thấy {len(mapping)} / {len(packlist)} lát cắt giao diện trong packlist.")
    
    # 2. Layout calculation
    CANVAS_W = 1240
    cur_x = 40
    cur_y = 40
    row_h = 0
    
    slice_layout = {}
    updates_by_node_state = {}
    
    for idx in sorted(mapping.keys()):
        m = mapping[idx]
        orig_cx, orig_cy, orig_cw, orig_ch = m["box"]
        new_cw = orig_cw + pad_w
        new_ch = orig_ch + pad_h
        
        if cur_x + new_cw + 40 > CANVAS_W:
            cur_x = 40
            cur_y += row_h + 24
            row_h = 0
            
        new_cx = cur_x
        new_cy = cur_y
        
        # Calculate new ox/oy to preserve pixel-perfect center
        orig_ox = m["ox"] if m["ox"] is not None else 0
        orig_oy = m["oy"] if m["oy"] is not None else 0
        new_ox = orig_ox - pad_w // 2
        new_oy = orig_oy - pad_h // 2
        
        orig_node_w = m["w"] if m["w"] is not None else orig_cw
        orig_node_h = m["h"] if m["h"] is not None else orig_ch
        new_node_w = max(orig_node_w, new_cw)
        new_node_h = max(orig_node_h, new_ch)
        
        slice_layout[idx] = {
            "node": m["node"], "state": m["state"],
            "orig_box": (orig_cx, orig_cy, orig_cw, orig_ch),
            "new_box": (new_cx, new_cy, new_cw, new_ch),
            "new_ox": new_ox, "new_oy": new_oy,
            "new_w": new_node_w, "new_h": new_node_h
        }
        
        updates_by_node_state[(m["node"], m["state"])] = {
            "cx": new_cx, "cy": new_cy, "cw": new_cw, "ch": new_ch,
            "ox": new_ox, "oy": new_oy,
            "w": new_node_w, "h": new_node_h
        }
        
        cur_x += new_cw + 24
        row_h = max(row_h, new_ch)
        
    CANVAS_H = cur_y + row_h + 40
    print(f"   + Kích thước Canvas mở rộng: {CANVAS_W} x {CANVAS_H}")
    
    # 3. Draw Atlas Guide and Atlas Base
    atlas_base = Image.new("RGBA", (CANVAS_W, CANVAS_H), (0, 0, 0, 0))
    atlas_guide = Image.new("RGBA", (CANVAS_W, CANVAS_H), (0, 0, 0, 0))
    draw_guide = ImageDraw.Draw(atlas_guide)
    
    psd_hover_layers = []
    psd_normal_layers = []
    psd_text_layers = []
    psd_raw_ref_layers = []
    
    manifest = {"canvas_size": [CANVAS_W, CANVAS_H], "slices": {}}
    
    for idx in sorted(slice_layout.keys()):
        item = slice_layout[idx]
        ncx, ncy, ncw, nch = item["new_box"]
        ocx, ocy, ocw, och = item["orig_box"]
        node_name = item["node"]
        state_name = item["state"]
        label_text = f"[{node_name}] {state_name} ({ncw}x{nch})"
        
        # Red box 1px: engine crop boundary
        draw_guide.rectangle([ncx, ncy, ncx + ncw - 1, ncy + nch - 1], outline=(255, 40, 40, 255), width=1)
        # Green box 1px: safe text boundary
        safe_x = ncx + pad_w // 2
        safe_y = ncy + pad_h // 2
        draw_guide.rectangle([safe_x, safe_y, safe_x + ocw - 1, safe_y + och - 1], outline=(0, 230, 80, 200), width=1)
        # Yellow label
        draw_guide.text((ncx, max(0, ncy - 13)), label_text, font=small_font, fill=(255, 230, 0, 255))
        
        # Crop raw patch (35% alpha reference)
        raw_patch = raw_img.crop((ocx, ocy, ocx + ocw, ocy + och))
        r_arr = np.array(raw_patch)
        r_arr[:, :, 3] = (r_arr[:, :, 3] * 0.35).astype(np.uint8)
        r_dim = Image.fromarray(r_arr)
        atlas_guide.paste(r_dim, (safe_x, safe_y), r_dim)
        
        # Crop translated patch from UI_Da_Sua (or raw if unchanged)
        mod_patch = mod_img.crop((ocx, ocy, ocx + ocw, ocy + och))
        atlas_base.paste(mod_patch, (safe_x, safe_y), mod_patch)
        
        # Add to PSD layer groups
        lyr_mod = pil_to_pytoshop_layer(mod_patch, label_text, safe_x, safe_y)
        lyr_raw = pil_to_pytoshop_layer(r_dim, f"[GỐC] {label_text}", safe_x, safe_y)
        psd_raw_ref_layers.append(lyr_raw)
        
        if state_name in ["over", "on", "active", "highlight"]:
            psd_hover_layers.append(lyr_mod)
        elif "head_" in node_name or "_lang" in node_name or "text" in node_name:
            psd_text_layers.append(lyr_mod)
        else:
            psd_normal_layers.append(lyr_mod)
            
        manifest["slices"][f"slice_{idx}_{node_name}_{state_name}"] = {
            "cx": ncx, "cy": ncy, "cw": ncw, "ch": nch,
            "ox": item["new_ox"], "oy": item["new_oy"],
            "orig_cx": ocx, "orig_cy": ocy, "orig_cw": ocw, "orig_ch": och
        }

    # 4. Save PNG guides and Manifest
    guide_path = OUTPUT_DIR / f"{tag_name}_atlas_guide.png"
    base_path = OUTPUT_DIR / f"{tag_name}_atlas_base.png"
    manifest_path = OUTPUT_DIR / f"{tag_name}_manifest.json"
    psd_path = OUTPUT_DIR / f"{tag_name}_template_guide.psd"
    
    atlas_guide.save(guide_path)
    atlas_base.save(base_path)
    with open(manifest_path, "w", encoding="utf-8") as f:
        json.dump(manifest, f, indent=2, ensure_ascii=False)
        
    # 5. Build PSD
    wire_layer = pil_to_pytoshop_layer(atlas_guide, "Khung_Wireframe_Va_Nhan", 0, 0)
    grp_guide = nested_layers.Group(name="[HUONG_DAN_WIREFRAME] (TẮT MẮT KHI XUẤT PNG)", layers=[wire_layer], closed=False)
    grp_hover = nested_layers.Group(name="[HOVER_EFFECT] (Nút Khi Rê Chuột / Active)", layers=psd_hover_layers, closed=True)
    grp_normal = nested_layers.Group(name="[NORMAL_BUTTONS] (Nút Bình Thường)", layers=psd_normal_layers, closed=True)
    grp_texts = nested_layers.Group(name="[TEXT_LABELS] (Tiêu Đề / Nhãn Văn Bản)", layers=psd_text_layers, closed=True)
    grp_refs = nested_layers.Group(name="[THAM_CHIEU_GOC] (Ảnh Mờ 35% Căn Hàng)", layers=psd_raw_ref_layers, closed=True)
    
    psd = nested_layers.nested_layers_to_psd(
        [grp_guide, grp_hover, grp_normal, grp_texts, grp_refs],
        color_mode=3,
        size=(CANVAS_W, CANVAS_H),
        compression=0
    )
    with open(psd_path, "wb") as f:
        psd.write(f)
    print(f"   [+] Đã tạo file khuôn Photoshop: {psd_path.name}")
    
    # 6. Synchronize PBDs
    # JP PBD
    jp_bin_path = next((ROOT_DIR / "extracted_data" / "data").glob(f"entry_{jp_pbd_idx:05d}*.bin"))
    out_jp_bin = PATCH_PBD_DIR / f"entry_{jp_pbd_idx:05d}.bin"
    sync_pbd(jp_json_path, jp_bin_path, updates_by_node_state, out_jp_bin)
    print(f"   [+] Đã đồng bộ PBD JP Entry {jp_pbd_idx}.")
    
    # EN PBD
    if en_pbd_idx is not None:
        en_json_cands = list(DUMP_DIR.glob(f"entry_{en_pbd_idx:05d}*.json"))
        if en_json_cands:
            en_json_path = en_json_cands[0]
            en_bin_path = next((ROOT_DIR / "extracted_data" / "data").glob(f"entry_{en_pbd_idx:05d}*.bin"))
            out_en_bin = PATCH_PBD_DIR / f"entry_{en_pbd_idx:05d}.bin"
            sync_pbd(en_json_path, en_bin_path, updates_by_node_state, out_en_bin)
            print(f"   [+] Đã đồng bộ PBD EN Entry {en_pbd_idx}.")

    # 7. Convert TLG5
    raw_entry_idx = int(raw_img_stem.split("_")[1])
    tlg_orig = next((ROOT_DIR / "extracted_data" / "data").glob(f"entry_{raw_entry_idx:05d}*.bin"))
    tlg_out = TLG_MSGTOOL_DIR / f"{raw_img_stem}.tlg"
    convert_png_to_tlg(tlg_orig, base_path, tlg_out)
    (PATCH_UI_DIR / f"entry_{raw_entry_idx:05d}.bin").write_bytes(tlg_out.read_bytes())
    print(f"   [+] Đã chuyển ảnh TLG5: entry_{raw_entry_idx:05d}.")

# ======================================================================
# MASTER PIPELINE FOR ALL REMAINING MODULES
# ======================================================================
modules_to_run = [
    ("config_p0", "entry_01952_579f", 1953, 1951),
    ("config_p1", "entry_01961_57a8", 1962, 1960),
    ("config_p2", "entry_01970_57b1", 1971, 1969),
    ("config_p3", "entry_01979_57ba", 1980, 1978),
    ("config_p4", "entry_01988_57c3", 1989, 1987),
    ("game_side", "entry_02055_5806", 2053, 2056)
]

for tag, raw_stem, jp_idx, en_idx in modules_to_run:
    build_universal_ui_module(tag, raw_stem, jp_idx, en_idx)

print("\n======================================================")
print("[REPACK] Đang tiến hành đóng gói toàn diện vào data.xp3...")
print("======================================================")
res = subprocess.run([str(USER_PYTHON), str(REPACK_SCRIPT)], capture_output=True, text=True)
print(res.stdout)
if res.returncode != 0:
    print("[-] Lỗi đóng gói:", res.stderr)
else:
    print("\n[+] HOÀN TẤT THÀNH CÔNG 100% TẤT CẢ CÁC MODULE UI VÀ ĐỒNG BỘ ENGINE HXV4!")
