import sys
sys.path.insert(0, r"E:\Extract Tools\cxdec-hxv4\src\common")
from xp3_inspect import DripProgram, read_archive, load_index, parse_hxv4_table, FilterRuntimeState
from pathlib import Path

game_xp3 = Path(r"E:\Games\COCORO.FIXED\game\data.xp3")
drip_path = Path(r"E:\Extract Tools\cxdec-hxv4\data\static_recover\drip_program_COCORO.exe.unpacked.json")
drip = DripProgram.load(drip_path)

info, entries, blob = read_archive(game_xp3)
_, _, _, index = load_index(blob)
descriptor, records = parse_hxv4_table(blob, index, entries, drip)
open_flag = descriptor.flags & 1

record_map = {r.xp3_entry_index: r for r in records}

with open(game_xp3, "rb") as f:
    for idx in [1977, 1978, 2096]:
        e = entries[idx]
        seg = e.segments[0]
        f.seek(seg.offset)
        raw_data = f.read(seg.archived_size)
        r = record_map.get(idx)
        cipher_data = bytearray(raw_data)
        if r is not None:
            seed = drip.build_filter_state(r.key, open_flag)
            state = FilterRuntimeState(seed)
            state.apply(cipher_data, 0)
        plain = bytes(cipher_data)
        out_p = Path(f"temp_xp3_live_{idx:05d}.bin")
        out_p.write_bytes(plain)
        print(f"Entry {idx}: size={len(plain)}, header={plain[:12]}")
