# -*- coding: utf-8 -*-
"""
COCORO - Build Complete Setting Pages Suite (Display, Text, Dialog, Sound)
Font: STIX Two Text Bold
Căn lề phải (Right-aligned), kích thước đồng nhất, không bị bé.
Đồng bộ 100% cả bản EN và JP trong tlg_msgtool và patch_data.
"""

import sys
import os
import json
import subprocess
from pathlib import Path
import numpy as np
from PIL import Image, ImageDraw, ImageFont
import pytoshop
from pytoshop.user import nested_layers

ROOT_DIR = Path(r"D:\Software\Antigravity\Project\Cocoro")
GUIDE_DIR = Path(r"D:\Workspace\Creative\2D\Projects\Photoshop\COCORO Prj\wireframe_guide")
MSG_TOOL = ROOT_DIR / "tools" / "msg-tool" / "msg_tool.exe"
REPACK_SCRIPT = ROOT_DIR / "repack_viet_hoa_full.py"
USER_PYTHON = Path(r"C:\Users\ADMIN\AppData\Local\Python\bin\python.exe")

PATCH_UI_DIR = ROOT_DIR / "COCORO_Patch_VietHoa" / "patch_data" / "ui"
PATCH_PBD_DIR = ROOT_DIR / "COCORO_Patch_VietHoa" / "patch_data" / "pbd"
TLG_MSGTOOL_DIR = ROOT_DIR / "tlg_msgtool"

GUIDE_DIR.mkdir(parents=True, exist_ok=True)
PATCH_UI_DIR.mkdir(parents=True, exist_ok=True)
PATCH_PBD_DIR.mkdir(parents=True, exist_ok=True)
TLG_MSGTOOL_DIR.mkdir(parents=True, exist_ok=True)

# Font STIX Two Text Bold
font_path = Path(r"C:\Users\ADMIN\AppData\Local\Microsoft\Windows\Fonts\STIXTwoText-Bold.ttf")
if not font_path.exists():
    font_path = Path(r"C:\Windows\Fonts\timesbd.ttf")
small_font = ImageFont.truetype(str(font_path), 11)
label_font = ImageFont.truetype(str(font_path), 32)
TEXT_COLOR = (50, 55, 60, 255)

def pil_to_pytoshop_layer(pil_img, name, left, top):
    arr = np.array(pil_img)
    h, w = arr.shape[:2]
    return nested_layers.Image(
        name=name,
        top=top,
        left=left,
        bottom=top + h,
        right=left + w,
        channels={
            0: arr[:, :, 0],
            1: arr[:, :, 1],
            2: arr[:, :, 2],
            -1: arr[:, :, 3]
        }
    )

def render_right_aligned_label(text, width=450, height=48, margin_right=15):
    img = Image.new("RGBA", (width, height), (0, 0, 0, 0))
    draw = ImageDraw.Draw(img)
    bb = draw.textbbox((0, 0), text, font=label_font)
    tw = bb[2] - bb[0]
    th = bb[3] - bb[1]
    tx = max(0, width - tw - margin_right)
    ty = (height - th) // 2 - bb[1]
    draw.text((tx, ty), text, font=label_font, fill=TEXT_COLOR)
    return img

print("=" * 65)
print("   COCORO - QUY TRÌNH TẠO BỘ KHUÔN TOÀN BỘ SETTING (STIX TWO TEXT)   ")
print("=" * 65)

# ======================================================================
# 1. BUILD SOUND (PAGE 3)
# ======================================================================
print("\n[1/4] Xây dựng trang Âm Thanh (Sound - config_p3)...")

RAW_EN_TLG_P3 = ROOT_DIR / "extracted_data" / "data" / "entry_01977_57b8.bin"
RAW_JP_TLG_P3 = ROOT_DIR / "extracted_data" / "data" / "entry_01979_57ba.bin"
PBD_EN_JSON_P3 = ROOT_DIR / "temp_pbd_dumps" / "entry_01978_57b9.json"
PBD_EN_BIN_P3 = ROOT_DIR / "extracted_data" / "data" / "entry_01978_57b9.bin"
PBD_JP_JSON_P3 = ROOT_DIR / "temp_pbd_dumps" / "entry_01980_57bb.json"
PBD_JP_BIN_P3 = ROOT_DIR / "extracted_data" / "data" / "entry_01980_57bb.bin"

clean_en_png_p3 = Path("temp_clean_en_sound.png")
subprocess.run([str(MSG_TOOL), "export", "-t", "kirikiri-tlg", str(RAW_EN_TLG_P3), str(clean_en_png_p3)], capture_output=True)
raw_en_img_p3 = Image.open(clean_en_png_p3).convert("RGBA")

CANVAS_P3_W = 900
CANVAS_P3_H = 650
atlas_base_p3 = Image.new("RGBA", (CANVAS_P3_W, CANVAS_P3_H), (0, 0, 0, 0))
atlas_guide_p3 = Image.new("RGBA", (CANVAS_P3_W, CANVAS_P3_H), (0, 0, 0, 0))
guide_draw_p3 = ImageDraw.Draw(atlas_guide_p3)

LAYOUT_P3 = {
    # Buttons
    9:  {"type": "btn", "x": 30, "y": 30,  "w": 282, "h": 66, "orig_y": 0,   "label": "BẬT (OFF)"},
    12: {"type": "btn", "x": 30, "y": 110, "w": 282, "h": 66, "orig_y": 198, "label": "BẬT (ON)"},
    13: {"type": "btn", "x": 30, "y": 190, "w": 282, "h": 66, "orig_y": 264, "label": "BẬT (HOVER)"},
    8:  {"type": "btn", "x": 30, "y": 290, "w": 282, "h": 66, "orig_y": 0,   "use_off_btn": True, "label": "TẮT (OFF)"},
    10: {"type": "btn", "x": 30, "y": 370, "w": 282, "h": 66, "orig_y": 66,  "label": "TẮT (ON)"},
    11: {"type": "btn", "x": 30, "y": 450, "w": 282, "h": 66, "orig_y": 132, "label": "TẮT (HOVER)"},
    # Labels
    7:  {"type": "label", "x": 360, "y": 30,  "w": 450, "h": 48, "text": "Âm lượng tổng",          "key": "wave",     "label": "Master Volume"},
    0:  {"type": "label", "x": 360, "y": 90,  "w": 450, "h": 48, "text": "Nhạc nền (BGM)",         "key": "bgm",      "label": "BGM Volume"},
    3:  {"type": "label", "x": 360, "y": 150, "w": 450, "h": 48, "text": "Hiệu ứng âm thanh (SE)",  "key": "se",       "label": "Sound Effects"},
    5:  {"type": "label", "x": 360, "y": 210, "w": 450, "h": 48, "text": "Lời thoại nhân vật",      "key": "voice",    "label": "Voice Volume"},
    2:  {"type": "label", "x": 360, "y": 270, "w": 450, "h": 48, "text": "Âm lượng phim",          "key": "movie",    "label": "Movie Volume"},
    4:  {"type": "label", "x": 360, "y": 330, "w": 450, "h": 48, "text": "Giọng hệ thống",          "key": "sysvo",    "label": "System Voice"},
    6:  {"type": "label", "x": 360, "y": 390, "w": 450, "h": 48, "text": "Ngắt giọng khi click",    "key": "voicecut", "label": "Voice Mute on Click"},
    1:  {"type": "label", "x": 360, "y": 450, "w": 450, "h": 48, "text": "Chế độ Downmix",         "key": "down",     "label": "Downmix Mode"},
}

for s_idx, d in LAYOUT_P3.items():
    nx, ny, nw, nh = d["x"], d["y"], d["w"], d["h"]
    if d["type"] == "btn":
        if d.get("use_off_btn"):
            btn_patch = raw_en_img_p3.crop((224, 66, 224 + 282, 66 + 66))
        else:
            orig_y = d["orig_y"]
            btn_patch = raw_en_img_p3.crop((224, orig_y, 224 + 282, orig_y + 66))
        atlas_base_p3.paste(btn_patch, (nx, ny), btn_patch)
        ref_arr = np.array(btn_patch)
        ref_arr[:, :, 3] = (ref_arr[:, :, 3] * 0.35).astype(np.uint8)
        atlas_guide_p3.paste(Image.fromarray(ref_arr), (nx, ny))
    else:
        lbl_img = render_right_aligned_label(d["text"], width=nw, height=nh, margin_right=15)
        atlas_base_p3.paste(lbl_img, (nx, ny), lbl_img)
    guide_draw_p3.rectangle([nx, ny, nx + nw - 1, ny + nh - 1], outline=(255, 40, 40, 255), width=1)
    guide_draw_p3.rectangle([nx + 4, ny + 4, nx + nw - 5, ny + nh - 5], outline=(0, 230, 80, 200), width=1)
    guide_draw_p3.text((nx, ny - 14), f"[{s_idx:02d}] {d['label']} ({nw}x{nh})", font=small_font, fill=(255, 230, 0, 255))

p3_base_png = GUIDE_DIR / "config_p3_atlas_base.png"
p3_guide_png = GUIDE_DIR / "config_p3_atlas_guide.png"
atlas_base_p3.save(p3_base_png)
atlas_guide_p3.save(p3_guide_png)

# PBD Sync Function for Sound
def sync_pbd_sound(json_path, bin_path, out_bin):
    with open(json_path, "r", encoding="utf-8") as f:
        pbd = json.load(f)
    packlist = pbd.get("packlist", [])
    for s_idx, d in LAYOUT_P3.items():
        if s_idx < len(packlist):
            p = packlist[s_idx]
            p[0] = d["x"]
            p[1] = d["y"]
            p[2] = d["w"]
            p[3] = d["h"]
            if len(p) > 7:
                p[7] = None
                
    def walk(node):
        if isinstance(node, dict):
            uiname = node.get("uiname", "")
            if "uistates" in node:
                st = node["uistates"]
                if "head_" in uiname:
                    for s_idx, d in LAYOUT_P3.items():
                        if d["type"] == "label":
                            k = d["key"]
                            if k in st:
                                st[k].update({
                                    "cx": d["x"], "cy": d["y"], "cw": d["w"], "ch": d["h"],
                                    "w": d["w"], "h": d["h"], "ox": 68, "oy": 3, "cr": None
                                })
                elif "voicecut_off" in uiname:
                    if "off" in st: st["off"].update({"cx": LAYOUT_P3[8]["x"], "cy": LAYOUT_P3[8]["y"], "cw": 282, "ch": 66, "w": 282, "h": 66, "cr": None})
                    if "on" in st:  st["on"].update({"cx": LAYOUT_P3[10]["x"], "cy": LAYOUT_P3[10]["y"], "cw": 282, "ch": 66, "w": 282, "h": 66, "cr": None})
                    if "over" in st: st["over"].update({"cx": LAYOUT_P3[11]["x"], "cy": LAYOUT_P3[11]["y"], "cw": 282, "ch": 66, "w": 282, "h": 66, "cr": None})
                elif "voicecut_on" in uiname:
                    if "off" in st: st["off"].update({"cx": LAYOUT_P3[9]["x"], "cy": LAYOUT_P3[9]["y"], "cw": 282, "ch": 66, "w": 282, "h": 66, "cr": None})
                    if "on" in st:  st["on"].update({"cx": LAYOUT_P3[12]["x"], "cy": LAYOUT_P3[12]["y"], "cw": 282, "ch": 66, "w": 282, "h": 66, "cr": None})
                    if "over" in st: st["over"].update({"cx": LAYOUT_P3[13]["x"], "cy": LAYOUT_P3[13]["y"], "cw": 282, "ch": 66, "w": 282, "h": 66, "cr": None})
            for k, v in node.items():
                if k != "uistates": walk(v)
        elif isinstance(node, list):
            for it in node: walk(it)
            
    walk(pbd.get("result", {}))
    synced_json = json_path.parent / (json_path.stem + "_synced.json")
    with open(synced_json, "w", encoding="utf-8") as f:
        json.dump(pbd, f, indent=2, ensure_ascii=False)
    cmd = [str(MSG_TOOL), "import", "-t", "kirikiri-tjs-ns0", str(bin_path), str(synced_json), str(out_bin)]
    subprocess.run(cmd, check=True, capture_output=True)

sync_pbd_sound(PBD_EN_JSON_P3, PBD_EN_BIN_P3, PATCH_PBD_DIR / "entry_01978.bin")
sync_pbd_sound(PBD_JP_JSON_P3, PBD_JP_BIN_P3, PATCH_PBD_DIR / "entry_01980.bin")

# Output TLGs for Sound into BOTH tlg_msgtool AND patch_data/ui
tlg_p3_en = TLG_MSGTOOL_DIR / "entry_01977_57b8.tlg"
tlg_p3_jp = TLG_MSGTOOL_DIR / "entry_01979_57ba.tlg"
subprocess.run([str(MSG_TOOL), "import", "-t", "kirikiri-tlg", str(RAW_EN_TLG_P3), str(p3_base_png), str(tlg_p3_en)], check=True)
subprocess.run([str(MSG_TOOL), "import", "-t", "kirikiri-tlg", str(RAW_EN_TLG_P3), str(p3_base_png), str(tlg_p3_jp)], check=True)
(PATCH_UI_DIR / "entry_01977.bin").write_bytes(tlg_p3_en.read_bytes())
(PATCH_UI_DIR / "entry_01979.bin").write_bytes(tlg_p3_jp.read_bytes())
print("   + Hoàn tất trang Âm Thanh (EN 1977/1978 & JP 1979/1980)!")

# ======================================================================
# 2. BUILD DIALOG (PAGE 2)
# ======================================================================
print("\n[2/4] Xây dựng trang Hội Thoại / Xác Nhận (Dialog - config_p2)...")

RAW_EN_TLG_P2 = ROOT_DIR / "extracted_data" / "data" / "entry_01968_57af.bin"
PBD_EN_JSON_P2 = ROOT_DIR / "temp_pbd_dumps" / "entry_01969_57b0.json"
PBD_EN_BIN_P2 = ROOT_DIR / "extracted_data" / "data" / "entry_01969_57b0.bin"
PBD_JP_JSON_P2 = ROOT_DIR / "temp_pbd_dumps" / "entry_01971_57b2.json"
PBD_JP_BIN_P2 = ROOT_DIR / "extracted_data" / "data" / "entry_01971_57b2.bin"

# Get clean ON/OFF buttons from raw_en_img_p3 (100% clean horizontal pills)
clean_pill_on = raw_en_img_p3.crop((224, 0, 224 + 282, 0 + 66))
clean_pill_on_active = raw_en_img_p3.crop((224, 198, 224 + 282, 198 + 66))
clean_pill_on_hover = raw_en_img_p3.crop((224, 264, 224 + 282, 264 + 66))
clean_pill_off = raw_en_img_p3.crop((224, 66, 224 + 282, 66 + 66))
clean_pill_off_active = raw_en_img_p3.crop((224, 66, 224 + 282, 66 + 66))
clean_pill_off_hover = raw_en_img_p3.crop((224, 132, 224 + 282, 132 + 66))

CANVAS_P2_W = 1200
CANVAS_P2_H = 1050
atlas_base_p2 = Image.new("RGBA", (CANVAS_P2_W, CANVAS_P2_H), (0, 0, 0, 0))
atlas_guide_p2 = Image.new("RGBA", (CANVAS_P2_W, CANVAS_P2_H), (0, 0, 0, 0))
guide_draw_p2 = ImageDraw.Draw(atlas_guide_p2)

LAYOUT_P2 = {
    # Buttons Group 1: cf_title
    1:  {"type": "btn", "x": 30, "y": 30,  "w": 282, "h": 66, "patch": clean_pill_on,        "label": "cf_title ON (off)"},
    4:  {"type": "btn", "x": 30, "y": 105, "w": 282, "h": 66, "patch": clean_pill_on_active, "label": "cf_title ON (on)"},
    5:  {"type": "btn", "x": 30, "y": 180, "w": 282, "h": 66, "patch": clean_pill_on_hover,  "label": "cf_title ON (over)"},
    0:  {"type": "btn", "x": 30, "y": 265, "w": 282, "h": 66, "patch": clean_pill_off,       "label": "cf_title OFF (off)"},
    2:  {"type": "btn", "x": 30, "y": 340, "w": 282, "h": 66, "patch": clean_pill_off_active,"label": "cf_title OFF (on)"},
    3:  {"type": "btn", "x": 30, "y": 415, "w": 282, "h": 66, "patch": clean_pill_off_hover, "label": "cf_title OFF (over)"},

    # Buttons Group 2: nextjump
    22: {"type": "btn", "x": 30, "y": 500, "w": 282, "h": 66, "patch": clean_pill_on,        "label": "nextjump ON (off)"},
    23: {"type": "btn", "x": 30, "y": 575, "w": 282, "h": 66, "patch": clean_pill_on_active, "label": "nextjump ON (on)"},
    24: {"type": "btn", "x": 30, "y": 650, "w": 282, "h": 66, "patch": clean_pill_on_hover,  "label": "nextjump ON (over)"},
    19: {"type": "btn", "x": 30, "y": 735, "w": 282, "h": 66, "patch": clean_pill_off,       "label": "nextjump OFF (off)"},
    20: {"type": "btn", "x": 30, "y": 810, "w": 282, "h": 66, "patch": clean_pill_off_active,"label": "nextjump OFF (on)"},
    21: {"type": "btn", "x": 30, "y": 885, "w": 282, "h": 66, "patch": clean_pill_off_hover, "label": "nextjump OFF (over)"},

    # Buttons Group 3: prevjump
    28: {"type": "btn", "x": 30, "y": 500, "w": 282, "h": 66, "patch": clean_pill_on,        "label": "prevjump ON (off)"},
    29: {"type": "btn", "x": 30, "y": 575, "w": 282, "h": 66, "patch": clean_pill_on_active, "label": "prevjump ON (on)"},
    30: {"type": "btn", "x": 30, "y": 650, "w": 282, "h": 66, "patch": clean_pill_on_hover,  "label": "prevjump ON (over)"},
    25: {"type": "btn", "x": 30, "y": 735, "w": 282, "h": 66, "patch": clean_pill_off,       "label": "prevjump OFF (off)"},
    26: {"type": "btn", "x": 30, "y": 810, "w": 282, "h": 66, "patch": clean_pill_off_active,"label": "prevjump OFF (on)"},
    27: {"type": "btn", "x": 30, "y": 885, "w": 282, "h": 66, "patch": clean_pill_off_hover, "label": "prevjump OFF (over)"},

    # 13 Labels (x=360, w=640, h=48)
    18: {"type": "label", "x": 360, "y": 30,  "w": 640, "h": 48, "text": "Xác nhận về màn hình chính",   "key": "cf_title",       "label": "Title Confirm"},
    10: {"type": "label", "x": 360, "y": 85,  "w": 640, "h": 48, "text": "Xác nhận thoát trò chơi",       "key": "cf_exit",        "label": "Exit Confirm"},
    13: {"type": "label", "x": 360, "y": 140, "w": 640, "h": 48, "text": "Xác nhận tải file lưu",         "key": "cf_load",        "label": "Load Confirm"},
    15: {"type": "label", "x": 360, "y": 195, "w": 640, "h": 48, "text": "Xác nhận ghi đè file lưu",      "key": "cf_overwrite",   "label": "Overwrite Confirm"},
    9:  {"type": "label", "x": 360, "y": 250, "w": 640, "h": 48, "text": "Xác nhận xóa file lưu",         "key": "cf_delete",      "label": "Delete Confirm"},
    17: {"type": "label", "x": 360, "y": 305, "w": 640, "h": 48, "text": "Xác nhận lưu nhanh",            "key": "cf_qsave",       "label": "Quick Save Confirm"},
    16: {"type": "label", "x": 360, "y": 360, "w": 640, "h": 48, "text": "Xác nhận tải nhanh",            "key": "cf_qload",       "label": "Quick Load Confirm"},
    12: {"type": "label", "x": 360, "y": 415, "w": 640, "h": 48, "text": "Xác nhận nhảy đến cảnh",        "key": "cf_jump",        "label": "Jump Confirm"},
    14: {"type": "label", "x": 360, "y": 470, "w": 640, "h": 48, "text": "Xác nhận chuyển cảnh tiếp",     "key": "cf_next",        "label": "Next Confirm"},
    11: {"type": "label", "x": 360, "y": 525, "w": 640, "h": 48, "text": "Xác nhận khôi phục mặc định",   "key": "cf_init",        "label": "Reset Confirm"},
    6:  {"type": "label", "x": 360, "y": 580, "w": 640, "h": 48, "text": "Xác nhận xóa toàn bộ dữ liệu",   "key": "cf_allremove1",  "label": "Remove Data Confirm"},
    7:  {"type": "label", "x": 360, "y": 635, "w": 640, "h": 48, "text": "Xác nhận xóa toàn bộ thiết lập", "key": "cf_allremove2",  "label": "Remove Settings Confirm"},
    8:  {"type": "label", "x": 360, "y": 690, "w": 640, "h": 48, "text": "Xác nhận trở về trước đó",      "key": "cf_backto",      "label": "Backto Confirm"},
}

for s_idx, d in LAYOUT_P2.items():
    nx, ny, nw, nh = d["x"], d["y"], d["w"], d["h"]
    if d["type"] == "btn":
        btn_patch = d["patch"]
        atlas_base_p2.paste(btn_patch, (nx, ny), btn_patch)
        ref_arr = np.array(btn_patch)
        ref_arr[:, :, 3] = (ref_arr[:, :, 3] * 0.35).astype(np.uint8)
        atlas_guide_p2.paste(Image.fromarray(ref_arr), (nx, ny))
    else:
        lbl_img = render_right_aligned_label(d["text"], width=nw, height=nh, margin_right=15)
        atlas_base_p2.paste(lbl_img, (nx, ny), lbl_img)
    guide_draw_p2.rectangle([nx, ny, nx + nw - 1, ny + nh - 1], outline=(255, 40, 40, 255), width=1)
    guide_draw_p2.rectangle([nx + 4, ny + 4, nx + nw - 5, ny + nh - 5], outline=(0, 230, 80, 200), width=1)
    guide_draw_p2.text((nx, ny - 14), f"[{s_idx:02d}] {d['label']} ({nw}x{nh})", font=small_font, fill=(255, 230, 0, 255))

p2_base_png = GUIDE_DIR / "config_p2_atlas_base.png"
p2_guide_png = GUIDE_DIR / "config_p2_atlas_guide.png"
atlas_base_p2.save(p2_base_png)
atlas_guide_p2.save(p2_guide_png)

# PBD Sync Function for Dialog
def sync_pbd_dialog(json_path, bin_path, out_bin):
    with open(json_path, "r", encoding="utf-8") as f:
        pbd = json.load(f)
    packlist = pbd.get("packlist", [])
    for s_idx, d in LAYOUT_P2.items():
        if s_idx < len(packlist):
            p = packlist[s_idx]
            p[0] = d["x"]
            p[1] = d["y"]
            p[2] = d["w"]
            p[3] = d["h"]
            if len(p) > 7:
                p[7] = None
                
    def walk(node):
        if isinstance(node, dict):
            uiname = node.get("uiname", "")
            if "uistates" in node:
                st = node["uistates"]
                if "head_cf_" in uiname:
                    for s_idx, d in LAYOUT_P2.items():
                        if d["type"] == "label":
                            k = d["key"]
                            if k in st:
                                st[k].update({
                                    "cx": d["x"], "cy": d["y"], "cw": d["w"], "ch": d["h"],
                                    "w": d["w"], "h": d["h"], "ox": 72, "oy": 3, "cr": None
                                })
                elif "cf_title_off" in uiname:
                    if "off" in st: st["off"].update({"cx": LAYOUT_P2[0]["x"], "cy": LAYOUT_P2[0]["y"], "cw": 282, "ch": 66, "w": 282, "h": 66, "cr": None})
                    if "on" in st:  st["on"].update({"cx": LAYOUT_P2[2]["x"], "cy": LAYOUT_P2[2]["y"], "cw": 282, "ch": 66, "w": 282, "h": 66, "cr": None})
                    if "over" in st: st["over"].update({"cx": LAYOUT_P2[3]["x"], "cy": LAYOUT_P2[3]["y"], "cw": 282, "ch": 66, "w": 282, "h": 66, "cr": None})
                elif "cf_title_on" in uiname:
                    if "off" in st: st["off"].update({"cx": LAYOUT_P2[1]["x"], "cy": LAYOUT_P2[1]["y"], "cw": 282, "ch": 66, "w": 282, "h": 66, "cr": None})
                    if "on" in st:  st["on"].update({"cx": LAYOUT_P2[4]["x"], "cy": LAYOUT_P2[4]["y"], "cw": 282, "ch": 66, "w": 282, "h": 66, "cr": None})
                    if "over" in st: st["over"].update({"cx": LAYOUT_P2[5]["x"], "cy": LAYOUT_P2[5]["y"], "cw": 282, "ch": 66, "w": 282, "h": 66, "cr": None})
                elif "nextjump_off" in uiname:
                    if "off" in st: st["off"].update({"cx": LAYOUT_P2[19]["x"], "cy": LAYOUT_P2[19]["y"], "cw": 282, "ch": 66, "w": 282, "h": 66, "cr": None})
                    if "on" in st:  st["on"].update({"cx": LAYOUT_P2[20]["x"], "cy": LAYOUT_P2[20]["y"], "cw": 282, "ch": 66, "w": 282, "h": 66, "cr": None})
                    if "over" in st: st["over"].update({"cx": LAYOUT_P2[21]["x"], "cy": LAYOUT_P2[21]["y"], "cw": 282, "ch": 66, "w": 282, "h": 66, "cr": None})
                elif "nextjump_on" in uiname:
                    if "off" in st: st["off"].update({"cx": LAYOUT_P2[22]["x"], "cy": LAYOUT_P2[22]["y"], "cw": 282, "ch": 66, "w": 282, "h": 66, "cr": None})
                    if "on" in st:  st["on"].update({"cx": LAYOUT_P2[23]["x"], "cy": LAYOUT_P2[23]["y"], "cw": 282, "ch": 66, "w": 282, "h": 66, "cr": None})
                    if "over" in st: st["over"].update({"cx": LAYOUT_P2[24]["x"], "cy": LAYOUT_P2[24]["y"], "cw": 282, "ch": 66, "w": 282, "h": 66, "cr": None})
                elif "prevjump_off" in uiname:
                    if "off" in st: st["off"].update({"cx": LAYOUT_P2[25]["x"], "cy": LAYOUT_P2[25]["y"], "cw": 282, "ch": 66, "w": 282, "h": 66, "cr": None})
                    if "on" in st:  st["on"].update({"cx": LAYOUT_P2[26]["x"], "cy": LAYOUT_P2[26]["y"], "cw": 282, "ch": 66, "w": 282, "h": 66, "cr": None})
                    if "over" in st: st["over"].update({"cx": LAYOUT_P2[27]["x"], "cy": LAYOUT_P2[27]["y"], "cw": 282, "ch": 66, "w": 282, "h": 66, "cr": None})
                elif "prevjump_on" in uiname:
                    if "off" in st: st["off"].update({"cx": LAYOUT_P2[28]["x"], "cy": LAYOUT_P2[28]["y"], "cw": 282, "ch": 66, "w": 282, "h": 66, "cr": None})
                    if "on" in st:  st["on"].update({"cx": LAYOUT_P2[29]["x"], "cy": LAYOUT_P2[29]["y"], "cw": 282, "ch": 66, "w": 282, "h": 66, "cr": None})
                    if "over" in st: st["over"].update({"cx": LAYOUT_P2[30]["x"], "cy": LAYOUT_P2[30]["y"], "cw": 282, "ch": 66, "w": 282, "h": 66, "cr": None})
            for k, v in node.items():
                if k != "uistates": walk(v)
        elif isinstance(node, list):
            for it in node: walk(it)
            
    walk(pbd.get("result", {}))
    synced_json = json_path.parent / (json_path.stem + "_synced.json")
    with open(synced_json, "w", encoding="utf-8") as f:
        json.dump(pbd, f, indent=2, ensure_ascii=False)
    cmd = [str(MSG_TOOL), "import", "-t", "kirikiri-tjs-ns0", str(bin_path), str(synced_json), str(out_bin)]
    subprocess.run(cmd, check=True, capture_output=True)

sync_pbd_dialog(PBD_EN_JSON_P2, PBD_EN_BIN_P2, PATCH_PBD_DIR / "entry_01969.bin")
sync_pbd_dialog(PBD_JP_JSON_P2, PBD_JP_BIN_P2, PATCH_PBD_DIR / "entry_01971.bin")

# Output TLGs for Dialog into BOTH tlg_msgtool AND patch_data/ui
tlg_p2_en = TLG_MSGTOOL_DIR / "entry_01968_57af.tlg"
tlg_p2_jp = TLG_MSGTOOL_DIR / "entry_01970_57b1.tlg"
subprocess.run([str(MSG_TOOL), "import", "-t", "kirikiri-tlg", str(RAW_EN_TLG_P2), str(p2_base_png), str(tlg_p2_en)], check=True)
subprocess.run([str(MSG_TOOL), "import", "-t", "kirikiri-tlg", str(RAW_EN_TLG_P2), str(p2_base_png), str(tlg_p2_jp)], check=True)
(PATCH_UI_DIR / "entry_01968.bin").write_bytes(tlg_p2_en.read_bytes())
(PATCH_UI_DIR / "entry_01970.bin").write_bytes(tlg_p2_jp.read_bytes())
print("   + Hoàn tất trang Hội Thoại (EN 1968/1969 & JP 1970/1971) - ĐÃ XÓA SẠCH VẾT MAGENTA CŨ!")

# ======================================================================
# 3. BUILD DISPLAY (PAGE 0)
# ======================================================================
print("\n[3/4] Xây dựng trang Hiển Thị (Display - config_p0)...")

RAW_EN_TLG_P0 = ROOT_DIR / "extracted_data" / "data" / "entry_01950_579d.bin"
PBD_EN_JSON_P0 = ROOT_DIR / "temp_pbd_dumps" / "entry_01951_579e.json"
PBD_EN_BIN_P0 = ROOT_DIR / "extracted_data" / "data" / "entry_01951_579e.bin"
PBD_JP_JSON_P0 = ROOT_DIR / "temp_pbd_dumps" / "entry_01953_57a0.json"
PBD_JP_BIN_P0 = ROOT_DIR / "extracted_data" / "data" / "entry_01953_57a0.bin"

clean_en_png_p0 = Path("temp_clean_en_display.png")
subprocess.run([str(MSG_TOOL), "export", "-t", "kirikiri-tlg", str(RAW_EN_TLG_P0), str(clean_en_png_p0)], capture_output=True)
raw_en_img_p0 = Image.open(clean_en_png_p0).convert("RGBA")

CANVAS_P0_W = 1000
CANVAS_P0_H = 800
atlas_base_p0 = Image.new("RGBA", (CANVAS_P0_W, CANVAS_P0_H), (0, 0, 0, 0))
atlas_guide_p0 = Image.new("RGBA", (CANVAS_P0_W, CANVAS_P0_H), (0, 0, 0, 0))
guide_draw_p0 = ImageDraw.Draw(atlas_guide_p0)

LAYOUT_P0 = {
    # Buttons Group 1: Fullscreen (Slices 06..10)
    6:  {"type": "btn", "x": 30, "y": 30,  "w": 282, "h": 66, "orig": (0, 418), "label": "Fullscreen OFF (off)"},
    7:  {"type": "btn", "x": 30, "y": 105, "w": 282, "h": 66, "orig": (0, 484), "label": "Fullscreen ON (off)"},
    8:  {"type": "btn", "x": 30, "y": 180, "w": 282, "h": 66, "orig": (0, 550), "label": "Fullscreen OFF (on)"},
    9:  {"type": "btn", "x": 30, "y": 255, "w": 282, "h": 66, "orig": (282, 0), "label": "Fullscreen ON (on)"},
    10: {"type": "btn", "x": 30, "y": 330, "w": 282, "h": 66, "orig": (282, 66),"label": "Fullscreen ON (over)"},
    
    # Buttons Group 2: VSync (Slices 20..25)
    21: {"type": "btn", "x": 30, "y": 415, "w": 282, "h": 66, "orig": (0, 418), "label": "VSync OFF (off)"},
    20: {"type": "btn", "x": 30, "y": 490, "w": 282, "h": 66, "orig": (0, 484), "label": "VSync ON (off)"},
    22: {"type": "btn", "x": 30, "y": 565, "w": 282, "h": 66, "orig": (0, 550), "label": "VSync OFF (on)"},
    23: {"type": "btn", "x": 30, "y": 640, "w": 282, "h": 66, "orig": (0, 550), "label": "VSync OFF (over)"},
    24: {"type": "btn", "x": 30, "y": 715, "w": 282, "h": 66, "orig": (282, 0), "label": "VSync ON (on)"},
    25: {"type": "btn", "x": 30, "y": 715, "w": 282, "h": 66, "orig": (282, 66),"label": "VSync ON (over)"},

    # Language text crops (Slices 00..05)
    0:  {"type": "crop", "x": 360, "y": 550, "w": 126, "h": 41, "orig": (415, 91),  "label": "CN"},
    1:  {"type": "crop", "x": 360, "y": 600, "w": 204, "h": 34, "orig": (375, 137), "label": "EN"},
    2:  {"type": "crop", "x": 360, "y": 645, "w": 121, "h": 41, "orig": (516, 550), "label": "JP"},
    3:  {"type": "crop", "x": 360, "y": 695, "w": 78,  "h": 40, "orig": (516, 509), "label": "KR"},
    4:  {"type": "crop", "x": 360, "y": 745, "w": 93,  "h": 34, "orig": (449, 0),   "label": "NONE"},
    5:  {"type": "crop", "x": 580, "y": 550, "w": 126, "h": 41, "orig": (415, 91),  "label": "TW"},

    # 9 Display Labels (căn lề phải w=500, h=48)
    12: {"type": "label", "x": 360, "y": 30,  "w": 500, "h": 48, "text": "Chế độ hiển thị",              "key": "fullscreen", "label": "Display Mode"},
    17: {"type": "label", "x": 360, "y": 85,  "w": 500, "h": 48, "text": "Ngôn ngữ giao diện",            "key": "uilang",     "label": "UI Lang"},
    15: {"type": "label", "x": 360, "y": 140, "w": 500, "h": 48, "text": "Ngôn ngữ văn bản chính",        "key": "textlang",   "label": "Main Text"},
    14: {"type": "label", "x": 360, "y": 195, "w": 500, "h": 48, "text": "Phụ đề ngôn ngữ phụ",          "key": "sublang",    "label": "Sub Text"},
    13: {"type": "label", "x": 360, "y": 250, "w": 500, "h": 48, "text": "Quay lại game sau khi lưu",    "key": "savequit",   "label": "Return After Saving"},
    19: {"type": "label", "x": 360, "y": 305, "w": 500, "h": 48, "text": "Đồng bộ khung hình (VSync)",    "key": "vspeedsync", "label": "VSync"},
    11: {"type": "label", "x": 360, "y": 360, "w": 500, "h": 48, "text": "Tốc độ dựng hình",             "key": "drawspeed",  "label": "Draw Speed"},
    18: {"type": "label", "x": 360, "y": 415, "w": 500, "h": 48, "text": "Tốc độ phát giọng",             "key": "voicespeed", "label": "Voice Speed"},
    16: {"type": "label", "x": 360, "y": 470, "w": 500, "h": 48, "text": "Chế độ cảm ứng",               "key": "touchmode",  "label": "Touch Mode"},
}

for s_idx, d in LAYOUT_P0.items():
    nx, ny, nw, nh = d["x"], d["y"], d["w"], d["h"]
    if d["type"] == "btn" or d["type"] == "crop":
        ox, oy = d["orig"]
        patch = raw_en_img_p0.crop((ox, oy, ox + nw, oy + nh))
        atlas_base_p0.paste(patch, (nx, ny), patch)
        ref_arr = np.array(patch)
        ref_arr[:, :, 3] = (ref_arr[:, :, 3] * 0.35).astype(np.uint8)
        atlas_guide_p0.paste(Image.fromarray(ref_arr), (nx, ny))
    else:
        lbl_img = render_right_aligned_label(d["text"], width=nw, height=nh, margin_right=15)
        atlas_base_p0.paste(lbl_img, (nx, ny), lbl_img)
    guide_draw_p0.rectangle([nx, ny, nx + nw - 1, ny + nh - 1], outline=(255, 40, 40, 255), width=1)
    guide_draw_p0.rectangle([nx + 4, ny + 4, nx + nw - 5, ny + nh - 5], outline=(0, 230, 80, 200), width=1)
    guide_draw_p0.text((nx, ny - 14), f"[{s_idx:02d}] {d['label']} ({nw}x{nh})", font=small_font, fill=(255, 230, 0, 255))

p0_base_png = GUIDE_DIR / "config_p0_atlas_base.png"
p0_guide_png = GUIDE_DIR / "config_p0_atlas_guide.png"
atlas_base_p0.save(p0_base_png)
atlas_guide_p0.save(p0_guide_png)

# PBD Sync Function for Display
def sync_pbd_display(json_path, bin_path, out_bin):
    with open(json_path, "r", encoding="utf-8") as f:
        pbd = json.load(f)
    packlist = pbd.get("packlist", [])
    for s_idx, d in LAYOUT_P0.items():
        if s_idx < len(packlist):
            p = packlist[s_idx]
            p[0] = d["x"]
            p[1] = d["y"]
            p[2] = d["w"]
            p[3] = d["h"]
            if len(p) > 7:
                p[7] = None
                
    def walk(node):
        if isinstance(node, dict):
            uiname = node.get("uiname", "")
            if "uistates" in node:
                st = node["uistates"]
                if "head_" in uiname:
                    for s_idx, d in LAYOUT_P0.items():
                        if d["type"] == "label":
                            k = d["key"]
                            if k in st:
                                st[k].update({
                                    "cx": d["x"], "cy": d["y"], "cw": d["w"], "ch": d["h"],
                                    "w": d["w"], "h": d["h"], "ox": 68, "oy": 3, "cr": None
                                })
                elif "fullscreen_off" in uiname:
                    if "off" in st: st["off"].update({"cx": LAYOUT_P0[6]["x"], "cy": LAYOUT_P0[6]["y"], "cw": 282, "ch": 66, "w": 282, "h": 66, "cr": None})
                    if "on" in st:  st["on"].update({"cx": LAYOUT_P0[8]["x"], "cy": LAYOUT_P0[8]["y"], "cw": 282, "ch": 66, "w": 282, "h": 66, "cr": None})
                elif "fullscreen_on" in uiname:
                    if "off" in st: st["off"].update({"cx": LAYOUT_P0[7]["x"], "cy": LAYOUT_P0[7]["y"], "cw": 282, "ch": 66, "w": 282, "h": 66, "cr": None})
                    if "on" in st:  st["on"].update({"cx": LAYOUT_P0[9]["x"], "cy": LAYOUT_P0[9]["y"], "cw": 282, "ch": 66, "w": 282, "h": 66, "cr": None})
                    if "over" in st: st["over"].update({"cx": LAYOUT_P0[10]["x"], "cy": LAYOUT_P0[10]["y"], "cw": 282, "ch": 66, "w": 282, "h": 66, "cr": None})
                elif "vspeedsync_off" in uiname:
                    if "off" in st: st["off"].update({"cx": LAYOUT_P0[21]["x"], "cy": LAYOUT_P0[21]["y"], "cw": 282, "ch": 66, "w": 282, "h": 66, "cr": None})
                    if "on" in st:  st["on"].update({"cx": LAYOUT_P0[22]["x"], "cy": LAYOUT_P0[22]["y"], "cw": 282, "ch": 66, "w": 282, "h": 66, "cr": None})
                    if "over" in st: st["over"].update({"cx": LAYOUT_P0[23]["x"], "cy": LAYOUT_P0[23]["y"], "cw": 282, "ch": 66, "w": 282, "h": 66, "cr": None})
                elif "vspeedsync_on" in uiname:
                    if "off" in st: st["off"].update({"cx": LAYOUT_P0[20]["x"], "cy": LAYOUT_P0[20]["y"], "cw": 282, "ch": 66, "w": 282, "h": 66, "cr": None})
                    if "on" in st:  st["on"].update({"cx": LAYOUT_P0[24]["x"], "cy": LAYOUT_P0[24]["y"], "cw": 282, "ch": 66, "w": 282, "h": 66, "cr": None})
                    if "over" in st: st["over"].update({"cx": LAYOUT_P0[25]["x"], "cy": LAYOUT_P0[25]["y"], "cw": 282, "ch": 66, "w": 282, "h": 66, "cr": None})
            for k, v in node.items():
                if k != "uistates": walk(v)
        elif isinstance(node, list):
            for it in node: walk(it)
            
    walk(pbd.get("result", {}))
    synced_json = json_path.parent / (json_path.stem + "_synced.json")
    with open(synced_json, "w", encoding="utf-8") as f:
        json.dump(pbd, f, indent=2, ensure_ascii=False)
    cmd = [str(MSG_TOOL), "import", "-t", "kirikiri-tjs-ns0", str(bin_path), str(synced_json), str(out_bin)]
    subprocess.run(cmd, check=True, capture_output=True)

sync_pbd_display(PBD_EN_JSON_P0, PBD_EN_BIN_P0, PATCH_PBD_DIR / "entry_01951.bin")
sync_pbd_display(PBD_JP_JSON_P0, PBD_JP_BIN_P0, PATCH_PBD_DIR / "entry_01953.bin")

# Output TLGs for Display into BOTH tlg_msgtool AND patch_data/ui
tlg_p0_en = TLG_MSGTOOL_DIR / "entry_01950_579d.tlg"
tlg_p0_jp = TLG_MSGTOOL_DIR / "entry_01952_579f.tlg"
subprocess.run([str(MSG_TOOL), "import", "-t", "kirikiri-tlg", str(RAW_EN_TLG_P0), str(p0_base_png), str(tlg_p0_en)], check=True)
subprocess.run([str(MSG_TOOL), "import", "-t", "kirikiri-tlg", str(RAW_EN_TLG_P0), str(p0_base_png), str(tlg_p0_jp)], check=True)
(PATCH_UI_DIR / "entry_01950.bin").write_bytes(tlg_p0_en.read_bytes())
(PATCH_UI_DIR / "entry_01952.bin").write_bytes(tlg_p0_jp.read_bytes())
print("   + Hoàn tất trang Hiển Thị (EN 1950/1951 & JP 1952/1953)!")

# ======================================================================
# 4. FIX TAB HEADER ("GIỌNG NÓI")
# ======================================================================
print("\n[4/4] Đồng bộ thanh Tab Base (sửa Giọng Nói cho tab 4)...")
RAW_1948 = ROOT_DIR / "extracted_data" / "data" / "entry_01948_579b.bin"
base_1948_png = Path("temp_base_1948.png")
subprocess.run([str(MSG_TOOL), "export", "-t", "kirikiri-tlg", str(RAW_1948), str(base_1948_png)], capture_output=True)
img_1948 = Image.open(base_1948_png).convert("RGBA")

tab_font_off = ImageFont.truetype(str(font_path), 20)
tab_font_over = ImageFont.truetype(str(font_path), 24)

draw_1948 = ImageDraw.Draw(img_1948)
draw_1948.rectangle([710, 268, 710 + 139, 268 + 30], fill=(0, 0, 0, 0))
bb = draw_1948.textbbox((0, 0), "GiọngNói", font=tab_font_off)
tw, th = bb[2] - bb[0], bb[3] - bb[1]
tx = 710 + (139 - tw) // 2
ty = 268 + (30 - th) // 2 - bb[1]
draw_1948.text((tx, ty), "GiọngNói", font=tab_font_off, fill=(100, 150, 180, 255))

draw_1948.rectangle([465, 193, 465 + 157, 193 + 48], fill=(0, 0, 0, 0))
bb = draw_1948.textbbox((0, 0), "GiọngNói", font=tab_font_over)
tw, th = bb[2] - bb[0], bb[3] - bb[1]
tx = 465 + (157 - tw) // 2
ty = 193 + (48 - th) // 2 - bb[1]
draw_1948.text((tx, ty), "GiọngNói", font=tab_font_over, fill=(255, 255, 255, 255))

fixed_1948_png = Path("temp_fixed_1948.png")
img_1948.save(fixed_1948_png)

tlg_1948 = TLG_MSGTOOL_DIR / "entry_01948_579b.tlg"
subprocess.run([str(MSG_TOOL), "import", "-t", "kirikiri-tlg", str(RAW_1948), str(fixed_1948_png), str(tlg_1948)], check=True)
(PATCH_UI_DIR / "entry_01948.bin").write_bytes(tlg_1948.read_bytes())

# ======================================================================
# REPACK INTO GAME DATA.XP3
# ======================================================================
print("\nĐóng gói toàn diện vào data.xp3 của game...")
res = subprocess.run([str(USER_PYTHON), str(REPACK_SCRIPT)], capture_output=True, text=True)
print(res.stdout)
if res.returncode != 0:
    print("[-] Lỗi repack:", res.stderr)
else:
    print("[+] HOÀN TẤT ĐÓNG GÓI DISPLAY + DIALOG + SOUND VÀO GAME!")
