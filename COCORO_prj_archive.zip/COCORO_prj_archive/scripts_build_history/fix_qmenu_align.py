import shutil
from pathlib import Path

orig_pbd = Path("extracted_data/data/entry_02157_586c.bin")
patch_pbd = Path("COCORO_Patch_VietHoa/patch_data/pbd/entry_02157.bin")

shutil.copy2(orig_pbd, patch_pbd)
print(f"Da khoi phuc entry_02157.bin goc: size={patch_pbd.stat().st_size} bytes!")

# Kiem tra lai byte tai offset 0x1166
b = patch_pbd.read_bytes()
print(f"Byte tai 0x1166: 0x{b[0x1166]:02x} (0x4f = 1615, 0x81 = 1665)")
assert b[0x1166] == 0x4F, "Loi khoi phuc toa do x!"
print("Toa do tat ca cac nut in-game qmenu da thang hang 100%!")
