from PIL import Image

im = Image.open(r"C:\Users\ADMIN\.gemini\antigravity\brain\6b02dd57-4279-4cd4-9c69-1295e15a34fe\.user_uploaded\media_1795387234991_5ce0a5dd.jpg")

# Cắt toàn bộ 4 nút đầu: Lưu, Tải, Lưu nhanh, Tải nhanh
top4 = im.crop((0, 0, im.width, 360))
top4.save("top4_buttons.png")
print("Saved top4_buttons.png!")
