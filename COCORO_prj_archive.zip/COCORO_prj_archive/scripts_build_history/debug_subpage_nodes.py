import json
from pathlib import Path

with open('orig_fresh/entry_01951.json', 'r', encoding='utf-8') as f:
    pbd = json.load(f)

def find_parent_of_head(node, path=''):
    if isinstance(node, dict):
        has_head = False
        for k, v in node.items():
            if isinstance(v, dict) and v.get('uiname', '').startswith('head_'):
                has_head = True
                break
        if has_head:
            print(f'=== CONTAINER: {path} ===')
            for sk, sv in node.items():
                if isinstance(sv, dict):
                    print(f"  key: {sk}, uiname: {sv.get('uiname')}, storage: {sv.get('storage')}, ox: {sv.get('ox')}, oy: {sv.get('oy')}, x: {sv.get('x')}, y: {sv.get('y')}")
                    if 'uistates' in sv:
                        for uk, uv in sv['uistates'].items():
                            print(f"     state {uk}: storage={uv.get('storage')}, cx={uv.get('cx')}, cy={uv.get('cy')}, cw={uv.get('cw')}, ch={uv.get('ch')}, ox={uv.get('ox')}, oy={uv.get('oy')}")
        for k, v in node.items():
            if isinstance(v, (dict, list)):
                find_parent_of_head(v, f'{path}/{k}')
    elif isinstance(node, list):
        for idx, it in enumerate(node):
            find_parent_of_head(it, f'{path}[{idx}]')

find_parent_of_head(pbd)
