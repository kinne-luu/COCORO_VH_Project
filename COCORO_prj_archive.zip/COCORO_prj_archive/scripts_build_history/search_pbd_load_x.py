import json
from pathlib import Path

for f in Path("temp_pbd_dumps").glob("*.json"):
    try:
        d = json.load(open(f, encoding='utf-8'))
        res = d.get("result", {})
        if "load" in res and "save" in res:
            s_x = res["save"].get("x")
            l_x = res["load"].get("x")
            print(f"{f.name}: save.x={s_x}, load.x={l_x}")
    except:
        pass
