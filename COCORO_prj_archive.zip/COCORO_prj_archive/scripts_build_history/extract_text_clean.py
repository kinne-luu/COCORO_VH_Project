import sys
from pathlib import Path

sys.path.insert(0, r"E:\Extract Tools\cxdec-hxv4\src\common")
from xp3_inspect import DripProgram, read_archive, load_index, parse_hxv4_table, FilterRuntimeState

BAK_PATH = Path(r"E:\Games\COCORO.FIXED\game\data.xp3.original.bak")
DRIP_PATH = Path(r"E:\Extract Tools\cxdec-hxv4\data\static_recover\drip_program_COCORO.exe.unpacked.json")
OUT_DIR = Path("true_clean_extracted")

drip = DripProgram.load(DRIP_PATH)
with open(BAK_PATH, "rb") as f:
    blob = f.read()

info, entries, _ = read_archive(BAK_PATH)
_, _, _, index = load_index(blob)
descriptor, records = parse_hxv4_table(blob, index, entries, drip)
open_flag = descriptor.flags & 1

targets = [1960, 1961, 1962]
for r in records:
    if r.xp3_entry_index in targets:
        e = entries[r.xp3_entry_index]
        seg = e.segments[0]
        seed_state = drip.build_filter_state(r.key, open_flag)
        fs = FilterRuntimeState(seed_state)
        raw = bytearray(blob[seg.offset : seg.offset + seg.archived_size])
        fs.apply(raw, 0)
        out_path = OUT_DIR / f"entry_{r.xp3_entry_index:05d}.bin"
        out_path.write_bytes(raw)
        print(f"Extracted clean entry {r.xp3_entry_index:05d} ({len(raw)} bytes) -> {out_path.name}")
