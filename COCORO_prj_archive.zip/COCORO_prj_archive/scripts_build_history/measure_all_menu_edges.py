from PIL import Image
import numpy as np

im = Image.open(r"C:\Users\ADMIN\.gemini\antigravity\brain\6b02dd57-4279-4cd4-9c69-1295e15a34fe\.user_uploaded\media_1795387234991_5ce0a5dd.jpg").convert("RGBA")
arr = np.array(im)

for y in range(80, 500, 10):
    row = arr[y, :, :3]
    dark_xs = np.where((row[:, 0] < 100) & (row[:, 1] < 100) & (row[:, 2] < 100))[0]
    if len(dark_xs) > 0:
        print(f"y={y:3d}: first dark x = {dark_xs[0]}")
