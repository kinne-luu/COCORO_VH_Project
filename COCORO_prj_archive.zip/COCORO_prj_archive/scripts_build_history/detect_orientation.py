import numpy as np
from PIL import Image

def find_icon_position(path):
    im = Image.open(path).convert("RGBA")
    arr = np.array(im)
    # Icon màu trắng hoặc sáng nằm ở đâu?
    # Ta tìm các pixel có R, G, B > 200
    white_pixels = np.where((arr[:, :, 0] > 200) & (arr[:, :, 1] > 200) & (arr[:, :, 2] > 200))
    if len(white_pixels[1]) > 0:
        min_x = np.min(white_pixels[1])
        max_x = np.max(white_pixels[1])
        print(f"{path}: white pixels X range = [{min_x}, {max_x}]")
    else:
        print(f"{path}: no bright pixels found")

find_icon_position("orig_load.png")
find_icon_position("orig_save_rot90.png")
find_icon_position("orig_save_rot270.png")
find_icon_position("user_load.png")
find_icon_position("user_save_rot90.png")
find_icon_position("user_save_rot270.png")
