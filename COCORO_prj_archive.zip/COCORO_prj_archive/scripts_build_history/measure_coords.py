from PIL import Image
import numpy as np

user_img = Image.open(r"C:\Users\ADMIN\.gemini\antigravity\brain\6b02dd57-4279-4cd4-9c69-1295e15a34fe\.user_uploaded\media_1795402114054_6050186b.jpg")
arr = np.array(user_img)

# Print image shape
print("Shape:", arr.shape)

# Let's sample colors across the row at y = 215 (across BGM)
for x in range(30, 200, 5):
    print(f"x={x}: RGB={arr[215, x][:3]}")
